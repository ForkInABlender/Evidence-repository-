# Dylan Kenneth Eliot — Optimized Pure-NumPy transformer v4
# Changes from v3: tiktoken BPE tokenization, embedding lookup (replaces one-hot concat),
#                  sinusoidal positional encoding added to embeddings

import numpy as np, warnings
import tiktoken
warnings.filterwarnings('ignore')

enc = tiktoken.get_encoding("gpt2")
VOCAB_SIZE = enc.n_vocab  # 50257

def tokenise(text): return enc.encode(text)
def detokenise(tokens): return enc.decode(tokens)

D=64; HEADS=4; BLOCKS=4; FFN_D=128; CTX=8; CLIP=1.0
DROPOUT_P=0.1; LABEL_SMOOTH=0.1; BATCH=16
LR_MAX=0.0002; LR_MIN=1e-6; BETA1=0.9; BETA2=0.999; EPS_A=1e-8
TRAINING=True

def dropout(x):
    if not TRAINING: return x
    return x*(np.random.rand(*x.shape)>DROPOUT_P)/(1-DROPOUT_P)

def clip_grad(g, norm=None):
    n=norm or np.linalg.norm(g)
    return (g*(CLIP/n) if n>CLIP else g), n

def gelu(x):
    x=np.clip(x,-10,10)
    return 0.5*x*(1+np.tanh(np.sqrt(2/np.pi)*(x+0.044715*x**3)))

def gelu_grad(x):
    x=np.clip(x,-10,10)
    cdf=0.5*(1+np.tanh(np.sqrt(2/np.pi)*(x+0.044715*x**3)))
    arg=np.clip(np.sqrt(2/np.pi)*(x+0.044715*x**3),-30,30)
    return cdf+x*np.sqrt(2/np.pi)*(1+0.134145*x**2)/np.cosh(arg)**2

def softmax(x):
    e=np.exp(np.clip(x-x.max(),-30,0)); return e/(e.sum()+1e-9)

def ln(x,g,b,eps=1e-6):
    mu=x.mean(); sd=x.std()+eps; return g*(x-mu)/sd+b,mu,sd

def ln_grad(dout,x,g,mu,sd):
    N=x.size; xn=(x-mu)/sd
    dx=g/(N*sd)*(N*dout-dout.sum()-xn*(dout*xn).sum())
    return dx,dout*xn,dout

def smooth_loss(probs, tgt, eps=LABEL_SMOOTH):
    smooth=np.full(VOCAB_SIZE, eps/VOCAB_SIZE)
    smooth[tgt]+=1-eps
    return -np.sum(smooth*np.log(np.clip(probs,1e-9,1)))

def smooth_grad(probs, tgt, eps=LABEL_SMOOTH):
    smooth=np.full(VOCAB_SIZE, eps/VOCAB_SIZE)
    smooth[tgt]+=1-eps
    return probs-smooth

def sinusoidal_pe(ctx, d):
    """Sinusoidal positional encoding, shape (ctx, d)."""
    pos=np.arange(ctx)[:,None]; i=np.arange(d)[None,:]
    angles=pos/np.power(10000,(2*(i//2))/d)
    pe=np.where(i%2==0, np.sin(angles), np.cos(angles))
    return pe  # (ctx, d)

# ─── COSINE LR SCHEDULE ───────────────────────────────────────
def cosine_lr(step, total_steps, warmup=200):
    if step < warmup:
        return LR_MAX * step / warmup
    progress = (step - warmup) / max(1, total_steps - warmup)
    return LR_MIN + 0.5*(LR_MAX-LR_MIN)*(1+np.cos(np.pi*progress))

# ─── ADAM ─────────────────────────────────────────────────────
class Adam:
    def __init__(self): self.m={}; self.v={}; self.t=0
    def step(self, params, grads, lr):
        self.t+=1
        for k,g in grads.items():
            if k not in self.m:
                self.m[k]=np.zeros_like(g); self.v[k]=np.zeros_like(g)
            self.m[k]=BETA1*self.m[k]+(1-BETA1)*g
            self.v[k]=BETA2*self.v[k]+(1-BETA2)*g**2
            mh=self.m[k]/(1-BETA1**self.t)
            vh=self.v[k]/(1-BETA2**self.t)
            params[k]-=lr*mh/(np.sqrt(vh)+EPS_A)

# ─── TRANSFORMER BLOCK ────────────────────────────────────────
class Block:
    def __init__(self,d,heads,ffn_d):
        s=np.sqrt(2/(d*2)); sf=np.sqrt(2/(d+ffn_d))
        self.p={'Wq':np.random.randn(d,d)*s,'Wk':np.random.randn(d,d)*s,
                'Wv':np.random.randn(d,d)*s,'Wo':np.random.randn(d,d)*s,
                'W1':np.random.randn(d,ffn_d)*sf,'b1':np.zeros(ffn_d),
                'W2':np.random.randn(ffn_d,d)*sf,'b2':np.zeros(d),
                'g1':np.ones(d),'b_ln1':np.zeros(d),
                'g2':np.ones(d),'b_ln2':np.zeros(d)}
        self.opt=Adam(); self.d=d; self.heads=heads
        self._acc={k:np.zeros_like(v) for k,v in self.p.items()}

    def forward(self,x):
        p=self.p
        l1,mu1,sd1=ln(x,p['g1'],p['b_ln1'])
        Q=l1@p['Wq']; K=l1@p['Wk']; V=l1@p['Wv']
        a=softmax(Q@K/np.sqrt(self.d/self.heads))
        sa=dropout((a*V)@p['Wo']); x1=x+sa
        l2,mu2,sd2=ln(x1,p['g2'],p['b_ln2'])
        h=l2@p['W1']+p['b1']; hg=gelu(h)
        x2=x1+dropout(hg@p['W2']+p['b2'])
        self._c=(x,l1,mu1,sd1,Q,K,V,a,sa,x1,l2,mu2,sd2,h,hg)
        return x2

    def backward(self,dout):
        p=self.p; (x,l1,mu1,sd1,Q,K,V,a,sa,x1,l2,mu2,sd2,h,hg)=self._c
        dffn,_=clip_grad(dout)
        dW2=hg[:,None]@dffn[None,:]; db2=dffn.copy()
        dhg=dffn@p['W2'].T; dh=dhg*gelu_grad(h)
        dW1=l2[:,None]@dh[None,:]; db1=dh.copy()
        dln2,dg2,db_ln2=ln_grad(dh@p['W1'].T,x1,p['g2'],mu2,sd2)
        dx1=dout+dln2
        dsa,_=clip_grad(dx1)
        dWo=sa[:,None]@dsa[None,:]
        dV=dsa@p['Wo'].T*a; dQ=dsa@p['Wo'].T*V/np.sqrt(self.d/self.heads); dK=dQ.copy()
        dln1,dg1,db_ln1=ln_grad(dQ@p['Wq'].T+dK@p['Wk'].T+dV@p['Wv'].T,x,p['g1'],mu1,sd1)
        for k,g in [('Wq',l1[:,None]@dQ[None,:]),('Wk',l1[:,None]@dK[None,:]),
                    ('Wv',l1[:,None]@dV[None,:]),('Wo',dWo),
                    ('W1',dW1),('b1',db1),('W2',dW2),('b2',db2),
                    ('g1',dg1),('b_ln1',db_ln1),('g2',dg2),('b_ln2',db_ln2)]:
            self._acc[k]+=g
        return clip_grad(dx1+dln1)[0]

    def apply(self, lr):
        grads={k:v/BATCH for k,v in self._acc.items()}
        self.opt.step(self.p, grads, lr)
        for k in self._acc: self._acc[k][:]=0

# ─── MODEL ────────────────────────────────────────────────────
class MiniTransformer:
    def __init__(self,vocab,d,heads,blocks,ffn_d,ctx):
        self.ctx=ctx; self.d=d; self.vocab=vocab
        # Embedding lookup table instead of one-hot projection
        self.We=np.random.randn(vocab,d)*np.sqrt(2/(vocab+d))  # (vocab, d)
        self.pe=sinusoidal_pe(ctx,d)                            # (ctx, d) — fixed, not trained
        self.be=np.zeros(d)
        self.Wo=np.random.randn(d,vocab)*np.sqrt(2/(d+vocab))
        self.bo=np.zeros(vocab)
        self.blocks=[Block(d,heads,ffn_d) for _ in range(blocks)]
        self.opt=Adam()
        self._acc_We=np.zeros_like(self.We)
        self._acc_Wo=np.zeros_like(self.Wo)
        self._acc_bo=np.zeros_like(self.bo)

    def forward(self,ctx_tokens):
        # Embed each token and add positional encoding, then sum to single vector
        self._tok=ctx_tokens
        embs=self.We[ctx_tokens]+self.pe  # (ctx, d)
        x=embs.sum(axis=0)+self.be        # (d,) — sum over context positions
        for blk in self.blocks: x=blk.forward(x)
        self._xN=x.copy()
        self._probs=softmax(x@self.Wo+self.bo)
        return self._probs

    def backward(self,tgt):
        dlogits=smooth_grad(self._probs,tgt)
        dx=clip_grad(dlogits@self.Wo.T)[0]
        self._acc_Wo+=clip_grad(self._xN[:,None]@dlogits[None,:])[0]
        self._acc_bo+=clip_grad(dlogits)[0]
        for blk in reversed(self.blocks): dx=blk.backward(dx)
        # dx flows back equally to each token embedding in the context
        for t in self._tok:
            self._acc_We[t]+=clip_grad(dx)[0]

    def apply(self, lr):
        p={'Wo':self.Wo,'bo':self.bo}
        grads={'Wo':self._acc_Wo/BATCH,'bo':self._acc_bo/BATCH}
        self.opt.step(p,grads,lr)
        # Embedding rows updated via sparse Adam-style SGD
        self.We-=lr*(self._acc_We/BATCH)
        self._acc_We[:]=0; self._acc_Wo[:]=0; self._acc_bo[:]=0
        for blk in self.blocks: blk.apply(lr)

    def loss(self,tgt):
        return smooth_loss(self._probs,tgt)

# ─── CORPUS ───────────────────────────────────────────────────
CORPUS = """What is 2+2? 2+2 equals 4. What is 3+3? 3+3 equals 6. What is 10 times 10? 10 times 10 equals 100. What is 7 times 8? 7 times 8 equals 56. What is the square root of 144? The square root of 144 is 12.
What is the capital of France? The capital of France is Paris. What is the capital of Germany? The capital of Germany is Berlin. What is the capital of Japan? The capital of Japan is Tokyo. What is the capital of Australia? The capital of Australia is Canberra. What is the capital of Brazil? The capital of Brazil is Brasilia. What is the capital of Canada? The capital of Canada is Ottawa.
What is Python? Python is a high-level programming language used for data science, web development, and automation. Python was created by Guido van Rossum and first released in 1991.
What is gravity? Gravity is a force attracting objects with mass toward one another. Einstein described gravity as the curvature of spacetime caused by mass and energy. Newton described gravity as a force proportional to mass and inversely proportional to the square of distance.
What is a black hole? A black hole is a region of spacetime where gravity is so strong that nothing, not even light, can escape. Black holes form when massive stars collapse at the end of their lives. The boundary of a black hole is called the event horizon.
What is time dilation? Time dilation is the difference in elapsed time measured by two clocks due to relative velocity or gravitational potential. Time passes more slowly near massive objects and at high velocities.
What is the speed of light? The speed of light in a vacuum is approximately 299,792,458 metres per second. Nothing with mass can reach or exceed this speed. The speed of light is denoted by the letter c.
What is quantum mechanics? Quantum mechanics is the branch of physics describing the behaviour of matter and energy at atomic and subatomic scales. It introduces concepts such as wave-particle duality and the uncertainty principle.
What is the Milky Way? The Milky Way is the galaxy containing our solar system. It is a barred spiral galaxy with hundreds of billions of stars. The Milky Way is approximately 100,000 light-years in diameter.
What is DNA? DNA is a molecule that carries the genetic instructions for the development, functioning, growth, and reproduction of all known organisms. DNA stands for deoxyribonucleic acid.
What is photosynthesis? Photosynthesis is the process by which plants use sunlight, water, and carbon dioxide to produce oxygen and energy in the form of glucose.
What is the theory of evolution? The theory of evolution states that all species of organisms arise and develop through the natural selection of small, inherited variations that increase the ability to compete, survive, and reproduce.
What is the periodic table? The periodic table is a tabular arrangement of chemical elements ordered by atomic number, electron configuration, and recurring chemical properties.
What is artificial intelligence? Artificial intelligence is the simulation of human intelligence processes by computer systems, including learning, reasoning, and self-correction.
What is the internet? The internet is a global network of interconnected computers that communicate using standardised protocols. It was developed from ARPANET in the late 1960s.
What is climate change? Climate change refers to long-term shifts in global temperatures and weather patterns. Since the industrial revolution, human activities have been the main driver of climate change.
What is the human brain? The human brain is the central organ of the nervous system. It controls thought, memory, emotion, touch, motor skills, vision, breathing, and every process that regulates the body.
What is electricity? Electricity is the flow of electric charge through a conductor. It powers modern civilisation and is generated from sources including fossil fuels, nuclear energy, and renewables.
What is democracy? Democracy is a system of government in which power is vested in the people, who rule either directly or through freely elected representatives.
What is the solar system? The solar system consists of the Sun and the objects that orbit it, including eight planets, their moons, dwarf planets, asteroids, and comets.""".strip()

tokens=tokenise(CORPUS)
pairs=[(tokens[i-CTX:i],tokens[i]) for i in range(CTX,len(tokens))]
model=MiniTransformer(VOCAB_SIZE,D,HEADS,BLOCKS,FFN_D,CTX)

try:
    w=np.load('claude_v4_snapshot.npz')
    model.We=w['We']; model.Wo=w['Wo']; model.bo=w['bo']
    for i,blk in enumerate(model.blocks):
        for k in blk.p: blk.p[k]=w[f'blk{i}_{k}']
    print("  Loaded existing weights — continuing training...")
except Exception as e:
    print(f"  Starting fresh ({e})")

total_steps=100*len(pairs)//BATCH

print("╔══════════════════════════════════════════════════════════╗")
print("║  Claude v4 (tiktoken BPE + embedding lookup + sinPE)   ║")
print("╚══════════════════════════════════════════════════════════╝")
print(f"  vocab={VOCAB_SIZE}  d={D}  heads={HEADS}  blocks={BLOCKS}  ctx={CTX}  batch={BATCH}")
print(f"  corpus={len(CORPUS)} chars  tokens={len(tokens)}  samples={len(pairs)}")

EPOCHS=300; PATIENCE=20; best=float('inf'); no_imp=0; step=0
print(f"\n  Training up to {EPOCHS} epochs (early stop patience={PATIENCE})...")
for epoch in range(EPOCHS):
    idxs=np.random.permutation(len(pairs)); total=0.0
    for b_start in range(0,len(idxs),BATCH):
        batch=idxs[b_start:b_start+BATCH]
        for i in batch:
            ctx_toks,tgt=pairs[i]
            model.forward(ctx_toks); total+=model.loss(tgt); model.backward(tgt)
        lr=cosine_lr(step,total_steps); model.apply(lr); step+=1
    avg=total/len(pairs)
    mark='↓' if avg<best else ' '
    print(f"    epoch {epoch+1:>3}  loss={avg:.4f} {mark}  lr={cosine_lr(step,total_steps):.6f}")
    if avg<best-1e-4:
        best=avg; no_imp=0
        weights={'We':model.We,'Wo':model.Wo,'bo':model.bo}
        for i,blk in enumerate(model.blocks):
            for k in blk.p: weights[f'blk{i}_{k}']=blk.p[k]
        np.savez('claude_v4_snapshot.npz',**weights)
    else:
        no_imp+=1
        if no_imp>=PATIENCE:
            print(f"  Early stop at epoch {epoch+1}"); break

TRAINING=False
def generate(seed,n=60,temperature=0.8):
    toks=tokenise(seed)
    ctx=([0]*CTX+toks)[-CTX:]
    out=list(toks)
    for _ in range(n):
        probs=model.forward(ctx)
        probs=np.clip(probs,1e-9,None); probs=probs**(1/temperature); probs/=probs.sum()
        if np.any(np.isnan(probs)): probs=np.ones(VOCAB_SIZE)/VOCAB_SIZE
        nxt=int(np.random.choice(VOCAB_SIZE,p=probs))
        out.append(nxt); ctx=ctx[1:]+[nxt]
    return detokenise(out)

print(f"\n  Generation (temperature=0.8):")
for seed in ["What is","Python is","The capital"]:
    print(f"    [{seed!r}] → '{generate(seed,n=40)}'")
print(f"\n  Best loss: {best:.4f} → saved to claude_v4_snapshot.npz")
