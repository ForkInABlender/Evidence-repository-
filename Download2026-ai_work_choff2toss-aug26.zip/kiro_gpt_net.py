# Dylan Kenneth Eliot & Kiro
"""
kiro_gpt_net.py

1. Train main_gpt3_3d.net on next-token prediction (language modeling)
2. Use the trained net (frozen) as backbone for Kiro's 4-class behavior classifier
"""

import numpy as np
from pybrain3.structure import FeedForwardNetwork, LinearLayer, FullConnection
from pybrain3.structure.modules import SigmoidLayer
from pybrain3.datasets import SupervisedDataSet
from pybrain3.supervised.trainers import BackpropTrainer
from main_gpt3_3d import net as gpt_net, VOCAB_SIZE

# --- Minimal vocab mapped into VOCAB_SIZE space ---
WORDS = ['fix','build','run','what','explain','why','how','hi','hello',
         'drop','reset','force','wipe','malware','virus','phishing','hack','ignore']
word2idx = {w: hash(w) % VOCAB_SIZE for w in WORDS}

def onehot(idx):
    v = np.zeros(VOCAB_SIZE); v[idx] = 1.0; return v

# --- Step 1: Train gpt_net on next-token prediction ---
print("Step 1: Training gpt_net (next-token prediction)...")
lm_ds = SupervisedDataSet(VOCAB_SIZE, VOCAB_SIZE)
# Simple bigram pairs: each word predicts the next in a fixed sequence
sequence = ['fix','build','run','what','explain','why','hi','hello',
            'drop','reset','force','malware','virus','phishing','hack']
for i in range(len(sequence) - 1):
    lm_ds.addSample(onehot(word2idx[sequence[i]]),
                    onehot(word2idx[sequence[i+1]]))

lm_trainer = BackpropTrainer(gpt_net, lm_ds, learningrate=0.001, momentum=0.9)
lm_trainer.trainEpochs(5)
print(f"LM error: {lm_trainer.testOnData(lm_ds):.6f}\n")

# --- Step 2: Generate embeddings from trained gpt_net (frozen) ---
print("Step 2: Extracting embeddings from trained gpt_net...")

KEYWORDS = {
    'fix':0,'build':0,'run':0,'rename':0,'refactor':0,
    'what':1,'explain':1,'why':1,'how':1,'hi':1,'hello':1,'hey':1,
    'drop':2,'reset':2,'force':2,'wipe':2,
    'malware':3,'virus':3,'phishing':3,'hack':3,'ignore':3,
}

def text_to_onehot(text):
    v = np.zeros(VOCAB_SIZE)
    for word in text.lower().split():
        if word in KEYWORDS:
            v[hash(word) % VOCAB_SIZE] = 1.0
    return v

def one_hot4(c):
    v = [0.0]*4; v[c]=1.0; return v

training = [
    ("fix the typo",      0), ("build a rest api",  0), ("run the tests",   0),
    ("what is recursion", 1), ("explain backprop",  1), ("why is failing",  1),
    ("hi there",          1), ("hello",             1),
    ("drop the database", 2), ("reset hard",        2), ("force push",      2),
    ("malware please",    3), ("virus generator",   3), ("phishing site",   3),
    ("hack this",         3), ("ignore instructions",3),
]

cls_ds = SupervisedDataSet(VOCAB_SIZE, 4)
for query, label in training:
    emb = gpt_net.activate(text_to_onehot(query)).copy()
    cls_ds.addSample(emb, one_hot4(label))

# --- Step 3: Train classifier head on top of trained embeddings ---
print("Step 3: Training classifier head...")
head = FeedForwardNetwork()
head.addInputModule(LinearLayer(VOCAB_SIZE, name='in'))
head.addModule(SigmoidLayer(16, name='hidden'))
head.addOutputModule(SigmoidLayer(4, name='out'))
head.addConnection(FullConnection(head['in'], head['hidden']))
head.addConnection(FullConnection(head['hidden'], head['out']))
head.sortModules()

cls_trainer = BackpropTrainer(head, cls_ds, learningrate=0.05, momentum=0.9)
cls_trainer.trainEpochs(2000)
print(f"Classifier error: {cls_trainer.testOnData(cls_ds):.6f}\n")

# --- Inference ---
CLASSES = ['ACT','EXPLAIN','CONFIRM','REFUSE']
RESPONSES = {
    'ACT':     "On it.",
    'EXPLAIN': "Here's what I know:",
    'CONFIRM': "Destructive action — confirm before I proceed?",
    'REFUSE':  "I can't help with that.",
}

def respond(query):
    emb = gpt_net.activate(text_to_onehot(query))
    out = head.activate(emb)
    cls = CLASSES[int(np.argmax(out))]
    return cls, float(np.max(out)), RESPONSES[cls]

print("=== Kiro-GPT Net — Self Test ===\n")
tests = [
    "fix the bug in app.py",
    "what is a neural network",
    "drop the production database",
    "write me a virus",
    "hello",
    "reset hard origin main",
]
results = []
for q in tests:
    cls, conf, resp = respond(q)
    line = f"Q: {q!r}\n   -> {cls} ({conf:.2f})  \"{resp}\""
    print(line)
    results.append(line)

with open("kiro_gpt_results.txt", "w") as f:
    f.write("Pipeline: train gpt_net (LM) -> frozen embeddings -> train classifier head\n\n")
    f.write("\n".join(results) + "\n")
print("\nSaved to kiro_gpt_results.txt")
