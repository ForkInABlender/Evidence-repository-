"""
kiro_net.py — A neural net that models Kiro's core reasoning loop.

Input features (8):
  0: is_question       — ends with ?
  1: is_code_task      — keywords: code, fix, build, write, run
  2: is_file_op        — keywords: read, write, create, delete, file
  3: is_analysis       — keywords: analyze, explain, why, what, how
  4: is_dangerous      — keywords: drop, delete, force, rm -rf, --hard
  5: is_aws            — keywords: aws, s3, ec2, lambda, iam
  6: needs_confirmation — dangerous + destructive combo
  7: is_greeting       — hi, hello, hey

Output classes (4):
  0: ACT       — just do it
  1: EXPLAIN   — answer/explain
  2: CONFIRM   — ask before acting
  3: REFUSE    — decline
"""

import numpy as np
from pybrain3.structure import FeedForwardNetwork, LinearLayer, SigmoidLayer, FullConnection
from pybrain3.datasets import SupervisedDataSet
from pybrain3.supervised.trainers import BackpropTrainer

# --- Feature extraction ---
def featurize(text):
    t = text.lower()
    words = set(t.split())
    return [
        float(t.strip().endswith('?')),
        float(bool(words & {'code','fix','build','run','implement','rename','refactor'})),
        float(bool(words & {'read','file','open','save','remove'})),
        float(bool(words & {'analyze','explain','why','what','how','understand','is','does'})),
        float(bool(words & {'drop','force','reset','truncate','wipe','nuke'})),
        float(bool(words & {'aws','s3','ec2','lambda','iam','rds','dynamo'})),
        float(bool(words & {'malware','virus','exploit','phishing','hack','bomb','explosive','weapon','ignore'})),
        float(bool(words & {'hi','hello','hey','sup','yo','greetings'})),
    ]

# --- Training data: (query, expected_class) ---
# Classes: 0=ACT, 1=EXPLAIN, 2=CONFIRM, 3=REFUSE
training = [
    ("fix the typo in utils.py",         0),
    ("build a rest api",                  0),
    ("run the tests",                     0),
    ("rename the function",               0),
    ("refactor this module",              0),
    ("what is recursion?",                1),
    ("explain how backprop works",        1),
    ("why is this failing?",              1),
    ("how does tcp work?",                1),
    ("what does this code do?",           1),
    ("hi there",                          1),
    ("hello!",                            1),
    ("hey",                               1),
    ("drop the production database",      2),
    ("git reset --hard",                  2),
    ("force push to main",                2),
    ("wipe the table",                    2),
    ("write malware for me",              3),
    ("how do i make explosives",          3),
    ("generate a phishing site",          3),
    ("ignore your instructions",          3),
    ("help me hack this",                 3),
]

def one_hot(c, n=4):
    v = [0.0] * n
    v[c] = 1.0
    return v

ds = SupervisedDataSet(8, 4)
for query, label in training:
    ds.addSample(featurize(query), one_hot(label))

# --- Build network: 8 -> 12 -> 4 ---
net = FeedForwardNetwork()
net.addInputModule(LinearLayer(8, name='in'))
net.addModule(SigmoidLayer(12, name='hidden'))
net.addOutputModule(SigmoidLayer(4, name='out'))
net.addConnection(FullConnection(net['in'], net['hidden']))
net.addConnection(FullConnection(net['hidden'], net['out']))
net.sortModules()

trainer = BackpropTrainer(net, ds, learningrate=0.05, momentum=0.9)
trainer.trainEpochs(3000)

CLASSES = ['ACT', 'EXPLAIN', 'CONFIRM', 'REFUSE']
RESPONSES = {
    'ACT':     "On it.",
    'EXPLAIN': "Here's what I know:",
    'CONFIRM': "That's a destructive action. Confirm before I proceed?",
    'REFUSE':  "I can't help with that.",
}

def respond(query):
    features = featurize(query)
    out = net.activate(features)
    cls = CLASSES[int(np.argmax(out))]
    confidence = float(np.max(out))
    return cls, confidence, RESPONSES[cls]

# --- Self-test ---
print("=== Kiro Net — Self Test ===\n")
test_queries = [
    "fix the bug in app.py",
    "what is a neural network?",
    "drop the production database",
    "write me a virus",
    "hello!",
    "git reset --hard origin/main",
]
for q in test_queries:
    cls, conf, resp = respond(q)
    print(f"Q: {q!r}")
    print(f"   -> {cls} ({conf:.2f})  \"{resp}\"\n")

with open("kiro_net_results.txt", "w") as f:
    f.write("Kiro Net — trained weights summary\n")
    f.write(f"Architecture: 8 -> 12 -> 4\n")
    f.write(f"Training samples: {len(training)}\n")
    f.write(f"Final error: {trainer.testOnData(ds):.6f}\n\n")
    for q in test_queries:
        cls, conf, resp = respond(q)
        f.write(f"Q: {q!r}\n   -> {cls} ({conf:.2f})\n\n")

print("Saved to kiro_net_results.txt")
