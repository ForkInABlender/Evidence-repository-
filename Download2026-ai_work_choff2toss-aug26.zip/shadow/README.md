# BES Encryption
---
Black Army Encryption Standard. 
---
This software will leverage a wide range of features to encrypt data and hide it in a png image:
```
ML‑KEM‑768
AES‑256‑GCM
AES‑256‑CTR
Rubik’s cube cipher
XOR keystream
S‑box substitution 
GF(256) linear mixing
GCM authentication
Entropy harvesting
Deterministic entropy pools
ASCII‑to‑32‑bit mapping
2D differential transform
Affine and bit‑rotation transforms
Face & column/row permutations
Inter‑face arithmetic
Chunked processing
Zlib compression
PNG LSB steganography
PBKDF2‑HMAC‑SHA256
GF(256) matrix operations
Constant‑time implementation
Parallel entropy collection
Termios password hiding
File existence & metadata validation
Deterministic PRNG (xorshift64*) 
Linear Algebra
SHA‑256 
No temp files, all in memory
Various techniques to wipe memory after use.
```
Where is your God now?

Download code, build, install and clean:
---
```
git clone git@gitee.com:teamsloth/shadow.git; cd shadow; sudo make install clean
```

Usage:
---
1.- Key Generation
```
$ shadow -g alice
Generating ML‑KEM‑768 key pair for 'alice'...
Keys generated successfully:
  Public key:  alice.pub (1184 bytes)
  Secret key:  alice.sec (3584 bytes)
```

2.- Create or move to a folder for private key.
```
$ mkdir keys; chmod 700 keys;
$ mv alice.sec keys/; chmod 600 keys/alice.sec
```

3.- To encrypt a file like secret.txt with an image like carrier.png:
```
shadow -e -f secret.txt -s carrier.png -o stego.png -r alice.pub
```

4.- To decrypt the message:
```
shadow -d -i stego.png -x -o recovered.txt -k keys
```

5.- Multi-Recipient Behavior

You can encrypt for any number of recipients:
```
$ shadow -e -f secret.txt -s carrier.png -o stego.png -r alice.pub -r bob.pub -r jim.pub
```
Each recipient can independently decrypt using their own .sec. 

Only the embedded image and public key are needed to decrypt. 

Once you are done with a recovered message, the following would be good to ensure forensics are not found on disk:
```
$ bleachbit --shred recovered.txt 
Delete 4.1kB /home/user/shadow/recovered.txt
Disk space recovered: 4.1kB
Files deleted: 1
```

Limitations:
---
1.- You will not be able to fit an elephant in a dog house. The larger the encrypted data, the large of an image you will need to embed it into. Try a wallpaper images with high resolution to hold more data.

2.- This software only encrypts into png images. There is no support for jpgs, gifs or other formats yet. However, many online tools will help convert other formats to png.

3.- Some of the entropy techniques will only work on x86_64. This may still work other platforms, but entropy may be missing or behavior may become unpredictable. If you do not have x86_64, you should run this in a x86_64 virtual machine instead. 

4.- This was built on Linux. It might work on other Operating Systems, but support and its behavior is not promised at this time. 

5.- To prevent any side-channel attacks, do not use swap with this software. Either disable swap or use zram and ensure the following command returns 'none':
```
$ cat /sys/block/zram0/backing_dev 
none
```

Donations:
---
This software is, and will remain, free. If you value it, want it maintained regularly and/or want improvements of new features added, donations are key. Monero payments may be sent to the following address.
```
47EE8uDmCjxRi7Wrwj3uGjDigVehMyFRuVRLskyg5rUGY3LuKmVWsWPGPzibYGjyTeDcxyPzDky6qSGfYd1prfe6C2Ld3sM
```
