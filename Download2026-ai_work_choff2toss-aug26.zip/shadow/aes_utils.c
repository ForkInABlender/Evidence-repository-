#include "aes_utils.h"
#include <openssl/evp.h>
#include <openssl/crypto.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void aes_gcm_encrypt(const uint8_t *in, uint8_t *out, size_t len,
                     const uint8_t *key, const uint8_t *iv,
                     uint8_t *tag_out) {
    EVP_CIPHER_CTX *ctx = EVP_CIPHER_CTX_new();
    if (!ctx) { fprintf(stderr, "EVP_CIPHER_CTX_new failed\n"); exit(EXIT_FAILURE); }

    if (EVP_EncryptInit_ex(ctx, EVP_aes_256_gcm(), NULL, NULL, NULL) != 1 ||
        EVP_EncryptInit_ex(ctx, NULL, NULL, key, iv) != 1) {
        fprintf(stderr, "EVP_EncryptInit_ex failed\n");
        EVP_CIPHER_CTX_free(ctx);
        exit(EXIT_FAILURE);
    }

    int outlen;
    if (EVP_EncryptUpdate(ctx, out, &outlen, in, len) != 1) {
        fprintf(stderr, "EVP_EncryptUpdate failed\n");
        EVP_CIPHER_CTX_free(ctx);
        exit(EXIT_FAILURE);
    }

    if (EVP_EncryptFinal_ex(ctx, out + outlen, &outlen) != 1) {
        fprintf(stderr, "EVP_EncryptFinal_ex failed\n");
        EVP_CIPHER_CTX_free(ctx);
        exit(EXIT_FAILURE);
    }

    if (EVP_CIPHER_CTX_ctrl(ctx, EVP_CTRL_GCM_GET_TAG, AES_GCM_TAGLEN, tag_out) != 1) {
        fprintf(stderr, "EVP_CIPHER_CTX_ctrl get tag failed\n");
        EVP_CIPHER_CTX_free(ctx);
        exit(EXIT_FAILURE);
    }

    EVP_CIPHER_CTX_free(ctx);
    
    // Clear sensitive data from stack (though OpenSSL may have copies)
    OPENSSL_cleanse(&outlen, sizeof(outlen));
}

int aes_gcm_decrypt(const uint8_t *in, uint8_t *out, size_t len,
                    const uint8_t *key, const uint8_t *iv,
                    const uint8_t *tag) {
    EVP_CIPHER_CTX *ctx = EVP_CIPHER_CTX_new();
    if (!ctx) return -1;

    if (EVP_DecryptInit_ex(ctx, EVP_aes_256_gcm(), NULL, NULL, NULL) != 1 ||
        EVP_DecryptInit_ex(ctx, NULL, NULL, key, iv) != 1) {
        EVP_CIPHER_CTX_free(ctx);
        return -1;
    }

    int outlen;
    if (EVP_DecryptUpdate(ctx, out, &outlen, in, len) != 1) {
        EVP_CIPHER_CTX_free(ctx);
        return -1;
    }

    if (EVP_CIPHER_CTX_ctrl(ctx, EVP_CTRL_GCM_SET_TAG, AES_GCM_TAGLEN, (void*)tag) != 1) {
        EVP_CIPHER_CTX_free(ctx);
        return -1;
    }

    int ret = EVP_DecryptFinal_ex(ctx, out + outlen, &outlen);
    EVP_CIPHER_CTX_free(ctx);
    
    // Clear sensitive data
    OPENSSL_cleanse(&outlen, sizeof(outlen));
    
    return (ret == 1) ? 0 : -1;
}
