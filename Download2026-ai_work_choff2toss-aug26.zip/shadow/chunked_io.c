#define _POSIX_C_SOURCE 200809L
#include "chunked_io.h"
#include "crypto_core.h"
#include "aes_utils.h"
#include "stego_util.h"
#include "utils.h"
#include "entropy.h"
#include "encoding.h"
#include "entropy_pool.h"
#include "crypto_utils.h"
#include <oqs/oqs.h>
#include <zlib.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <termios.h>
#include <openssl/evp.h>
#include <openssl/rand.h>
#include <openssl/kdf.h>
#include <openssl/crypto.h>
#include <dirent.h>

#define OUTER_AES_KEYLEN 32
#define OUTER_IVLEN 12
#define OUTER_TAGLEN 16
#define OUTER_MAGIC 0x4F555445
#define OUTER_VERSION 4
#define ENCODED_MATRIX_SIZE 64
#define TOTAL_CELLS (6 * ENCODED_MATRIX_SIZE * ENCODED_MATRIX_SIZE)
#define TOTAL_BYTES (TOTAL_CELLS * sizeof(uint32_t))

// Use the new ML‑KEM names if available, otherwise fall back to Kyber names
#ifdef OQS_KEM_ml_kem_768_length_public_key
    #define KEM_PUBKEY_LEN OQS_KEM_ml_kem_768_length_public_key
    #define KEM_SECKEY_LEN OQS_KEM_ml_kem_768_length_secret_key
    #define KEM_CIPHER_LEN OQS_KEM_ml_kem_768_length_ciphertext
#else
    #define KEM_PUBKEY_LEN OQS_KEM_kyber_768_length_public_key
    #define KEM_SECKEY_LEN OQS_KEM_kyber_768_length_secret_key
    #define KEM_CIPHER_LEN OQS_KEM_kyber_768_length_ciphertext
#endif

/* Limit recipients to prevent integer overflow / DoS */
#define MAX_RECIPIENTS 1024

static void sha256(uint8_t *out, const uint8_t *in, size_t len) {
    EVP_MD_CTX *ctx = EVP_MD_CTX_new();
    EVP_DigestInit_ex(ctx, EVP_sha256(), NULL);
    EVP_DigestUpdate(ctx, in, len);
    EVP_DigestFinal_ex(ctx, out, NULL);
    EVP_MD_CTX_free(ctx);
}

static void kdf(uint8_t *out, size_t out_len, const uint8_t *in, size_t in_len, const char *salt) {
    EVP_MD_CTX *ctx = EVP_MD_CTX_new();
    EVP_DigestInit_ex(ctx, EVP_sha256(), NULL);
    EVP_DigestUpdate(ctx, in, in_len);
    EVP_DigestUpdate(ctx, salt, strlen(salt));
    uint8_t tmp[32];
    EVP_DigestFinal_ex(ctx, tmp, NULL);
    EVP_MD_CTX_free(ctx);
    memcpy(out, tmp, out_len < 32 ? out_len : 32);
}

static void prompt_password(const char *prompt, char *password, size_t max_len) {
    fprintf(stderr, "%s", prompt);
    fflush(stderr);
    struct termios old, new;
    tcgetattr(STDIN_FILENO, &old);
    new = old;
    new.c_lflag &= ~ECHO;
    tcsetattr(STDIN_FILENO, TCSANOW, &new);
    if (!fgets(password, max_len, stdin)) {
        password[0] = '\0';
    } else {
        size_t len = strlen(password);
        if (len > 0 && password[len-1] == '\n') password[len-1] = '\0';
    }
    tcsetattr(STDIN_FILENO, TCSANOW, &old);
    fprintf(stderr, "\n");
}

static int derive_key_from_password(const char *password, uint8_t salt[16],
                                     uint8_t *key_out, int do_gen_salt) {
    if (do_gen_salt) {
        if (RAND_bytes(salt, 16) != 1) return -1;
    }
    if (PKCS5_PBKDF2_HMAC(password, strlen(password), salt, 16, 100000,
                          EVP_sha256(), 32, key_out) != 1) return -1;
    return 0;
}

int save_outer_encrypted_multi(const char *path, const uint8_t *inner_data, size_t inner_len,
                               char **pubkey_paths, int num_recipients) {
    if (num_recipients <= 0 || num_recipients > MAX_RECIPIENTS) return -1;

    // ----- Compress inner_data -----
    uLongf compressed_len = compressBound(inner_len);
    uint8_t *compressed = malloc(compressed_len + 10);
    if (!compressed) return -1;

    compressed[0] = 'Z';
    compressed[1] = 'L';
    uint32_t orig_size = inner_len;
    memcpy(compressed + 2, &orig_size, 4);

    int ret = compress2(compressed + 10, &compressed_len,
                        (const Bytef*)inner_data, inner_len,
                        9);
    if (ret != Z_OK) {
        free(compressed);
        return -1;
    }
    uint32_t comp_len32 = compressed_len;
    memcpy(compressed + 6, &comp_len32, 4);
    size_t total_len = 10 + compressed_len;

    OQS_KEM *kem = OQS_KEM_new(KEM_ALG);
    if (!kem) { free(compressed); return -1; }

    uint8_t aes_key[32], iv[12];
    if (RAND_bytes(aes_key, 32) != 1 || RAND_bytes(iv, 12) != 1) {
        OQS_KEM_free(kem); free(compressed); return -1;
    }

    uint8_t *ciphertext = malloc(total_len);
    uint8_t tag[16];
    if (!ciphertext) { OQS_KEM_free(kem); free(compressed); return -1; }
    EVP_CIPHER_CTX *ctx = EVP_CIPHER_CTX_new();
    if (!ctx) { free(ciphertext); OQS_KEM_free(kem); free(compressed); return -1; }
    int outlen;
    int enc_ret = EVP_EncryptInit_ex(ctx, EVP_aes_256_gcm(), NULL, aes_key, iv) &&
                  EVP_EncryptUpdate(ctx, ciphertext, &outlen, compressed, total_len) &&
                  EVP_EncryptFinal_ex(ctx, ciphertext + outlen, &outlen) &&
                  EVP_CIPHER_CTX_ctrl(ctx, EVP_CTRL_GCM_GET_TAG, 16, tag);
    EVP_CIPHER_CTX_free(ctx);
    if (!enc_ret) { free(ciphertext); OQS_KEM_free(kem); free(compressed); return -1; }

    size_t header_size = 4 + 4 + 4;
    size_t recipient_size = 32 + KEM_CIPHER_LEN + 32;
    size_t total_out_len = header_size + num_recipients * recipient_size + 12 + total_len + 16;
    uint8_t *out_buf = malloc(total_out_len);
    if (!out_buf) { free(ciphertext); OQS_KEM_free(kem); free(compressed); return -1; }
    uint8_t *ptr = out_buf;

    put_u32(ptr, OUTER_MAGIC); ptr += 4;
    put_u32(ptr, OUTER_VERSION); ptr += 4;
    put_u32(ptr, num_recipients); ptr += 4;

    for (int i = 0; i < num_recipients; i++) {
        FILE *f = fopen(pubkey_paths[i], "rb");
        if (!f) { free(out_buf); free(ciphertext); OQS_KEM_free(kem); free(compressed); return -1; }
        uint8_t *pub = malloc(KEM_PUBKEY_LEN);
        if (fread(pub, 1, KEM_PUBKEY_LEN, f) != KEM_PUBKEY_LEN) {
            free(pub); fclose(f); free(out_buf); free(ciphertext); OQS_KEM_free(kem); free(compressed); return -1;
        }
        fclose(f);
        uint8_t pub_hash[32];
        sha256(pub_hash, pub, KEM_PUBKEY_LEN);
        memcpy(ptr, pub_hash, 32); ptr += 32;
        uint8_t *cipher = malloc(KEM_CIPHER_LEN);
        uint8_t shared_secret[32];
        if (OQS_KEM_encaps(kem, cipher, shared_secret, pub) != OQS_SUCCESS) {
            free(pub); free(cipher); free(out_buf); free(ciphertext); OQS_KEM_free(kem); free(compressed); return -1;
        }
        memcpy(ptr, cipher, KEM_CIPHER_LEN); ptr += KEM_CIPHER_LEN;
        free(cipher);
        uint8_t wrap_key[32];
        kdf(wrap_key, 32, shared_secret, 32, "wrap");
        for (int j = 0; j < 32; j++) wrap_key[j] ^= aes_key[j];
        memcpy(ptr, wrap_key, 32); ptr += 32;
        free(pub);
    }
    memcpy(ptr, iv, 12); ptr += 12;
    memcpy(ptr, ciphertext, total_len); ptr += total_len;
    memcpy(ptr, tag, 16);
    free(ciphertext);
    free(compressed);

    FILE *fp = fopen(path, "wb");
    if (!fp) { free(out_buf); OQS_KEM_free(kem); return -1; }
    fwrite(out_buf, 1, total_out_len, fp);
    fclose(fp);
    free(out_buf);
    OQS_KEM_free(kem);
    return 0;
}

int load_outer_encrypted_multi(const char *path, uint8_t **out_data, size_t *out_len,
                               const char *keydir) {
    FILE *fp = fopen(path, "rb");
    if (!fp) { perror("fopen"); return -1; }
    
    uint8_t hdr[12];
    if (fread(hdr, 1, 12, fp) != 12) { fclose(fp); return -1; }
    uint32_t magic = get_u32(hdr);
    uint32_t version = get_u32(hdr + 4);
    uint32_t num_recipients = get_u32(hdr + 8);
    if (magic != OUTER_MAGIC || version != OUTER_VERSION) {
        fclose(fp); return -1;
    }
    // Validate number of recipients
    if (num_recipients == 0 || num_recipients > MAX_RECIPIENTS) {
        fclose(fp); return -1;
    }
    size_t recipient_size = 32 + KEM_CIPHER_LEN + 32;
    // Check multiplication overflow
    if (num_recipients > SIZE_MAX / recipient_size) {
        fclose(fp); return -1;
    }
    
    uint8_t *recip_blocks = malloc(num_recipients * recipient_size);
    if (!recip_blocks) { fclose(fp); return -1; }
    
    size_t bytes_to_read = num_recipients * recipient_size;
    if (fread(recip_blocks, 1, bytes_to_read, fp) != bytes_to_read) {
        free(recip_blocks); fclose(fp); return -1;
    }
    
    uint8_t iv[12];
    if (fread(iv, 1, 12, fp) != 12) { free(recip_blocks); fclose(fp); return -1; }
    
    // Get file size
    fseek(fp, 0, SEEK_END);
    long file_size = ftell(fp);
    
    // Compute ciphertext offset (after header, recipient blocks, and IV)
    off_t cipher_offset = 12 + num_recipients * recipient_size + 12;
    // FIX: Ensure enough bytes remain for the authentication tag (16 bytes)
    if (cipher_offset >= file_size || file_size - cipher_offset < 16) {
        free(recip_blocks); fclose(fp); return -1;
    }
    size_t cipher_len = file_size - cipher_offset - 16;
    
    // Seek to ciphertext start
    if (fseek(fp, cipher_offset, SEEK_SET) != 0) {
        free(recip_blocks); fclose(fp); return -1;
    }
    
    uint8_t *ciphertext = malloc(cipher_len);
    uint8_t tag[16];
    if (!ciphertext) { free(recip_blocks); fclose(fp); return -1; }
    if (fread(ciphertext, 1, cipher_len, fp) != cipher_len) {
        free(recip_blocks); free(ciphertext); fclose(fp); return -1;
    }
    if (fread(tag, 1, 16, fp) != 16) {
        free(recip_blocks); free(ciphertext); fclose(fp); return -1;
    }
    fclose(fp);
    
    OQS_KEM *kem = OQS_KEM_new(KEM_ALG);
    if (!kem) { free(recip_blocks); free(ciphertext); return -1; }
    
    DIR *dir = opendir(keydir);
    if (!dir) { free(recip_blocks); free(ciphertext); OQS_KEM_free(kem); return -1; }
    
    uint8_t aes_key[32];
    int found = 0;
    struct dirent *entry;
    
    while ((entry = readdir(dir)) != NULL) {
        if (!strstr(entry->d_name, ".sec")) continue;
        char secpath[512];
        snprintf(secpath, sizeof(secpath), "%s/%s", keydir, entry->d_name);
        FILE *sf = fopen(secpath, "rb");
        if (!sf) { perror("fopen"); continue; }
        uint8_t *pub = malloc(KEM_PUBKEY_LEN);
        uint8_t *sec = malloc(KEM_SECKEY_LEN);
        size_t read_pub = fread(pub, 1, KEM_PUBKEY_LEN, sf);
        size_t read_sec = fread(sec, 1, KEM_SECKEY_LEN, sf);
        fclose(sf);
        if (read_pub != KEM_PUBKEY_LEN || read_sec != KEM_SECKEY_LEN) {
            fprintf(stderr, "    read_pub=%zu (expected %d), read_sec=%zu (expected %d)\n",
                    read_pub, KEM_PUBKEY_LEN, read_sec, KEM_SECKEY_LEN);
            free(pub); free(sec);
            continue;
        }
        uint8_t pub_hash[32];
        sha256(pub_hash, pub, KEM_PUBKEY_LEN);
        for (uint32_t i = 0; i < num_recipients; i++) {
            uint8_t *rec = recip_blocks + i * recipient_size;
            if (ct_memcmp(rec, pub_hash, 32) == 0) {
                uint8_t *cipher = rec + 32;
                uint8_t shared_secret[32];
                if (OQS_KEM_decaps(kem, shared_secret, cipher, sec) != OQS_SUCCESS) {
                    fprintf(stderr, "    Decapsulation failed\n");
                    break;
                }
                uint8_t wrap_key[32];
                kdf(wrap_key, 32, shared_secret, 32, "wrap");
                uint8_t *wrapped = rec + 32 + KEM_CIPHER_LEN;
                for (int j = 0; j < 32; j++) aes_key[j] = wrap_key[j] ^ wrapped[j];
                found = 1;
                break;
            }
        }
        free(pub); free(sec);
        if (found) break;
    } 
    closedir(dir);
    free(recip_blocks);
    if (!found) {
        fprintf(stderr, "=== ERROR: No matching secret key found in %s\n", keydir);
        free(ciphertext);
        OQS_KEM_free(kem);
        return -1;
    }

    uint8_t *plain_compressed = malloc(cipher_len);
    if (!plain_compressed) { free(ciphertext); OQS_KEM_free(kem); return -1; }
    EVP_CIPHER_CTX *ctx = EVP_CIPHER_CTX_new();
    if (!ctx) { free(ciphertext); free(plain_compressed); OQS_KEM_free(kem); return -1; }
    int outlen;
    int dec_ret = EVP_DecryptInit_ex(ctx, EVP_aes_256_gcm(), NULL, aes_key, iv) &&
                  EVP_DecryptUpdate(ctx, plain_compressed, &outlen, ciphertext, cipher_len) &&
                  EVP_CIPHER_CTX_ctrl(ctx, EVP_CTRL_GCM_SET_TAG, 16, tag) &&
                  EVP_DecryptFinal_ex(ctx, plain_compressed + outlen, &outlen);
    EVP_CIPHER_CTX_free(ctx);
    free(ciphertext);
    if (dec_ret != 1) { free(plain_compressed); OQS_KEM_free(kem); return -1; }

    // Decompress
    size_t decrypted_len = cipher_len;
    if (decrypted_len < 10) { free(plain_compressed); OQS_KEM_free(kem); return -1; }
    if (plain_compressed[0] != 'Z' || plain_compressed[1] != 'L') {
        free(plain_compressed); OQS_KEM_free(kem); return -1;
    }
    uint32_t orig_size, comp_size;
    memcpy(&orig_size, plain_compressed + 2, 4);
    memcpy(&comp_size, plain_compressed + 6, 4);
    if (orig_size > 100 * 1024 * 1024) { free(plain_compressed); OQS_KEM_free(kem); return -1; }
    uint8_t *decompressed = malloc(orig_size);
    if (!decompressed) { free(plain_compressed); OQS_KEM_free(kem); return -1; }
    uLongf decomp_len = orig_size;
    int zret = uncompress(decompressed, &decomp_len,
                          plain_compressed + 10, comp_size);
    free(plain_compressed);
    if (zret != Z_OK || decomp_len != orig_size) {
        free(decompressed); OQS_KEM_free(kem); return -1;
    }
    OPENSSL_cleanse(aes_key, sizeof(aes_key));
    OPENSSL_cleanse(iv, sizeof(iv));
    *out_data = decompressed;
    *out_len = orig_size;
    OQS_KEM_free(kem);
    return 0;
}

void do_encrypt_chunked(const char *input_file, const char *output_file,
                        char **pubkeys, int num_pubkeys) {
    // Read input file
    size_t file_len;
    uint8_t *file_data = read_file(input_file, &file_len);
    if (!file_data) die("read_file failed");

    // Generate base seed and deterministic entropy pools
    uint64_t base_seed;
    if (RAND_bytes((uint8_t*)&base_seed, 8) != 1) die("RAND_bytes base_seed");
    generate_entropy_pools_deterministic(base_seed);

    // Encode file to cubes (in memory)
    uint8_t *metadata = NULL;
    size_t cubes_len;
    uint8_t *cubes_data = encode_message_to_cubes((const char*)file_data, file_len,
                                                   base_seed, &metadata, &cubes_len);
    free(file_data);   // no longer needed

    // Compress cubes
    uLongf compressed_len = compressBound(cubes_len);
    uint8_t *compressed = malloc(compressed_len);
    if (!compressed) die("malloc");
    int ret = compress2(compressed, &compressed_len, cubes_data, cubes_len, 9);
    if (ret != Z_OK) die("Compression failed");
    free(cubes_data);

    // Prepend metadata (12 bytes)
    size_t plain_len = 12 + compressed_len;
    uint8_t *plain = malloc(plain_len);
    memcpy(plain, metadata, 12);
    memcpy(plain + 12, compressed, compressed_len);
    free(metadata);
    free(compressed);

    // Password encryption (AES‑GCM)
    char password[256], password_confirm[256];
    int password_matched = 0, attempts = 0;
    while (!password_matched && attempts < 3) {
        prompt_password("Enter password for file: ", password, sizeof(password));
        prompt_password("Confirm password: ", password_confirm, sizeof(password_confirm));
        if (strcmp(password, password_confirm) == 0) password_matched = 1;
        else {
            fprintf(stderr, "Passwords do not match.\n");
            OPENSSL_cleanse(password, sizeof(password));
            OPENSSL_cleanse(password_confirm, sizeof(password_confirm));
            attempts++;
        }
    }
    if (!password_matched) die("Too many attempts");
    OPENSSL_cleanse(password_confirm, sizeof(password_confirm));

    uint8_t salt[16], pw_key[32];
    if (derive_key_from_password(password, salt, pw_key, 1) != 0) die("Key derivation failed");
    OPENSSL_cleanse(password, sizeof(password));

    uint8_t iv[12];
    if (RAND_bytes(iv, 12) != 1) die("RAND_bytes iv");
    uint8_t *pw_ciphertext = malloc(plain_len + 16);
    uint8_t tag[16];
    aes_gcm_encrypt(plain, pw_ciphertext, plain_len, pw_key, iv, tag);
    OPENSSL_cleanse(pw_key, sizeof(pw_key));
    free(plain);

    size_t blob_len = 16 + 12 + 16 + plain_len;
    uint8_t *password_blob = malloc(blob_len);
    uint8_t *ptr = password_blob;
    memcpy(ptr, salt, 16); ptr += 16;
    memcpy(ptr, iv, 12);   ptr += 12;
    memcpy(ptr, tag, 16);  ptr += 16;
    memcpy(ptr, pw_ciphertext, plain_len);
    free(pw_ciphertext);

    // Chunked Rubik’s cube encryption (128 layers)
    init_entropy();
    cube_metadata_layers_t meta_layers;
    meta_layers.layer_count = 128;
    for (size_t layer = 0; layer < meta_layers.layer_count; layer++)
        generate_layer_metadata(&meta_layers.layers[layer]);

    uint64_t num_chunks = (blob_len + CUBE_CAPACITY - 1) / CUBE_CAPACITY;
    size_t total_chunk_data = num_chunks * (HMAC_TAGLEN + CUBE_CAPACITY);
    uint8_t *all_chunks = malloc(total_chunk_data);
    if (!all_chunks) die("malloc all_chunks");

    for (uint64_t chunk_idx = 0; chunk_idx < num_chunks; chunk_idx++) {
        size_t offset = chunk_idx * CUBE_CAPACITY;
        size_t chunk_len = (offset + CUBE_CAPACITY <= blob_len) ? CUBE_CAPACITY : blob_len - offset;

        uint8_t cube[6][MATRIX_SIZE][MATRIX_SIZE] = {{{0}}};
        memcpy(&cube[0][0][0], password_blob + offset, chunk_len);
        if (chunk_len < CUBE_CAPACITY)
            fill_with_entropy((uint8_t*)&cube[0][0][0] + chunk_len, CUBE_CAPACITY - chunk_len);

        uint8_t final_hmac_tag[HMAC_TAGLEN];
        for (size_t layer = 0; layer < meta_layers.layer_count; layer++) {
            shuffle_layer_t *sl = &meta_layers.layers[layer];
            uint8_t iv1[16], iv2[16], iv3[16];
            derive_ivs(sl->cbc_iv1, chunk_idx, layer, iv1, iv2, iv3);
            uint8_t *tag_ptr = (layer == meta_layers.layer_count - 1) ? final_hmac_tag : NULL;
            encrypt_cube_layer_ex(cube, sl, iv1, chunk_idx, tag_ptr);
        }

        uint8_t *chunk_ptr = all_chunks + chunk_idx * (HMAC_TAGLEN + CUBE_CAPACITY);
        memcpy(chunk_ptr, final_hmac_tag, HMAC_TAGLEN);
        memcpy(chunk_ptr + HMAC_TAGLEN, cube, sizeof(cube));
    }
    free(password_blob);

    // Outer Kyber‑AES encryption
    size_t meta_size = sizeof(cube_metadata_layers_t);
    size_t inner_len = meta_size + sizeof(num_chunks) + total_chunk_data + sizeof(blob_len);
    uint8_t *inner_data = malloc(inner_len);
    ptr = inner_data;
    memcpy(ptr, &meta_layers, meta_size); ptr += meta_size;
    memcpy(ptr, &num_chunks, sizeof(num_chunks)); ptr += sizeof(num_chunks);
    memcpy(ptr, all_chunks, total_chunk_data); ptr += total_chunk_data;
    memcpy(ptr, &blob_len, sizeof(blob_len));
    free(all_chunks);

    if (save_outer_encrypted_multi(output_file, inner_data, inner_len, pubkeys, num_pubkeys) != 0)
        die("Failed to save outer encrypted file");
    free(inner_data);
    cleanup_entropy();
}

void do_decrypt_chunked(const char *input_file, const char *output_file, const char *keydir) {
    // ----- Step 1: Outer decryption -----
    uint8_t *inner_data = NULL;
    size_t inner_len = 0;
    if (load_outer_encrypted_multi(input_file, &inner_data, &inner_len, keydir) != 0)
        die("Failed to load encrypted file (wrong keydir?)");

    // ----- Step 2: Recover layer metadata, chunks, blob length -----
    uint8_t *ptr = inner_data;
    cube_metadata_layers_t meta_layers;
    if (inner_len < sizeof(meta_layers)) die("Corrupted file");
    memcpy(&meta_layers, ptr, sizeof(meta_layers)); ptr += sizeof(meta_layers);

    uint64_t num_chunks;
    if (inner_len < (ptr - inner_data) + sizeof(num_chunks)) die("Missing chunk count");
    memcpy(&num_chunks, ptr, sizeof(num_chunks)); ptr += sizeof(num_chunks);

    size_t chunk_data_size = num_chunks * (HMAC_TAGLEN + CUBE_CAPACITY);
    if (inner_len < (ptr - inner_data) + chunk_data_size + sizeof(size_t)) die("Data size mismatch");
    const uint8_t *chunk_data_start = ptr;
    ptr += chunk_data_size;
    size_t password_blob_len;
    memcpy(&password_blob_len, ptr, sizeof(password_blob_len));

    // ----- Step 3: Decrypt each chunk (reverse cube layers) -----
    uint8_t *password_blob = malloc(password_blob_len);
    if (!password_blob) die("malloc");
    size_t recovered_pos = 0;
    for (uint64_t chunk_idx = 0; chunk_idx < num_chunks; chunk_idx++) {
        const uint8_t *chunk_ptr = chunk_data_start + chunk_idx * (HMAC_TAGLEN + CUBE_CAPACITY);
        const uint8_t *hmac_tag = chunk_ptr;
        const uint8_t *encrypted_cube = chunk_ptr + HMAC_TAGLEN;

        uint8_t cube[6][MATRIX_SIZE][MATRIX_SIZE];
        memcpy(cube, encrypted_cube, sizeof(cube));

        for (int layer = (int)meta_layers.layer_count - 1; layer >= 0; layer--) {
            shuffle_layer_t *sl = &meta_layers.layers[layer];
            uint8_t iv1[16], iv2[16], iv3[16];
            derive_ivs(sl->cbc_iv1, chunk_idx, layer, iv1, iv2, iv3);
            const uint8_t *tag_to_use = (layer == (int)meta_layers.layer_count - 1) ? hmac_tag : NULL;
            if (decrypt_cube_layer_ex(cube, sl, iv1, chunk_idx, tag_to_use) != 0)
                die("Layer decryption failed");
        }

        size_t to_copy = CUBE_CAPACITY;
        if (recovered_pos + to_copy > password_blob_len) to_copy = password_blob_len - recovered_pos;
        memcpy(password_blob + recovered_pos, &cube[0][0][0], to_copy);
        recovered_pos += to_copy;
    }
    if (recovered_pos != password_blob_len) die("Decrypted size mismatch");

    // ----- Step 4: Password decryption (AES‑GCM) -----
    if (password_blob_len < 16+12+16+4) die("Password blob too short");
    const uint8_t *salt = password_blob;
    const uint8_t *iv = password_blob + 16;
    const uint8_t *tag = password_blob + 16 + 12;
    size_t enc_comp_len = password_blob_len - (16 + 12 + 16);
    const uint8_t *enc_comp = password_blob + 16 + 12 + 16;

    char password[256];
    prompt_password("Enter password to decrypt the file: ", password, sizeof(password));
    uint8_t pw_key[32];
    if (derive_key_from_password(password, (uint8_t*)salt, pw_key, 0) != 0) die("Key derivation failed");
    OPENSSL_cleanse(password, sizeof(password));

    uint8_t *plain = malloc(enc_comp_len);
    if (!plain) die("malloc");
    int dec_ret = aes_gcm_decrypt(enc_comp, plain, enc_comp_len, pw_key, iv, tag);
    OPENSSL_cleanse(pw_key, sizeof(pw_key));
    free(password_blob);
    if (dec_ret != 0) die("Password incorrect or data corrupted");

    // plain = [12‑byte metadata] + [compressed cubes]
    if (enc_comp_len < 12) die("Plaintext too short");
    uint8_t *meta = plain;
    size_t compressed_len = enc_comp_len - 12;
    uint8_t *compressed = plain + 12;

    // Copy metadata to a local buffer BEFORE freeing plain
    uint8_t meta_copy[12];
    memcpy(meta_copy, meta, 12);
    uint64_t base_seed;
    memcpy(&base_seed, meta_copy, 8);
    generate_entropy_pools_deterministic(base_seed);

    // ----- Step 5: Decompress cubes data -----
    uint32_t original_len;
    memcpy(&original_len, meta_copy + 8, 4);
    size_t expected_cubes_len = ((original_len + TOTAL_CELLS - 1) / TOTAL_CELLS) * TOTAL_BYTES;
    if (expected_cubes_len > 100 * 1024 * 1024) die("Decompressed size too large");
    uLongf decomp_len = expected_cubes_len;
    uint8_t *decompressed = malloc(decomp_len);
    if (!decompressed) die("malloc");
    int zret = uncompress(decompressed, &decomp_len, compressed, compressed_len);
    free(plain);
    if (zret != Z_OK || decomp_len != expected_cubes_len) die("Decompression failed");

    // ----- Step 6: Decode from cubes (in memory) -----
    int recovered_len;
    char *recovered = decode_message_from_cubes(decompressed, decomp_len,
                                                 meta_copy, 12,
                                                 &recovered_len);
    if (!recovered) die("decode failed");

    // Write recovered data to output file
    FILE *out = fopen(output_file, "wb");
    if (!out) die("fopen output");
    fwrite(recovered, 1, recovered_len, out);
    fclose(out);
    free(recovered);
    free(decompressed);
    printf("SUCCESS: Decrypted and decoded to '%s'\n", output_file);
}
