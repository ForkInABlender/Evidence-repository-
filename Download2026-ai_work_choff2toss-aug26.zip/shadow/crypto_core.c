#include "crypto_core.h"
#include "utils.h"
#include "entropy.h"
#include "aes_utils.h"
#include "prng_utils.h"
#include "matrix_utils.h"
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <openssl/evp.h>
#include <openssl/rand.h>

static void derive_chunk_key(const uint8_t *base_key, uint64_t chunk_idx, uint8_t out_key[32]) {
    EVP_MD_CTX *mdctx = EVP_MD_CTX_new();
    const EVP_MD *md = EVP_sha256();
    uint8_t digest[32];
    uint64_t chunk_be = __builtin_bswap64(chunk_idx);
    EVP_DigestInit_ex(mdctx, md, NULL);
    EVP_DigestUpdate(mdctx, base_key, 32);
    EVP_DigestUpdate(mdctx, &chunk_be, sizeof(chunk_be));
    EVP_DigestFinal_ex(mdctx, digest, NULL);
    memcpy(out_key, digest, 32);
    EVP_MD_CTX_free(mdctx);
}

void encrypt_cube_layer_simple(uint8_t cube[6][MATRIX_SIZE][MATRIX_SIZE],
                               shuffle_layer_t *sl) {
    // 1. XOR keystream
    prng_state_t xform_prng;
    if (prng_init(&xform_prng, sl->transform_seed) != 0) exit(EXIT_FAILURE);
    for (int f = 0; f < 6; f++)
        for (int r = 0; r < MATRIX_SIZE; r++)
            for (int c = 0; c < MATRIX_SIZE; c++)
                cube[f][r][c] ^= prng_get_byte(&xform_prng);
    prng_free(&xform_prng);

    // 2. S‑box substitution
    for (int f = 0; f < 6; f++)
        for (int r = 0; r < MATRIX_SIZE; r++)
            for (int c = 0; c < MATRIX_SIZE; c++)
                cube[f][r][c] = sl->sbox[cube[f][r][c]];

    // 3. Linear mixing across faces
    mix_faces(cube, sl->mix_matrix);
}

// Corresponding decryption
void decrypt_cube_layer_simple(uint8_t cube[6][MATRIX_SIZE][MATRIX_SIZE],
                               const shuffle_layer_t *sl) {
    // 1. Reverse linear mixing
    mix_faces(cube, sl->mix_matrix_inv);

    // 2. Inverse S‑box
    for (int f = 0; f < 6; f++)
        for (int r = 0; r < MATRIX_SIZE; r++)
            for (int c = 0; c < MATRIX_SIZE; c++)
                cube[f][r][c] = sl->inv_sbox[cube[f][r][c]];

    // 3. XOR same keystream
    prng_state_t xform_prng;
    if (prng_init(&xform_prng, sl->transform_seed) != 0) exit(EXIT_FAILURE);
    for (int f = 0; f < 6; f++)
        for (int r = 0; r < MATRIX_SIZE; r++)
            for (int c = 0; c < MATRIX_SIZE; c++)
                cube[f][r][c] ^= prng_get_byte(&xform_prng);
    prng_free(&xform_prng);
}

void generate_layer_metadata(shuffle_layer_t *sl) {
    for (int i = 0; i < 32; i++) {
        sl->aes_key1[i] = get_entropy_byte();
        sl->aes_key2[i] = get_entropy_byte();
        sl->aes_key3[i] = get_entropy_byte();
        sl->hmac_key[i] = get_entropy_byte();
        sl->transform_seed[i] = get_entropy_byte();
        sl->shuffle_seed[i] = get_entropy_byte();
    }
    for (int i = 0; i < CBC_IVLEN; i++)
        sl->cbc_iv1[i] = get_entropy_byte();

    // S‑box
    uint8_t sbox[256];
    for (int i = 0; i < 256; i++) sbox[i] = (uint8_t)i;
    for (int i = 255; i > 0; i--) {
        int j = get_entropy_byte() % (i + 1);
        uint8_t t = sbox[i];
        sbox[i] = sbox[j];
        sbox[j] = t;
    }
    memcpy(sl->sbox, sbox, 256);
    for (int i = 0; i < 256; i++) sl->inv_sbox[sl->sbox[i]] = (uint8_t)i;

    // Mix matrix
    generate_invertible_matrix_6x6(sl->mix_matrix);
    if (matrix_invert_6x6(sl->mix_matrix, sl->mix_matrix_inv) != 0) {
        int retry = 0;
        do {
            generate_invertible_matrix_6x6(sl->mix_matrix);
            retry++;
            if (retry > 10) {
                fprintf(stderr, "FATAL: Could not generate invertible matrix\n");
                exit(EXIT_FAILURE);
            }
        } while (matrix_invert_6x6(sl->mix_matrix, sl->mix_matrix_inv) != 0);
    }

    // Transform key string
    prng_state_t prng;
    if (prng_init(&prng, sl->shuffle_seed) != 0) exit(EXIT_FAILURE);
    const char *moves[] = {"L","R","U","D","F","B"};
    char *p = sl->transform_key;
    for (int i = 0; i < 64; i++) {
        uint8_t r = prng_get_byte(&prng);
        size_t n = snprintf(p, sizeof(sl->transform_key) - (p - sl->transform_key),
                           "%s ", moves[r % 6]);
        if (n <= 0 || n >= sizeof(sl->transform_key) - (p - sl->transform_key)) break;
        p += n;
    }
    prng_free(&prng);
}

// Deterministic IV derivation using byte‑swapping for cross‑platform consistency
void derive_ivs(const uint8_t *iv_seed, uint64_t chunk_idx, uint32_t layer_idx,
                uint8_t iv1[16], uint8_t iv2[16], uint8_t iv3[16]) {
    EVP_MD_CTX *mdctx = EVP_MD_CTX_new();
    const EVP_MD *md = EVP_sha256();
    uint8_t digest[32];

    // Convert to big‑endian (network order) using built‑in byte swap
    uint64_t chunk_be = __builtin_bswap64(chunk_idx);
    uint32_t layer_be = __builtin_bswap32(layer_idx);

    // iv1 = H(iv_seed || chunk_be || layer_be || 1)
    EVP_DigestInit_ex(mdctx, md, NULL);
    EVP_DigestUpdate(mdctx, iv_seed, 16);
    EVP_DigestUpdate(mdctx, &chunk_be, sizeof(chunk_be));
    EVP_DigestUpdate(mdctx, &layer_be, sizeof(layer_be));
    uint8_t c = 1;
    EVP_DigestUpdate(mdctx, &c, 1);
    EVP_DigestFinal_ex(mdctx, digest, NULL);
    memcpy(iv1, digest, 16);

    // iv2 = H(iv_seed || chunk_be || layer_be || 2)
    EVP_DigestInit_ex(mdctx, md, NULL);
    EVP_DigestUpdate(mdctx, iv_seed, 16);
    EVP_DigestUpdate(mdctx, &chunk_be, sizeof(chunk_be));
    EVP_DigestUpdate(mdctx, &layer_be, sizeof(layer_be));
    c = 2;
    EVP_DigestUpdate(mdctx, &c, 1);
    EVP_DigestFinal_ex(mdctx, digest, NULL);
    memcpy(iv2, digest, 16);

    // iv3 = H(iv_seed || chunk_be || layer_be || 3)
    EVP_DigestInit_ex(mdctx, md, NULL);
    EVP_DigestUpdate(mdctx, iv_seed, 16);
    EVP_DigestUpdate(mdctx, &chunk_be, sizeof(chunk_be));
    EVP_DigestUpdate(mdctx, &layer_be, sizeof(layer_be));
    c = 3;
    EVP_DigestUpdate(mdctx, &c, 1);
    EVP_DigestFinal_ex(mdctx, digest, NULL);
    memcpy(iv3, digest, 16);

    EVP_MD_CTX_free(mdctx);
}

void encrypt_cube_layer_ex(uint8_t cube[6][MATRIX_SIZE][MATRIX_SIZE],
                           shuffle_layer_t *sl,
                           const uint8_t *iv1,
                           uint64_t chunk_idx,
                           uint8_t *hmac_tag_out) {
    // 1. XOR keystream
    prng_state_t xform_prng;
    if (prng_init(&xform_prng, sl->transform_seed) != 0) exit(EXIT_FAILURE);
    for (int f = 0; f < 6; f++)
        for (int r = 0; r < MATRIX_SIZE; r++)
            for (int c = 0; c < MATRIX_SIZE; c++)
                cube[f][r][c] ^= prng_get_byte(&xform_prng);
    prng_free(&xform_prng);

    // 2. S‑box
    for (int f = 0; f < 6; f++)
        for (int r = 0; r < MATRIX_SIZE; r++)
            for (int c = 0; c < MATRIX_SIZE; c++)
                cube[f][r][c] = sl->sbox[cube[f][r][c]];

    // 3. Linear mixing across faces
    mix_faces(cube, sl->mix_matrix);

    // 4. Flatten cube to 384 bytes
    uint8_t flat[CUBE_CAPACITY];
    int idx = 0;
    for (int f = 0; f < 6; f++)
        for (int r = 0; r < MATRIX_SIZE; r++)
            for (int c = 0; c < MATRIX_SIZE; c++)
                flat[idx++] = cube[f][r][c];

    // 5. Prepare GCM IV (first 12 bytes of iv1, or random for legacy)
    uint8_t gcm_iv[12];
    if (iv1) memcpy(gcm_iv, iv1, 12);
    else if (RAND_bytes(gcm_iv, 12) != 1) exit(EXIT_FAILURE);   // legacy fallback

    // 6. Derive per‑chunk AES key from the layer’s master key
    uint8_t chunk_key[32];
    derive_chunk_key(sl->aes_key1, chunk_idx, chunk_key);

    // 7. AES‑GCM encryption using the derived chunk key
    uint8_t encrypted[CUBE_CAPACITY];
    uint8_t local_tag[HMAC_TAGLEN] = {0};
    uint8_t *tag_ptr = hmac_tag_out ? hmac_tag_out : local_tag;
    aes_gcm_encrypt(flat, encrypted, CUBE_CAPACITY, chunk_key, gcm_iv, tag_ptr);

    // 8. Write back encrypted cube
    idx = 0;
    for (int f = 0; f < 6; f++)
        for (int r = 0; r < MATRIX_SIZE; r++)
            for (int c = 0; c < MATRIX_SIZE; c++)
                cube[f][r][c] = encrypted[idx++];
}

int decrypt_cube_layer_ex(uint8_t cube[6][MATRIX_SIZE][MATRIX_SIZE],
                          const shuffle_layer_t *sl,
                          const uint8_t *iv1,
                          uint64_t chunk_idx,
                          const uint8_t *hmac_tag) {
    // Step 1: Flatten ciphertext cube
    uint8_t flat[CUBE_CAPACITY];
    int idx = 0;
    for (int f = 0; f < 6; f++)
        for (int r = 0; r < MATRIX_SIZE; r++)
            for (int c = 0; c < MATRIX_SIZE; c++)
                flat[idx++] = cube[f][r][c];

    // Step 2: Prepare GCM IV (first 12 bytes of iv1)
    uint8_t gcm_iv[12];
    if (!iv1) return -1;   // IV required for chunked mode
    memcpy(gcm_iv, iv1, 12);

    // Step 3: Derive per‑chunk AES key (must match encryption)
    uint8_t chunk_key[32];
    derive_chunk_key(sl->aes_key1, chunk_idx, chunk_key);

    // Step 4: AES‑GCM decryption using derived key
    uint8_t decrypted[CUBE_CAPACITY];
    int ret;
    if (hmac_tag == NULL) {
        // Inner layer: no tag stored, use dummy and ignore verification
        uint8_t dummy_tag[16] = {0};
        ret = aes_gcm_decrypt(flat, decrypted, CUBE_CAPACITY, chunk_key, gcm_iv, dummy_tag);
        // ignore return value for inner layers
    } else {
        // Outermost layer: verify tag
        ret = aes_gcm_decrypt(flat, decrypted, CUBE_CAPACITY, chunk_key, gcm_iv, hmac_tag);
        if (ret != 0) return -1;   // tag mismatch -> corruption
    }

    // Step 5: Rebuild cube from decrypted data (this is the transformed cube T)
    idx = 0;
    for (int f = 0; f < 6; f++)
        for (int r = 0; r < MATRIX_SIZE; r++)
            for (int c = 0; c < MATRIX_SIZE; c++)
                cube[f][r][c] = decrypted[idx++];

    // Step 6: Reverse the forward transforms (inverse mix, inverse S‑box, XOR keystream)
    mix_faces(cube, sl->mix_matrix_inv);

    for (int f = 0; f < 6; f++)
        for (int r = 0; r < MATRIX_SIZE; r++)
            for (int c = 0; c < MATRIX_SIZE; c++)
                cube[f][r][c] = sl->inv_sbox[cube[f][r][c]];

    prng_state_t xform_prng;
    if (prng_init(&xform_prng, sl->transform_seed) != 0) return -1;
    for (int f = 0; f < 6; f++)
        for (int r = 0; r < MATRIX_SIZE; r++)
            for (int c = 0; c < MATRIX_SIZE; c++)
                cube[f][r][c] ^= prng_get_byte(&xform_prng);
    prng_free(&xform_prng);

    return 0;
}
