#define _POSIX_C_SOURCE 200809L
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>
#include "encoding.h"
#include "entropy_pool.h"
#include "stego_util.h"

#define ENCODED_MATRIX_SIZE 64
#define TOTAL_CELLS (6 * ENCODED_MATRIX_SIZE * ENCODED_MATRIX_SIZE)
#define FACE_CELLS (ENCODED_MATRIX_SIZE * ENCODED_MATRIX_SIZE)
#define TOTAL_BYTES (TOTAL_CELLS * sizeof(uint32_t))

typedef uint32_t face_t[ENCODED_MATRIX_SIZE][ENCODED_MATRIX_SIZE];
typedef uint32_t cube_t[6][ENCODED_MATRIX_SIZE][ENCODED_MATRIX_SIZE];

typedef enum {
    OP_ADD = 0,
    OP_SUB = 1,
    NUM_OPS = 2
} math_op_t;

const char* op_to_string(math_op_t op) { return (op == OP_ADD) ? "+" : "-"; }

// ------------------------- Deterministic RNG -------------------------
uint64_t rng_state;
void rng_init(uint64_t seed) { rng_state = seed; }
uint64_t rng_next(void) {
    uint64_t x = rng_state;
    x ^= x >> 12; x ^= x << 25; x ^= x >> 27;
    rng_state = x;
    return x * 0x2545F4914F6CDD1DULL;
}
uint32_t rng_uint32(void) { return (uint32_t)(rng_next() >> 32); }
void generate_random_permutation(int *perm, int n) {
    for (int i = 0; i < n; i++) perm[i] = i;
    for (int i = n-1; i > 0; i--) {
        int j = rng_uint32() % (i+1);
        int tmp = perm[i];
        perm[i] = perm[j];
        perm[j] = tmp;
    }
}

// ------------------------- Transform functions -------------------------
void apply_row_permutation(face_t face, const int *perm);
void apply_col_permutation(face_t face, const int *perm);
uint32_t rotl32(uint32_t x, int r);
uint32_t rotr32(uint32_t x, int r);
void apply_bit_rotation(face_t face, int amount, int left);
uint32_t mod_inv_odd(uint32_t a);
void apply_affine(face_t face, uint32_t a, uint32_t b);
void apply_inverse_affine(face_t face, uint32_t a, uint32_t b);
void apply_2d_diff(face_t face);
void revert_2d_diff(face_t face);
void apply_face_permutation(cube_t cube, const int *perm);
void apply_operation(face_t accum, const face_t src, math_op_t op);
void apply_inverse_operation(face_t accum, const face_t src, math_op_t op);
void xor_face(face_t face, uint32_t key);
void global_bit_rotation(cube_t cube, int amount, int left);

// ------------------------- Entropy helpers -------------------------
uint32_t random_from_pool(int ascii) {
    int idx = rng_uint32() % POOL_SIZE;
    return entropy_pool[ascii - MIN_ASCII][idx];
}

void encode_message_cube(cube_t cube, const char *message, int msg_len) {
    int idx = 0;
    for (int f = 0; f < 6; f++)
        for (int r = 0; r < ENCODED_MATRIX_SIZE; r++)
            for (int c = 0; c < ENCODED_MATRIX_SIZE; c++)
                cube[f][r][c] = (idx < msg_len) ? random_from_pool((unsigned char)message[idx++])
                                                : random_from_pool(32);
}

void decode_message_cube(const cube_t cube, int msg_len, char *recovered) {
    int idx = 0;
    for (int f = 0; f < 6 && idx < msg_len; f++)
        for (int r = 0; r < ENCODED_MATRIX_SIZE && idx < msg_len; r++)
            for (int c = 0; c < ENCODED_MATRIX_SIZE && idx < msg_len; c++) {
                uint32_t val = cube[f][r][c];
                int ascii = find_ascii_hash(val);
                recovered[idx++] = (ascii >= 0) ? (char)ascii : '?';
            }
    recovered[msg_len] = '\0';
}

// ------------------------- Transform function implementations -------------------------
void apply_row_permutation(face_t face, const int *perm) {
    face_t temp;
    memcpy(temp, face, sizeof(face_t));
    for (int r = 0; r < ENCODED_MATRIX_SIZE; r++)
        memcpy(face[r], temp[perm[r]], sizeof(uint32_t) * ENCODED_MATRIX_SIZE);
}

void apply_col_permutation(face_t face, const int *perm) {
    face_t temp;
    memcpy(temp, face, sizeof(face_t));
    for (int r = 0; r < ENCODED_MATRIX_SIZE; r++)
        for (int c = 0; c < ENCODED_MATRIX_SIZE; c++)
            face[r][c] = temp[r][perm[c]];
}

uint32_t rotl32(uint32_t x, int r) {
    r &= 31;
    return (x << r) | (x >> (32 - r));
}

uint32_t rotr32(uint32_t x, int r) {
    r &= 31;
    return (x >> r) | (x << (32 - r));
}

void apply_bit_rotation(face_t face, int amount, int left) {
    for (int r = 0; r < ENCODED_MATRIX_SIZE; r++)
        for (int c = 0; c < ENCODED_MATRIX_SIZE; c++)
            face[r][c] = left ? rotl32(face[r][c], amount) : rotr32(face[r][c], amount);
}

uint32_t mod_inv_odd(uint32_t a) {
    uint32_t inv = a;
    for (int i = 0; i < 4; i++) inv = inv * (2 - a * inv);
    return inv;
}

void apply_affine(face_t face, uint32_t a, uint32_t b) {
    for (int r = 0; r < ENCODED_MATRIX_SIZE; r++)
        for (int c = 0; c < ENCODED_MATRIX_SIZE; c++)
            face[r][c] = face[r][c] * a + b;
}

void apply_inverse_affine(face_t face, uint32_t a, uint32_t b) {
    uint32_t inv_a = mod_inv_odd(a);
    for (int r = 0; r < ENCODED_MATRIX_SIZE; r++)
        for (int c = 0; c < ENCODED_MATRIX_SIZE; c++)
            face[r][c] = (face[r][c] - b) * inv_a;
}

void apply_2d_diff(face_t face) {
    face_t temp;
    memcpy(temp, face, sizeof(face_t));
    for (int r = 0; r < ENCODED_MATRIX_SIZE; r++) {
        temp[r][0] = face[r][0];
        for (int c = 1; c < ENCODED_MATRIX_SIZE; c++)
            temp[r][c] = face[r][c] - face[r][c-1];
    }
    for (int c = 0; c < ENCODED_MATRIX_SIZE; c++) {
        for (int r = ENCODED_MATRIX_SIZE-1; r > 0; r--)
            temp[r][c] = temp[r][c] - temp[r-1][c];
    }
    memcpy(face, temp, sizeof(face_t));
}

void revert_2d_diff(face_t face) {
    face_t temp;
    memcpy(temp, face, sizeof(face_t));
    for (int c = 0; c < ENCODED_MATRIX_SIZE; c++) {
        for (int r = 1; r < ENCODED_MATRIX_SIZE; r++)
            temp[r][c] = temp[r][c] + temp[r-1][c];
    }
    for (int r = 0; r < ENCODED_MATRIX_SIZE; r++) {
        for (int c = 1; c < ENCODED_MATRIX_SIZE; c++)
            temp[r][c] = temp[r][c] + temp[r][c-1];
    }
    memcpy(face, temp, sizeof(face_t));
}

void apply_face_permutation(cube_t cube, const int *perm) {
    cube_t temp;
    memcpy(temp, cube, sizeof(cube_t));
    for (int i = 0; i < 6; i++)
        memcpy(cube[i], temp[perm[i]], sizeof(face_t));
}

void apply_operation(face_t accum, const face_t src, math_op_t op) {
    for (int r = 0; r < ENCODED_MATRIX_SIZE; r++)
        for (int c = 0; c < ENCODED_MATRIX_SIZE; c++) {
            if (op == OP_ADD) accum[r][c] += src[r][c];
            else accum[r][c] -= src[r][c];
        }
}

void apply_inverse_operation(face_t accum, const face_t src, math_op_t op) {
    for (int r = 0; r < ENCODED_MATRIX_SIZE; r++)
        for (int c = 0; c < ENCODED_MATRIX_SIZE; c++) {
            if (op == OP_ADD) accum[r][c] -= src[r][c];
            else accum[r][c] += src[r][c];
        }
}

void xor_face(face_t face, uint32_t key) {
    for (int r = 0; r < ENCODED_MATRIX_SIZE; r++)
        for (int c = 0; c < ENCODED_MATRIX_SIZE; c++)
            face[r][c] ^= key;
}

void global_bit_rotation(cube_t cube, int amount, int left) {
    for (int f = 0; f < 6; f++)
        for (int r = 0; r < ENCODED_MATRIX_SIZE; r++)
            for (int c = 0; c < ENCODED_MATRIX_SIZE; c++)
                cube[f][r][c] = left ? rotl32(cube[f][r][c], amount) : rotr32(cube[f][r][c], amount);
}

// ------------------------- In‑memory chunk processing -------------------------
void encode_chunk_to_mem(const char *chunk, int chunk_len, int chunk_index,
                         uint64_t base_seed, uint8_t *out_cube) {
    uint64_t chunk_seed = base_seed ^ ((uint64_t)chunk_index << 32) ^ chunk_index;
    rng_init(chunk_seed);

    unsigned int row_perm_seeds[6], col_perm_seeds[6];
    int bit_rot_amounts[6], bit_rot_left[6];
    uint32_t affine_a[6], affine_b[6], xor_masks[6];
    int face_perm[6];
    math_op_t inter_ops[5];
    uint32_t inter_xor_keys[5];
    int global_rot_amount, global_rot_left;

    for (int i = 0; i < 6; i++) {
        row_perm_seeds[i] = rng_uint32();
        col_perm_seeds[i] = rng_uint32();
    }
    for (int i = 0; i < 6; i++) {
        bit_rot_amounts[i] = rng_uint32() % 32;
        bit_rot_left[i] = rng_uint32() & 1;
    }
    for (int i = 0; i < 6; i++) {
        affine_a[i] = rng_uint32() | 1;
        affine_b[i] = rng_uint32();
        xor_masks[i] = rng_uint32();
    }
    generate_random_permutation(face_perm, 6);
    for (int i = 0; i < 5; i++) {
        inter_ops[i] = (math_op_t)(rng_uint32() % NUM_OPS);
        inter_xor_keys[i] = rng_uint32();
    }
    global_rot_amount = rng_uint32() % 32;
    global_rot_left = rng_uint32() & 1;

    cube_t cube = {0};
    encode_message_cube(cube, chunk, chunk_len);

    for (int f = 0; f < 6; f++) {
        uint64_t saved_state = rng_state;
        rng_init(row_perm_seeds[f]);
        int row_perm[ENCODED_MATRIX_SIZE];
        generate_random_permutation(row_perm, ENCODED_MATRIX_SIZE);
        rng_init(col_perm_seeds[f]);
        int col_perm[ENCODED_MATRIX_SIZE];
        generate_random_permutation(col_perm, ENCODED_MATRIX_SIZE);
        rng_state = saved_state;

        apply_row_permutation(cube[f], row_perm);
        apply_col_permutation(cube[f], col_perm);
        apply_bit_rotation(cube[f], bit_rot_amounts[f], bit_rot_left[f]);
        apply_affine(cube[f], affine_a[f], affine_b[f]);
        xor_face(cube[f], xor_masks[f]);
    }
    for (int f = 0; f < 6; f++) apply_2d_diff(cube[f]);
    apply_face_permutation(cube, face_perm);
    for (int i = 1; i <= 5; i++) {
        apply_operation(cube[0], cube[i], inter_ops[i-1]);
        xor_face(cube[0], inter_xor_keys[i-1]);
    }
    global_bit_rotation(cube, global_rot_amount, global_rot_left);

    memcpy(out_cube, cube, TOTAL_BYTES);
}

void decode_chunk_from_mem(uint8_t *cube_data, int chunk_len, int chunk_index, uint64_t base_seed) {
    (void)chunk_len;
    uint64_t chunk_seed = base_seed ^ ((uint64_t)chunk_index << 32) ^ chunk_index;
    rng_init(chunk_seed);

    unsigned int row_perm_seeds[6], col_perm_seeds[6];
    int bit_rot_amounts[6], bit_rot_left[6];
    uint32_t affine_a[6], affine_b[6], xor_masks[6];
    int face_perm[6];
    math_op_t inter_ops[5];
    uint32_t inter_xor_keys[5];
    int global_rot_amount, global_rot_left;

    for (int i = 0; i < 6; i++) {
        row_perm_seeds[i] = rng_uint32();
        col_perm_seeds[i] = rng_uint32();
    }
    for (int i = 0; i < 6; i++) {
        bit_rot_amounts[i] = rng_uint32() % 32;
        bit_rot_left[i] = rng_uint32() & 1;
    }
    for (int i = 0; i < 6; i++) {
        affine_a[i] = rng_uint32() | 1;
        affine_b[i] = rng_uint32();
        xor_masks[i] = rng_uint32();
    }
    generate_random_permutation(face_perm, 6);
    for (int i = 0; i < 5; i++) {
        inter_ops[i] = (math_op_t)(rng_uint32() % NUM_OPS);
        inter_xor_keys[i] = rng_uint32();
    }
    global_rot_amount = rng_uint32() % 32;
    global_rot_left = rng_uint32() & 1;

    cube_t cube;
    memcpy(cube, cube_data, TOTAL_BYTES);

    global_bit_rotation(cube, global_rot_amount, !global_rot_left);
    for (int i = 4; i >= 0; i--) {
        xor_face(cube[0], inter_xor_keys[i]);
        apply_inverse_operation(cube[0], cube[i+1], inter_ops[i]);
    }
    int inv_face_perm[6];
    for (int i = 0; i < 6; i++) inv_face_perm[face_perm[i]] = i;
    cube_t temp;
    memcpy(temp, cube, sizeof(cube_t));
    for (int i = 0; i < 6; i++) memcpy(cube[i], temp[inv_face_perm[i]], sizeof(face_t));
    for (int f = 0; f < 6; f++) revert_2d_diff(cube[f]);
    for (int f = 0; f < 6; f++) {
        uint64_t saved_state = rng_state;
        rng_init(row_perm_seeds[f]);
        int row_perm[ENCODED_MATRIX_SIZE], inv_row_perm[ENCODED_MATRIX_SIZE];
        generate_random_permutation(row_perm, ENCODED_MATRIX_SIZE);
        for (int r = 0; r < ENCODED_MATRIX_SIZE; r++) inv_row_perm[row_perm[r]] = r;
        rng_init(col_perm_seeds[f]);
        int col_perm[ENCODED_MATRIX_SIZE], inv_col_perm[ENCODED_MATRIX_SIZE];
        generate_random_permutation(col_perm, ENCODED_MATRIX_SIZE);
        for (int c = 0; c < ENCODED_MATRIX_SIZE; c++) inv_col_perm[col_perm[c]] = c;
        rng_state = saved_state;

        xor_face(cube[f], xor_masks[f]);
        apply_inverse_affine(cube[f], affine_a[f], affine_b[f]);
        apply_bit_rotation(cube[f], bit_rot_amounts[f], !bit_rot_left[f]);
        apply_col_permutation(cube[f], inv_col_perm);
        apply_row_permutation(cube[f], inv_row_perm);
    }
    memcpy(cube_data, cube, TOTAL_BYTES);
}

// ------------------------- High‑level memory‑only functions -------------------------
uint8_t* encode_message_to_cubes(const char *message, int msg_len,
                                 uint64_t base_seed,
                                 uint8_t **metadata_out,
                                 size_t *out_cubes_len) {
    int num_chunks = (msg_len + TOTAL_CELLS - 1) / TOTAL_CELLS;
    size_t total_cubes_len = num_chunks * TOTAL_BYTES;
    uint8_t *cubes_buf = malloc(total_cubes_len);
    if (!cubes_buf) die("malloc");

    for (int i = 0; i < num_chunks; i++) {
        int start = i * TOTAL_CELLS;
        int len = (start + TOTAL_CELLS <= msg_len) ? TOTAL_CELLS : msg_len - start;
        char chunk[TOTAL_CELLS + 1];
        memcpy(chunk, message + start, len);
        chunk[len] = '\0';
        encode_chunk_to_mem(chunk, len, i, base_seed, cubes_buf + i * TOTAL_BYTES);
    }

    uint8_t *meta = malloc(12);
    if (!meta) die("malloc");
    memcpy(meta, &base_seed, 8);
    memcpy(meta + 8, &msg_len, 4);
    *metadata_out = meta;
    *out_cubes_len = total_cubes_len;
    return cubes_buf;
}

char* decode_message_from_cubes(const uint8_t *cubes_data, size_t cubes_len,
                                const uint8_t *metadata, size_t metadata_len,
                                int *out_msg_len) {
    if (metadata_len != 12) die("Invalid metadata length");
    uint64_t base_seed;
    int total_len;
    memcpy(&base_seed, metadata, 8);
    memcpy(&total_len, metadata + 8, 4);

    int num_chunks = (total_len + TOTAL_CELLS - 1) / TOTAL_CELLS;
    if (cubes_len != (size_t)num_chunks * TOTAL_BYTES) die("Cubes size mismatch");

    char *full_message = malloc(total_len + 1);
    if (!full_message) die("malloc");

    int offset = 0;
    for (int i = 0; i < num_chunks; i++) {
        uint8_t *cube_buf = malloc(TOTAL_BYTES);
        if (!cube_buf) die("malloc");
        memcpy(cube_buf, cubes_data + i * TOTAL_BYTES, TOTAL_BYTES);
        int chunk_len = (i == num_chunks-1 && total_len % TOTAL_CELLS != 0) ? total_len % TOTAL_CELLS : TOTAL_CELLS;
        decode_chunk_from_mem(cube_buf, chunk_len, i, base_seed);
        cube_t cube;
        memcpy(cube, cube_buf, TOTAL_BYTES);
        char decoded[TOTAL_CELLS + 1];
        decode_message_cube(cube, chunk_len, decoded);
        memcpy(full_message + offset, decoded, chunk_len);
        offset += chunk_len;
        free(cube_buf);
    }
    full_message[total_len] = '\0';
    *out_msg_len = total_len;
    return full_message;
}
