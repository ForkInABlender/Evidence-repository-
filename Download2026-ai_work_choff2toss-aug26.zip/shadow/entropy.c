#define _GNU_SOURCE          // for getloadavg
#define _POSIX_C_SOURCE 200809L
#include "entropy.h"
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <unistd.h>
#include <time.h>
#include <pthread.h>
#include <openssl/rand.h>
#include <sys/time.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <errno.h>
#include <signal.h>
#include <sys/resource.h>   // for getrusage
#include <sys/sysinfo.h>    // for sysinfo
#ifdef __linux__
#include <sys/random.h>     // for getrandom
#endif
#include <dirent.h>         // for thermal zones
#include <sys/syscall.h>    // for perf_event_open
#include <linux/perf_event.h> // for hardware performance counters

// For curl (optional, but we'll check availability)
#ifdef USE_LIBCURL
#include <curl/curl.h>
#endif

// Check for x86_64 CPU features (RDSEED/RDRAND)
#if defined(__x86_64__) || defined(_M_X64)
#include <cpuid.h>
#include <immintrin.h>

// CPU feature flags
static int has_rdrand = 0;
static int has_rdseed = 0;

// CPU cycle counter (rdtsc)
static inline uint64_t rdtsc(void) {
    uint32_t lo, hi;
    __asm__ volatile ("rdtsc" : "=a"(lo), "=d"(hi));
    return ((uint64_t)hi << 32) | lo;
}

// Check CPU support for RDRAND and RDSEED
static void check_cpu_features(void) {
    unsigned int eax, ebx, ecx, edx;
    
    // Check for RDRAND (CPUID leaf 1, ECX bit 30)
    if (__get_cpuid(1, &eax, &ebx, &ecx, &edx)) {
        has_rdrand = (ecx & (1 << 30)) != 0;
    }
    
    // Check for RDSEED (CPUID leaf 7, ECX bit 0)
    if (__get_cpuid_count(7, 0, &eax, &ebx, &ecx, &edx)) {
        has_rdseed = (ebx & (1 << 18)) != 0;
    }
    
    if (has_rdseed) {
        printf("Hardware RDSEED available (true random numbers)\n");
    } else if (has_rdrand) {
        printf("Hardware RDRAND available (pseudo-random numbers)\n");
    }
}

// Get 64-bit random value from RDSEED (true hardware random)
static uint64_t rdseed64(void) {
    if (!has_rdseed) return 0;
    
    unsigned long long val;
    unsigned char retry = 0;
    while (!_rdseed64_step(&val) && retry < 10) {
        retry++;
    }
    return (uint64_t)val;
}

// Get 64-bit random value from RDRAND (hardware PRNG)
static uint64_t rdrand64(void) {
    if (!has_rdrand) return 0;
    
    unsigned long long val;
    unsigned char retry = 0;
    while (!_rdrand64_step(&val) && retry < 10) {
        retry++;
    }
    return (uint64_t)val;
}

// Get hardware randomness (prefer RDSEED, fallback to RDRAND)
static uint64_t get_hardware_random64(void) {
    uint64_t val;
    if (has_rdseed) {
        val = rdseed64();
        if (val != 0) return val;
    }
    if (has_rdrand) {
        val = rdrand64();
        if (val != 0) return val;
    }
    return 0;  // No hardware RNG available
}

#else
// Non-x86_64 platforms
static uint64_t rdtsc(void) { return (uint64_t)clock(); }
static void check_cpu_features(void) { }
static uint64_t get_hardware_random64(void) { return 0; }
#endif

// Enhanced entropy pool with jitter
static uint8_t *entropy_pool = NULL;
static size_t pool_size = 0;
static pthread_mutex_t entropy_mutex = PTHREAD_MUTEX_INITIALIZER;

// Get current thread ID without syscall
static uint64_t get_thread_id(void) {
    uint64_t tid = (uint64_t)pthread_self();
    tid ^= (uint64_t)clock();
    tid ^= (uint64_t)time(NULL);
    return tid;
}

// High-resolution timer jitter with hardware RNG mixing and rdtsc
static uint64_t get_jitter(void) {
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    uint64_t jitter = ts.tv_nsec;
    jitter ^= (uint64_t)ts.tv_sec << 32;
    jitter ^= get_thread_id();
    jitter ^= rdtsc();  // CPU cycle counter
    
    uint64_t hw_rnd = get_hardware_random64();
    if (hw_rnd) jitter ^= hw_rnd;
    
    jitter ^= (uint64_t)clock() * 0x9E3779B97F4A7C15ULL;
    return jitter;
}

// Mix entropy with jitter to increase unpredictability
static void mix_with_jitter(uint8_t *buffer, size_t len) {
    for (size_t i = 0; i < len; i++) {
        uint64_t jitter = get_jitter();
        buffer[i] ^= (jitter >> (i % 56)) & 0xFF;
        for (volatile int j = 0; j < 100; j++);
    }
}

/* ---------- Additional entropy sources ---------- */

// 1. Environment variables entropy
static void add_env_entropy(uint8_t *buffer, size_t len) {
    const char *vars[] = {"PATH", "HOME", "USER", "SHELL", "LANG", "DISPLAY", "TERM", "PWD", "HOSTNAME"};
    for (size_t i = 0; i < len && i < sizeof(vars)/sizeof(vars[0]); i++) {
        const char *val = getenv(vars[i % (sizeof(vars)/sizeof(vars[0]))]);
        if (val) {
            for (size_t j = 0; val[j] && j < 16; j++) {
                buffer[i % len] ^= val[j] ^ (j << 4) ^ (i & 0xFF);
            }
        }
    }
}

// 2. System load average entropy
static void add_load_entropy(uint8_t *buffer, size_t len) {
    double loadavg[3];
    if (getloadavg(loadavg, 3) == 3) {
        for (size_t i = 0; i < len && i < 3; i++) {
            uint64_t bits;
            memcpy(&bits, &loadavg[i], sizeof(double));
            for (size_t j = 0; j < 8 && i+j < len; j++) {
                buffer[i+j] ^= (bits >> (j*8)) & 0xFF;
            }
        }
    }
}

// 3. Disk I/O timing entropy (Linux /proc/diskstats)
static void add_disk_entropy(uint8_t *buffer, size_t len) {
    FILE *fp = fopen("/proc/diskstats", "r");
    if (fp) {
        char line[512];
        struct timeval before, after;
        for (size_t i = 0; i < len && fgets(line, sizeof(line), fp); i++) {
            gettimeofday(&before, NULL);
            // Force a tiny delay by reading dummy data
            volatile int dummy = strlen(line);
            (void)dummy;
            gettimeofday(&after, NULL);
            uint64_t diff = (after.tv_sec - before.tv_sec) * 1000000 + (after.tv_usec - before.tv_usec);
            buffer[i] ^= (diff >> (i % 56)) & 0xFF;
        }
        fclose(fp);
    }
}

// 4. Input device entropy (mouse/keyboard) - Linux /dev/input/mice
static void add_input_entropy(uint8_t *buffer, size_t len) {
    int fd = open("/dev/input/mice", O_RDONLY | O_NONBLOCK);
    if (fd >= 0) {
        struct timeval start, now;
        gettimeofday(&start, NULL);
        for (size_t i = 0; i < len; i++) {
            char event[3];
            ssize_t n = read(fd, event, sizeof(event));
            if (n > 0) {
                gettimeofday(&now, NULL);
                uint64_t diff = (now.tv_sec - start.tv_sec) * 1000000 + (now.tv_usec - start.tv_usec);
                buffer[i] ^= (diff >> ((i * 3) % 56)) & 0xFF;
            }
            usleep(1000);  // small delay
        }
        close(fd);
    }
}

// 5. Network entropy via random.org (if libcurl is available)
#ifdef USE_LIBCURL
static size_t curl_write_callback(void *contents, size_t size, size_t nmemb, void *userp) {
    size_t realsize = size * nmemb;
    uint8_t *buf = (uint8_t*)userp;
    for (size_t i = 0; i < realsize && i < 32; i++) {
        buf[i % 32] ^= ((uint8_t*)contents)[i];
    }
    return realsize;
}

static void add_network_entropy(uint8_t *buffer, size_t len) {
    CURL *curl = curl_easy_init();
    if (curl) {
        uint8_t net_buf[32] = {0};
        curl_easy_setopt(curl, CURLOPT_URL, "https://www.random.org/cgi-bin/randbyte?nbytes=32&format=f");
        curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, curl_write_callback);
        curl_easy_setopt(curl, CURLOPT_WRITEDATA, net_buf);
        curl_easy_setopt(curl, CURLOPT_TIMEOUT, 2L);
        curl_easy_perform(curl);
        curl_easy_cleanup(curl);
        for (size_t i = 0; i < len; i++) {
            buffer[i] ^= net_buf[i % 32];
        }
    }
}
#else
static void add_network_entropy(uint8_t *buffer, size_t len) { (void)buffer; (void)len; }
#endif

// 6. Signal timing entropy
static volatile sig_atomic_t sig_count = 0;
static void sigusr1_handler(int sig) { (void)sig; sig_count++; }

static void add_signal_entropy(uint8_t *buffer, size_t len) {
    struct sigaction oldact;
    struct sigaction act = {0};
    act.sa_handler = sigusr1_handler;
    sigaction(SIGUSR1, &act, &oldact);
    for (size_t i = 0; i < len; i++) {
        int before = sig_count;
        usleep(1000);
        int after = sig_count;
        buffer[i] ^= (after - before) ^ (i & 0xFF);
    }
    sigaction(SIGUSR1, &oldact, NULL);
}

// 7. getrandom() entropy (Linux only)
static void add_getrandom_entropy(uint8_t *buffer, size_t len) {
#ifdef __linux__
    uint8_t *tmp = malloc(len);
    if (!tmp) return;
    ssize_t n = getrandom(tmp, len, 0);
    if (n == (ssize_t)len) {
        for (size_t i = 0; i < len; i++) buffer[i] ^= tmp[i];
    }
    free(tmp);
#endif
}

// 8. CPU time entropy (CLOCK_PROCESS_CPUTIME_ID and CLOCK_THREAD_CPUTIME_ID)
static void add_cputime_entropy(uint8_t *buffer, size_t len) {
    struct timespec ts;
    // Process CPU time
    if (clock_gettime(CLOCK_PROCESS_CPUTIME_ID, &ts) == 0) {
        uint64_t ct = (uint64_t)ts.tv_nsec ^ ((uint64_t)ts.tv_sec << 32);
        for (size_t i = 0; i < len; i++) {
            buffer[i] ^= (ct >> (i % 56)) & 0xFF;
            ct = (ct * 0x9E3779B97F4A7C15ULL) >> 1;
        }
    }
    // Thread CPU time
    if (clock_gettime(CLOCK_THREAD_CPUTIME_ID, &ts) == 0) {
        uint64_t ct = (uint64_t)ts.tv_nsec ^ ((uint64_t)ts.tv_sec << 32);
        for (size_t i = 0; i < len; i++) {
            buffer[i] ^= (ct >> (i % 56)) & 0xFF;
            ct = (ct * 0x9E3779B97F4A7C15ULL) >> 1;
        }
    }
}

// 9. getrusage() resource usage entropy
static void add_rusage_entropy(uint8_t *buffer, size_t len) {
    struct rusage ru;
    if (getrusage(RUSAGE_SELF, &ru) == 0) {
        uint64_t mixed = (uint64_t)ru.ru_utime.tv_sec ^ (uint64_t)ru.ru_utime.tv_usec
                       ^ (uint64_t)ru.ru_stime.tv_sec ^ (uint64_t)ru.ru_stime.tv_usec
                       ^ ru.ru_minflt ^ ru.ru_majflt ^ ru.ru_nvcsw ^ ru.ru_nivcsw;
        for (size_t i = 0; i < len; i++) {
            buffer[i] ^= (mixed >> (i % 56)) & 0xFF;
            mixed = (mixed * 0x9E3779B97F4A7C15ULL) >> 1;
        }
    }
}

// 10. sysinfo() entropy
static void add_sysinfo_entropy(uint8_t *buffer, size_t len) {
    struct sysinfo info;
    if (sysinfo(&info) == 0) {
        uint64_t mixed = (uint64_t)info.loads[0] ^ (uint64_t)info.loads[1] ^ (uint64_t)info.loads[2]
                       ^ (info.freeram ^ info.totalram) ^ info.procs;
        for (size_t i = 0; i < len; i++) {
            buffer[i] ^= (mixed >> (i % 56)) & 0xFF;
            mixed = (mixed * 0x9E3779B97F4A7C15ULL) >> 1;
        }
    }
}

// 11. Process identifiers entropy
static void add_pid_entropy(uint8_t *buffer, size_t len) {
    uint64_t mixed = (uint64_t)getpid() ^ (uint64_t)gethostid() ^ (uint64_t)getppid();
    for (size_t i = 0; i < len; i++) {
        buffer[i] ^= (mixed >> (i % 56)) & 0xFF;
        mixed = (mixed * 0x9E3779B97F4A7C15ULL) >> 1;
    }
}

/* ==================== NEW ENTROPY SOURCES =================== */

// 12. CPU thermal sensor entropy (fixed buffer size warning)
static void add_thermal_entropy(uint8_t *buffer, size_t len) {
    DIR *dir = opendir("/sys/class/thermal");
    if (!dir) return;
    struct dirent *entry;
    while ((entry = readdir(dir)) != NULL) {
        if (strncmp(entry->d_name, "thermal_zone", 12) == 0) {
            char path[512];  // Increased from 256 to 512 to avoid truncation warning
            int ret = snprintf(path, sizeof(path), "/sys/class/thermal/%s/temp", entry->d_name);
            if (ret < 0 || (size_t)ret >= sizeof(path)) continue;  // truncation check
            FILE *fp = fopen(path, "r");
            if (fp) {
                int temp;
                if (fscanf(fp, "%d", &temp) == 1) {
                    uint64_t val = (uint64_t)temp;
                    for (size_t i = 0; i < len; i++) {
                        buffer[i] ^= (val >> (i % 56)) & 0xFF;
                        val = (val * 0x9E3779B97F4A7C15ULL) >> 1;
                    }
                }
                fclose(fp);
            }
        }
    }
    closedir(dir);
}

// 13. Network device statistics entropy (/proc/net/dev)
static void add_netdev_entropy(uint8_t *buffer, size_t len) {
    FILE *fp = fopen("/proc/net/dev", "r");
    if (!fp) return;
    char line[512];
    uint64_t mixed = 0;
    while (fgets(line, sizeof(line), fp)) {
        // find lines containing ':' (interface lines)
        if (strchr(line, ':')) {
            unsigned long long rx_bytes, tx_bytes;
            // simplistic parsing: skip interface name, then read bytes
            char *p = strchr(line, ':');
            if (p && sscanf(p+1, "%llu %*u %*u %*u %*u %*u %*u %*u %llu", &rx_bytes, &tx_bytes) == 2) {
                mixed ^= rx_bytes ^ tx_bytes;
            }
        }
    }
    fclose(fp);
    for (size_t i = 0; i < len; i++) {
        buffer[i] ^= (mixed >> (i % 56)) & 0xFF;
        mixed = (mixed * 0x9E3779B97F4A7C15ULL) >> 1;
    }
}

// 14. Battery state entropy (capacity and energy)
static void add_battery_entropy(uint8_t *buffer, size_t len) {
    FILE *fp = fopen("/sys/class/power_supply/BAT0/capacity", "r");
    if (fp) {
        int cap;
        if (fscanf(fp, "%d", &cap) == 1) {
            uint64_t val = (uint64_t)cap;
            for (size_t i = 0; i < len; i++) {
                buffer[i] ^= (val >> (i % 56)) & 0xFF;
                val = (val * 0x9E3779B97F4A7C15ULL) >> 1;
            }
        }
        fclose(fp);
    }
    // Also try energy_now (microjoules)
    fp = fopen("/sys/class/power_supply/BAT0/energy_now", "r");
    if (fp) {
        unsigned long long energy;
        if (fscanf(fp, "%llu", &energy) == 1) {
            for (size_t i = 0; i < len; i++) {
                buffer[i] ^= (energy >> (i % 56)) & 0xFF;
                energy = (energy * 0x9E3779B97F4A7C15ULL) >> 1;
            }
        }
        fclose(fp);
    }
}

// 15. Performance counter entropy (hardware cache misses)
static void add_perf_entropy(uint8_t *buffer, size_t len) {
#ifdef __linux__
    struct perf_event_attr attr = {
        .type = PERF_TYPE_HARDWARE,
        .config = PERF_COUNT_HW_CACHE_MISSES,
        .size = sizeof(struct perf_event_attr),
        .disabled = 0,
        .inherit = 1,
    };
    int fd = syscall(__NR_perf_event_open, &attr, 0, -1, -1, 0);
    if (fd < 0) return;
    uint64_t val;
    if (read(fd, &val, sizeof(val)) == sizeof(val)) {
        for (size_t i = 0; i < len; i++) {
            buffer[i] ^= (val >> (i % 56)) & 0xFF;
            val = (val * 0x9E3779B97F4A7C15ULL) >> 1;
        }
    }
    close(fd);
#endif
}

/* ---------- Combined entropy collection ---------- */
static void gather_all_entropy(uint8_t *buffer, size_t len) {
    // Zero the buffer first
    memset(buffer, 0, len);
    
    // Source 1: Hardware RNG
    for (size_t i = 0; i + 8 <= len; i += 8) {
        uint64_t hw = get_hardware_random64();
        if (hw) memcpy(buffer + i, &hw, 8);
    }
    
    // Source 2: OpenSSL RAND_bytes
    uint8_t *tmp = malloc(len);
    if (tmp) {
        if (RAND_bytes(tmp, len) == 1) {
            for (size_t i = 0; i < len; i++) buffer[i] ^= tmp[i];
        }
        free(tmp);
    }
    
    // Source 3: /dev/urandom
    FILE *ur = fopen("/dev/urandom", "rb");
    if (ur) {
        uint8_t *ur_buf = malloc(len);
        if (ur_buf) {
            size_t bytes_read = fread(ur_buf, 1, len, ur);
            (void)bytes_read;
            for (size_t i = 0; i < len; i++) buffer[i] ^= ur_buf[i];
            free(ur_buf);
        }
        fclose(ur);
    }
    
    // Source 4: getrandom() (Linux)
    add_getrandom_entropy(buffer, len);
    
    // Source 5: Jitter (time, rdtsc, etc.)
    for (size_t i = 0; i < len; i++) {
        buffer[i] ^= (get_jitter() >> ((i * 7) % 56)) & 0xFF;
    }
    
    // Original additional entropy sources
    add_env_entropy(buffer, len);
    add_load_entropy(buffer, len);
    add_disk_entropy(buffer, len);
    add_input_entropy(buffer, len);
    add_network_entropy(buffer, len);
    add_signal_entropy(buffer, len);
    add_cputime_entropy(buffer, len);
    add_rusage_entropy(buffer, len);
    add_sysinfo_entropy(buffer, len);
    add_pid_entropy(buffer, len);
    
    // NEW entropy sources
    add_thermal_entropy(buffer, len);
    add_netdev_entropy(buffer, len);
    add_battery_entropy(buffer, len);
    add_perf_entropy(buffer, len);
    
    // Final mixing pass
    mix_with_jitter(buffer, len);
}

/* ---------- Parallel collection helpers ---------- */
#define NUM_COLLECT_THREADS 4   // adjust based on CPU cores

typedef struct {
    uint8_t *buf;
    size_t off;
    size_t len;
} collect_args_t;

static void *collect_worker(void *arg) {
    collect_args_t *args = (collect_args_t*)arg;
    gather_all_entropy(args->buf + args->off, args->len);
    return NULL;
}

// Initialize entropy pool with all sources (parallel version)
void init_entropy(void) {
    check_cpu_features();
    
    // Ensure OpenSSL's RNG is seeded from system sources
    RAND_poll();
    
    pool_size = ENTROPY_BYTES_PER_ENTRY;
    entropy_pool = malloc(pool_size);
    if (!entropy_pool) { perror("malloc"); exit(1); }
    
    printf("Anything done well takes time.\nMake some coffee while entropy is being applied.\n");

    // Use a temporary buffer to collect entropy
    uint8_t *temp = malloc(pool_size);
    if (!temp) { free(entropy_pool); exit(1); }
    
    // Parallel collection
    pthread_t threads[NUM_COLLECT_THREADS];
    collect_args_t args[NUM_COLLECT_THREADS];
    
    size_t chunk = 4096;
    size_t num_chunks = (pool_size + chunk - 1) / chunk;
    size_t chunks_per_thread = (num_chunks + NUM_COLLECT_THREADS - 1) / NUM_COLLECT_THREADS;
    
    for (int t = 0; t < NUM_COLLECT_THREADS; t++) {
        size_t start_chunk = t * chunks_per_thread;
        size_t end_chunk = start_chunk + chunks_per_thread;
        if (start_chunk >= num_chunks) {
            args[t].len = 0;
            continue;
        }
        size_t start_off = start_chunk * chunk;
        size_t end_off = end_chunk * chunk;
        if (end_off > pool_size) end_off = pool_size;
        args[t].buf = temp;
        args[t].off = start_off;
        args[t].len = end_off - start_off;
        pthread_create(&threads[t], NULL, collect_worker, &args[t]);
    }
    
    for (int t = 0; t < NUM_COLLECT_THREADS; t++) {
        if (args[t].len > 0)
            pthread_join(threads[t], NULL);
    }
    
    printf("Entropy collected (parallel).\n");
    
    // Copy to global pool and mix further
    memcpy(entropy_pool, temp, pool_size);
    free(temp);
    
    // Multiple mixing passes
    for (int pass = 0; pass < 3; pass++) {
        mix_with_jitter(entropy_pool, pool_size);
        // Re-inject hardware randomness
        for (size_t i = 0; i < pool_size; i += 64) {
            uint64_t hw = get_hardware_random64();
            if (hw) {
                for (size_t j = 0; j < 8 && i+j < pool_size; j++) {
                    entropy_pool[i+j] ^= (hw >> (j*8)) & 0xFF;
                }
            }
        }
    }
    
    printf("Entropy pool initialized (%zu bytes)\n", pool_size);
    
    // Verify non-zero
    int all_zero = 1;
    for (size_t i = 0; i < pool_size && all_zero; i++) {
        if (entropy_pool[i] != 0) all_zero = 0;
    }
    if (all_zero) fprintf(stderr, "WARNING: Entropy pool appears all zero!\n");
}

// Get random byte with thread-safe access
uint8_t get_entropy_byte(void) {
    if (!entropy_pool) init_entropy();
    pthread_mutex_lock(&entropy_mutex);

    uint32_t index;
    uint64_t hw_index = get_hardware_random64();
    if (hw_index) {
        index = hw_index & 0xFFFFFFFF;
    } else if (RAND_bytes((uint8_t*)&index, sizeof(index)) != 1) {
        index = get_jitter() ^ (uint32_t)clock() ^ (uint32_t)time(NULL);
    }

    uint8_t result = entropy_pool[index % pool_size];

    // Refresh every 1,000 bytes consumed (not calls)
    static size_t bytes_consumed = 0;
    if (++bytes_consumed >= 1000) {
        uint8_t new_byte;
        gather_all_entropy(&new_byte, 1);
        uint32_t refresh_index;
        if (RAND_bytes((uint8_t*)&refresh_index, sizeof(refresh_index)) != 1) {
            refresh_index = get_jitter() & 0xFFFFFFFF;
        }
        entropy_pool[refresh_index % pool_size] ^= new_byte;
        bytes_consumed = 0;
    }

    pthread_mutex_unlock(&entropy_mutex);
    return result;
}

// Fill buffer with enhanced entropy
void fill_with_entropy(uint8_t *buffer, size_t len) {
    if (!entropy_pool) init_entropy();
    pthread_mutex_lock(&entropy_mutex);

    static size_t bytes_consumed = 0;   // separate counter for this function

    for (size_t i = 0; i < len; i++) {
        uint32_t index;
        uint64_t hw_idx = get_hardware_random64();
        if (hw_idx) {
            index = hw_idx & 0xFFFFFFFF;
        } else {
            if (RAND_bytes((uint8_t*)&index, sizeof(index)) != 1) {
                index = get_jitter() & 0xFFFFFFFF;
            }
        }

        uint8_t entropy_byte = entropy_pool[index % pool_size];
        entropy_byte ^= (get_jitter() >> (i % 56)) & 0xFF;

        uint64_t hw_rnd = get_hardware_random64();
        if (hw_rnd) {
            entropy_byte ^= (hw_rnd >> ((i * 13) % 56)) & 0xFF;
        }

        buffer[i] = entropy_byte;

        // Refresh after every 1,000 bytes
        if (++bytes_consumed >= 1000) {
            uint8_t new_byte;
            gather_all_entropy(&new_byte, 1);
            uint32_t refresh_index;
            if (RAND_bytes((uint8_t*)&refresh_index, sizeof(refresh_index)) != 1) {
                refresh_index = get_jitter() & 0xFFFFFFFF;
            }
            entropy_pool[refresh_index % pool_size] ^= new_byte;
            bytes_consumed = 0;
        }
    }

    pthread_mutex_unlock(&entropy_mutex);
}

// Matrix filler for Rubik's cube face (legacy compatibility)
void fill_with_entropy_matrix(uint8_t matrix[MATRIX_SIZE][MATRIX_SIZE], size_t data_len) {
    size_t total_cells = MATRIX_SIZE * MATRIX_SIZE;
    if (data_len >= total_cells) return;
    
    size_t remaining = total_cells - data_len;
    uint8_t *start = &matrix[0][0] + data_len;
    fill_with_entropy(start, remaining);
}

// Clean up entropy pool
void cleanup_entropy(void) {
    if (entropy_pool) {
        OPENSSL_cleanse(entropy_pool, pool_size);
        free(entropy_pool);
        entropy_pool = NULL;
	pool_size = 0;
    }
}

// Get entropy pool statistics (for debugging)
void print_entropy_stats(void) {
    if (!entropy_pool) {
        printf("Entropy pool not initialized\n");
        return;
    }
    
    uint32_t sum = 0;
    uint32_t min = 255, max = 0;
    for (size_t i = 0; i < pool_size; i++) {
        sum += entropy_pool[i];
        if (entropy_pool[i] < min) min = entropy_pool[i];
        if (entropy_pool[i] > max) max = entropy_pool[i];
    }
    double avg = (double)sum / pool_size;
    
    printf("Entropy pool stats: size=%zu, avg=%.2f, min=%u, max=%u\n",
           pool_size, avg, min, max);
    
#if defined(__x86_64__) || defined(_M_X64)
    printf("Hardware RNG: RDSEED=%s, RDRAND=%s\n",
           has_rdseed ? "yes" : "no",
           has_rdrand ? "yes" : "no");
#endif
}
