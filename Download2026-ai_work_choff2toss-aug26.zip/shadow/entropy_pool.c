#include "entropy_pool.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <unistd.h>
#include <time.h>

uint32_t entropy_pool[NUM_POOLS][POOL_SIZE];
val_ascii_entry *sorted_table = NULL;
size_t table_size = 0;

static int compare_entries(const void *a, const void *b) {
    uint32_t va = ((const val_ascii_entry*)a)->val;
    uint32_t vb = ((const val_ascii_entry*)b)->val;
    return (va > vb) - (va < vb);
}

void build_sorted_table(void) {
    table_size = NUM_POOLS * POOL_SIZE;
    sorted_table = malloc(table_size * sizeof(val_ascii_entry));
    if (!sorted_table) { perror("malloc sorted_table"); exit(1); }
    size_t idx = 0;
    for (int ascii = MIN_ASCII; ascii <= MAX_ASCII; ascii++) {
        uint32_t *pool = entropy_pool[ascii - MIN_ASCII];
        for (int i = 0; i < POOL_SIZE; i++) {
            sorted_table[idx].val = pool[i];
            sorted_table[idx].ascii = (uint8_t)ascii;
            idx++;
        }
    }
    qsort(sorted_table, table_size, sizeof(val_ascii_entry), compare_entries);
}

int find_ascii_hash(uint32_t val) {
    if (!sorted_table) build_sorted_table();
    int lo = 0, hi = (int)table_size - 1;
    while (lo <= hi) {
        int mid = (lo + hi) / 2;
        if (sorted_table[mid].val == val)
            return sorted_table[mid].ascii;
        else if (sorted_table[mid].val < val)
            lo = mid + 1;
        else
            hi = mid - 1;
    }
    return -1;
}

/* Deterministic PRNG (xorshift64*) */
static uint64_t det_rng_state;

static uint64_t det_next(void) {
    uint64_t x = det_rng_state;
    x ^= x >> 12;
    x ^= x << 25;
    x ^= x >> 27;
    det_rng_state = x;
    return x * 0x2545F4914F6CDD1DULL;
}

static uint32_t det_urandom32(void) {
    return (uint32_t)(det_next() >> 32);
}

// ----------------------------------------------------------------------
// Hash set for uniqueness (same as before, but now deterministic)
// ----------------------------------------------------------------------
#define SET_SIZE (1 << 24)
static uint32_t *set = NULL;
static char *used = NULL;

static void set_init(void) {
    set = calloc(SET_SIZE, sizeof(uint32_t));
    used = calloc(SET_SIZE, 1);
}

static int set_add(uint32_t val) {
    uint32_t h = val & (SET_SIZE - 1);
    while (used[h]) {
        if (set[h] == val) return 0;
        h = (h + 1) & (SET_SIZE - 1);
    }
    set[h] = val;
    used[h] = 1;
    return 1;
}

static void set_free(void) {
    free(set); free(used);
    set = NULL; used = NULL;
}

// ----------------------------------------------------------------------
// Deterministic pool generation (uses the seed from the encrypted file)
// ----------------------------------------------------------------------
void generate_entropy_pools_deterministic(uint64_t seed) {
    det_rng_state = seed;
    printf("Generating deterministic entropy pools with seed 0x%016llx...\n", (unsigned long long)seed);
    set_init();
    for (int ascii = MIN_ASCII; ascii <= MAX_ASCII; ascii++) {
        //printf("  Pool for ASCII %d ('%c') ...\n", ascii, ascii);
        int count = 0;
        while (count < POOL_SIZE) {
            uint32_t val = det_urandom32();
            if (set_add(val)) {
                entropy_pool[ascii - MIN_ASCII][count++] = val;
            }
        }
    }
    set_free();
    build_sorted_table();
    printf("All pools generated.\n");
}
