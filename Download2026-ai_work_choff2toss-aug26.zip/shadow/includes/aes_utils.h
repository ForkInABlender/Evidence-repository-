#ifndef AES_UTILS_H
#define AES_UTILS_H

#include <stdint.h>
#include <stddef.h>

#define AES_GCM_IVLEN 12
#define AES_GCM_TAGLEN 16
#define AES_KEYLEN 32   // AES-256

// Encrypt with AES-256-GCM
// - in/out: plaintext/ciphertext (same length)
// - key: 32 bytes
// - iv: 12 bytes (must be unique per encryption)
// - tag_out: 16 bytes authentication tag
void aes_gcm_encrypt(const uint8_t *in, uint8_t *out, size_t len,
                     const uint8_t *key, const uint8_t *iv,
                     uint8_t *tag_out);

// Decrypt with AES-256-GCM
// - returns 0 on success (tag verified), -1 on failure
int aes_gcm_decrypt(const uint8_t *in, uint8_t *out, size_t len,
                    const uint8_t *key, const uint8_t *iv,
                    const uint8_t *tag);

#endif