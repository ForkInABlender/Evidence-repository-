#ifndef CHUNKED_IO_H
#define CHUNKED_IO_H

#include <stdint.h>
#include <stddef.h>

// Chunked mode (files of any size)
void do_encrypt_chunked(const char *input_file, const char *output_file,
                        char **pubkeys, int num_pubkeys);
void do_decrypt_chunked(const char *input_file, const char *output_file,
                        const char *keydir);

// Outer encryption wrapper (supports both formats)
int save_outer_encrypted(const char *path, const uint8_t *inner_data, size_t inner_len,
                         const char *outer_pub_key_path, int is_chunked, uint64_t num_chunks);
int load_outer_encrypted(const char *path, uint8_t **out_data, size_t *out_len,
                         const char *outer_priv_key_path, int *is_chunked, uint64_t *num_chunks);

#endif