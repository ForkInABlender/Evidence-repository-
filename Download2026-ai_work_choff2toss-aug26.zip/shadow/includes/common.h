#ifndef COMMON_H
#define COMMON_H

#include <stddef.h>
#include <stdint.h>

void die(const char *msg);

void check_add(size_t a, size_t b);
void check_mul(size_t a, size_t b);
void *xmalloc(size_t n);
void enc(const char *in,
         const char *carrier,
         const char *out,
         char **pubs,
         int n);
void dec(const char *keydir, const char *in, const char *out);

#endif