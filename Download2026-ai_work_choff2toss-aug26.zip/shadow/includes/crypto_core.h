#ifndef CRYPTO_CORE_H
#define CRYPTO_CORE_H

#include <stdint.h>
#include <stddef.h>
#include "rubik_cube.h"

void encrypt_cube_layer_simple(uint8_t cube[6][MATRIX_SIZE][MATRIX_SIZE],
                               shuffle_layer_t *sl);
void decrypt_cube_layer_simple(uint8_t cube[6][MATRIX_SIZE][MATRIX_SIZE],
                               const shuffle_layer_t *sl);

void generate_layer_metadata(shuffle_layer_t *sl);

void derive_ivs(const uint8_t *iv_seed, uint64_t chunk_idx, uint32_t layer_idx,
                uint8_t iv1[16], uint8_t iv2[16], uint8_t iv3[16]);

// New: added chunk_idx parameter for per‑chunk key derivation
void encrypt_cube_layer_ex(uint8_t cube[6][MATRIX_SIZE][MATRIX_SIZE],
                           shuffle_layer_t *sl,
                           const uint8_t *iv1,
                           uint64_t chunk_idx,
                           uint8_t *hmac_tag_out);

int decrypt_cube_layer_ex(uint8_t cube[6][MATRIX_SIZE][MATRIX_SIZE],
                          const shuffle_layer_t *sl,
                          const uint8_t *iv1,
                          uint64_t chunk_idx,
                          const uint8_t *hmac_tag);

#endif