#ifndef CRYPTO_UTILS_H
#define CRYPTO_UTILS_H

#include <stdint.h>
#include <stddef.h>
#include <openssl/crypto.h>

// Use the NIST-standardized ML-KEM-768 (formerly Kyber-768)
#define KEM_ALG OQS_KEM_alg_ml_kem_768

// Constant-time memory comparison (prevents timing side-channels)
static inline int constant_time_memcmp(const void *a, const void *b, size_t n) {
    const volatile uint8_t *pa = (const volatile uint8_t *)a;
    const volatile uint8_t *pb = (const volatile uint8_t *)b;
    volatile uint8_t diff = 0;
    for (size_t i = 0; i < n; i++) {
        diff |= pa[i] ^ pb[i];
    }
    return (diff != 0);
}

// Constant-time version of memcmp that returns 0 on match (like regular memcmp)
static inline int ct_memcmp(const void *a, const void *b, size_t n) {
    return constant_time_memcmp(a, b, n);
}

#endif
