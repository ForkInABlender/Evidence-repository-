#ifndef ENCODING_H
#define ENCODING_H

#include <stdint.h>
#include <stddef.h>
#include "entropy_pool.h"

// Functions used by chunked_io.c
uint8_t* encode_file_to_cubes(const char *input_path, const char *metadata_path,
                              uint64_t base_seed, size_t *out_len);

void decode_cubes_to_file(const char *cubes_path, const char *metadata_path,
                          const char *output_path);

uint8_t* encode_message_to_cubes(const char *message, int msg_len,
                                 uint64_t base_seed,
                                 uint8_t **metadata_out,
                                 size_t *out_cubes_len);

char* decode_message_from_cubes(const uint8_t *cubes_data, size_t cubes_len,
                                const uint8_t *metadata, size_t metadata_len,
                                int *out_msg_len);

#endif
