#ifndef ENTROPY_H
#define ENTROPY_H

#include <stdint.h>
#include <stddef.h>

#define ENTROPY_BYTES_PER_ENTRY (1024 * 1024)  // 1KB entropy pool
#define MATRIX_SIZE 8  // For compatibility with main.c

// Initialize entropy pool (call once at program start)
void init_entropy(void);

// Clean up entropy pool
void cleanup_entropy(void);

// Get a random byte from the entropy pool (cryptographically random selection)
uint8_t get_entropy_byte(void);

// Fill a buffer with entropy (for bulk operations)
void fill_with_entropy(uint8_t *buffer, size_t len);

// Legacy function for backward compatibility with main.c
void fill_with_entropy_matrix(uint8_t matrix[MATRIX_SIZE][MATRIX_SIZE], size_t data_len);

// Get high-quality random bytes directly
int get_random_bytes(uint8_t *buffer, size_t len);

// Print entropy pool statistics (for debugging)
void print_entropy_stats(void);

#endif
