#ifndef ENTROPY_POOL_H
#define ENTROPY_POOL_H

#include <stdint.h>
#include <stddef.h>

#define MIN_ASCII 0
#define MAX_ASCII 255
#define POOL_SIZE 10000            // numbers per character
#define NUM_POOLS (MAX_ASCII - MIN_ASCII + 1)  // 256

typedef struct {
    uint32_t val;
    uint8_t ascii;
} val_ascii_entry;

extern uint32_t entropy_pool[NUM_POOLS][POOL_SIZE];
extern val_ascii_entry *sorted_table;
extern size_t table_size;

// Generate all pools (must be called once)
void generate_entropy_pools(void);
void save_pools_to_file(const char *filename);
void build_sorted_table(void);
int find_ascii_hash(uint32_t val);
void generate_entropy_pools_deterministic(uint64_t seed);

#endif
