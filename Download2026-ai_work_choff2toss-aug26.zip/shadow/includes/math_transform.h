#ifndef MATH_TRANSFORM_H
#define MATH_TRANSFORM_H

#include <stdint.h>

#define MATRIX_SIZE 64
#define NUM_FACES 6

typedef uint32_t face_t[MATRIX_SIZE][MATRIX_SIZE];
typedef uint32_t cube_t[NUM_FACES][MATRIX_SIZE][MATRIX_SIZE];

// Apply a sequence of matrix additions (recorded in a file)
void apply_math_transforms(cube_t cube, const char *steps_file);

// Reverse the transforms using the same steps file
void revert_math_transforms(cube_t cube, const char *steps_file);

#endif
