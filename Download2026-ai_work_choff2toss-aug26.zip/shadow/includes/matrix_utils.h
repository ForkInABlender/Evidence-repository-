#ifndef MATRIX_UTILS_H
#define MATRIX_UTILS_H

#include <stdint.h>

/* ----- GF(256) arithmetic ----- */
uint8_t gf256_mul(uint8_t a, uint8_t b);
uint8_t gf256_inv(uint8_t a);

/* ----- 8×8 matrix operations (per‑face affine) ----- */
void matrix_mul(const uint8_t a[8][8], const uint8_t b[8][8], uint8_t out[8][8]);
int matrix_invert(const uint8_t in[8][8], uint8_t out[8][8]);
void affine_transform(const uint8_t in[8][8], const uint8_t M[8][8],
                      const uint8_t C[8], uint8_t out[8][8]);

/* ----- 6×6 matrix operations (face mixing) ----- */
void generate_invertible_matrix_6x6(uint8_t out[6][6]);
int matrix_invert_6x6(const uint8_t in[6][6], uint8_t out[6][6]);
void mix_faces(uint8_t cube[6][8][8], const uint8_t M[6][6]);

#endif
