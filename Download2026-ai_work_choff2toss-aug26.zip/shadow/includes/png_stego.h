#ifndef PNG_STEGO_H
#define PNG_STEGO_H

#include <stdint.h>
#include <stddef.h>

void embed_png(const char *carrier,
               const char *outfile,
               const uint8_t *data,
               size_t len,
	       const char *password);

uint8_t *read_png(const char *file,size_t *out_len, const char *password);

#endif