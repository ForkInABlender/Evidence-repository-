#pragma once

#include <openssl/evp.h>
#include <stdint.h>
#include <stddef.h>

typedef struct {
    EVP_CIPHER_CTX *ctx;
    uint8_t zero_buf[1024]; // buffer of zeros to XOR against
} prng_state_t;

int  prng_init(prng_state_t *state, const uint8_t *key32);
int  prng_generate(prng_state_t *state, uint8_t *out, size_t len);
void prng_free(prng_state_t *state);
uint8_t prng_get_byte(prng_state_t *state);
