#ifndef RUBIK_H
#define RUBIK_H

#include <stdint.h>
#include <stdbool.h>
#include <stddef.h>

#define MATRIX_SIZE 256

void rotate_row(uint8_t matrix[MATRIX_SIZE][MATRIX_SIZE], int row, bool reverse);
void rotate_col(uint8_t matrix[MATRIX_SIZE][MATRIX_SIZE], int col, bool reverse);

#endif // RUBIK_H
