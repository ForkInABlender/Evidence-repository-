#ifndef RUBIK_CUBE_H
#define RUBIK_CUBE_H

#include <stdint.h>
#include <stddef.h>

#define MATRIX_SIZE 8
#define NUM_MOVES 256
#define CBC_IVLEN 16
#define HMAC_KEYLEN 32
#define HMAC_TAGLEN 32

typedef struct {
    uint8_t aes_key1[32];
    uint8_t aes_key2[32];
    uint8_t aes_key3[32];
    uint8_t hmac_key[HMAC_KEYLEN];
    uint8_t transform_seed[32];
    uint8_t shuffle_seed[32];
    uint8_t cbc_iv1[CBC_IVLEN];
    uint8_t cbc_iv2[CBC_IVLEN];
    uint8_t cbc_iv3[CBC_IVLEN];
    uint8_t hmac_tag[HMAC_TAGLEN];
    char transform_key[1024];
    uint8_t mix_matrix[6][6];
    uint8_t mix_matrix_inv[6][6];
    uint8_t sbox[256];       // forward substitution
    uint8_t inv_sbox[256];   // inverse substitution
} shuffle_layer_t;

typedef struct {
    size_t layer_count;
    shuffle_layer_t layers[128];
} cube_metadata_layers_t;

// Cube faces
enum {
    UP = 0,
    DOWN = 1,
    LEFT = 2,
    RIGHT = 3,
    FRONT = 4,
    BACK = 5
};

// Function prototypes
void shuffle_cube(uint8_t cube[6][MATRIX_SIZE][MATRIX_SIZE], char *transform_key, size_t key_size,
                  const uint8_t *shuffle_seed);
void unshuffle_cube(uint8_t cube[6][MATRIX_SIZE][MATRIX_SIZE], const char *transform_key);
void rotate_face_clockwise(uint8_t face[MATRIX_SIZE][MATRIX_SIZE]);
void rotate_face_counterclockwise(uint8_t face[MATRIX_SIZE][MATRIX_SIZE]);

// Move functions
void move_U(uint8_t cube[6][MATRIX_SIZE][MATRIX_SIZE]);
void move_D(uint8_t cube[6][MATRIX_SIZE][MATRIX_SIZE]);
void move_L(uint8_t cube[6][MATRIX_SIZE][MATRIX_SIZE]);
void move_R(uint8_t cube[6][MATRIX_SIZE][MATRIX_SIZE]);
void move_F(uint8_t cube[6][MATRIX_SIZE][MATRIX_SIZE]);
void move_B(uint8_t cube[6][MATRIX_SIZE][MATRIX_SIZE]);
void move_U_inverse(uint8_t cube[6][MATRIX_SIZE][MATRIX_SIZE]);
void move_D_inverse(uint8_t cube[6][MATRIX_SIZE][MATRIX_SIZE]);
void move_L_inverse(uint8_t cube[6][MATRIX_SIZE][MATRIX_SIZE]);
void move_R_inverse(uint8_t cube[6][MATRIX_SIZE][MATRIX_SIZE]);
void move_F_inverse(uint8_t cube[6][MATRIX_SIZE][MATRIX_SIZE]);
void move_B_inverse(uint8_t cube[6][MATRIX_SIZE][MATRIX_SIZE]);

#endif