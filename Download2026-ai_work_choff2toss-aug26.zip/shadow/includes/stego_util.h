#ifndef STEGO_UTIL_H
#define STEGO_UTIL_H

#include <stdint.h>
#include <stddef.h>
#include <stdio.h>

void die(const char *msg);
void *xmalloc(size_t n);
FILE *xfopen(const char *p, const char *m);
void xfread(void *b, size_t n, FILE *f);
void xfwrite(const void *b, size_t n, FILE *f);
void put_u32(uint8_t *b, uint32_t v);
uint32_t get_u32(const uint8_t *b);
void check_add(size_t a, size_t b);
void check_mul(size_t a, size_t b);

#endif