#ifndef UTILS_H
#define UTILS_H

#include <stdint.h>
#include <stddef.h>
#include "rubik_cube.h"

#define CUBE_CAPACITY (6 * MATRIX_SIZE * MATRIX_SIZE)

// File I/O utilities
uint8_t* read_file(const char *filename, size_t *out_len);
void print_face0_preview(const uint8_t cube[6][MATRIX_SIZE][MATRIX_SIZE], 
                         const char *label, size_t len);

// RSA key management
void generate_rsa_keypair(const char *priv_path, const char *pub_path);

#endif