#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <termios.h>
#include <dirent.h>
#include <zlib.h>
#include <openssl/crypto.h>
#include <oqs/oqs.h>
#include "chunked_io.h"
#include "crypto_utils.h"
#include "utils.h"
#include "png_stego.h"
#include "stego_util.h"
#include "encoding.h"

// Helper function to check if a file exists
static int file_exists(const char *path) {
    FILE *f = fopen(path, "rb");
    if (f) {
        fclose(f);
        return 1;
    }
    return 0;
}

// Helper function to validate all public keys exist
static int validate_pubkeys(char **pubkeys, int num_pubkeys) {
    int all_exist = 1;
    for (int i = 0; i < num_pubkeys; i++) {
        if (!file_exists(pubkeys[i])) {
            fprintf(stderr, "Error: Public key file not found: %s\n", pubkeys[i]);
            all_exist = 0;
        }
    }
    return all_exist;
}

// Helper function to check if directory contains any .sec files
static int has_sec_files(const char *dirpath) {
    DIR *dir = opendir(dirpath);
    if (!dir) return 0;
    struct dirent *entry;
    int found = 0;
    while ((entry = readdir(dir)) != NULL) {
        if (strstr(entry->d_name, ".sec")) {
            found = 1;
            break;
        }
    }
    closedir(dir);
    return found;
}

void show_help(const char *prog) {
    printf("Usage: %s -e -f <infile> [-o <outfile.png>] [-s <carrier.png>] [-r pubkey...]\n", prog);
    printf("       %s -d -i <infile> [-o <outfile.png>] [-x] [-k keydir]\n", prog);
    printf("       %s -g <username>\n", prog);
    printf("       %s -h\n", prog);
    printf("\nOptions:\n");
    printf("  -g <username>     Generate ML‑KEM‑768 key pair for the user (exclusive, no other flags)\n");
    printf("  -d <keydir>       Directory to save/load keys (default: current directory)\n");
    printf("  -s <carrier.png>  Embed encrypted data into PNG carrier (instead of raw output)\n");
    printf("  -x <stego.png>    Extract hidden data from input PNG before decrypting\n");
    printf("  -r <pubkey>       Add recipient (can be repeated)\n");
    printf("  -k <keydir>       Directory containing secret key files (.sec) for decryption\n");
}

static void prompt_password(const char *prompt, char *password, size_t max_len) {
    fprintf(stderr, "%s", prompt);
    fflush(stderr);
    struct termios old, new;
    tcgetattr(STDIN_FILENO, &old);
    new = old;
    new.c_lflag &= ~ECHO;
    tcsetattr(STDIN_FILENO, TCSANOW, &new);
    if (!fgets(password, max_len, stdin)) {
        password[0] = '\0';
    } else {
        size_t len = strlen(password);
        if (len > 0 && password[len-1] == '\n') password[len-1] = '\0';
    }
    tcsetattr(STDIN_FILENO, TCSANOW, &old);
    fprintf(stderr, "\n");
} 

void generate_keys(const char *username, const char *keydir) {
    char pubpath[512], secpath[512];
    
    if (keydir) {
        snprintf(pubpath, sizeof(pubpath), "%s/%s.pub", keydir, username);
        snprintf(secpath, sizeof(secpath), "%s/%s.sec", keydir, username);
    } else {
        snprintf(pubpath, sizeof(pubpath), "%s.pub", username);
        snprintf(secpath, sizeof(secpath), "%s.sec", username);
    }
    
    // Check if files already exist
    FILE *test = fopen(pubpath, "rb");
    if (test) {
        fclose(test);
        fprintf(stderr, "Warning: %s already exists. Overwrite? (y/N): ", pubpath);
        char answer[10];
        if (!fgets(answer, sizeof(answer), stdin) || (answer[0] != 'y' && answer[0] != 'Y')) {
            fprintf(stderr, "Key generation cancelled.\n");
            return;
        }
    }
    
    test = fopen(secpath, "rb");
    if (test) {
        fclose(test);
        fprintf(stderr, "Warning: %s already exists. Overwrite? (y/N): ", secpath);
        char answer[10];
        if (!fgets(answer, sizeof(answer), stdin) || (answer[0] != 'y' && answer[0] != 'Y')) {
            fprintf(stderr, "Key generation cancelled.\n");
            return;
        }
    }
    
    printf("Generating ML‑KEM‑768 key pair for '%s'...\n", username);
    OQS_KEM *kem = OQS_KEM_new(KEM_ALG);
    if (!kem) {
        fprintf(stderr, "Failed to initialize ML‑KEM‑768\n");
        exit(EXIT_FAILURE);
    }
    
    uint8_t *pub = malloc(kem->length_public_key);
    uint8_t *sec = malloc(kem->length_secret_key);
    if (!pub || !sec) {
        fprintf(stderr, "Memory allocation failed\n");
        OQS_KEM_free(kem);
        exit(EXIT_FAILURE);
    }
    
    if (OQS_KEM_keypair(kem, pub, sec) != OQS_SUCCESS) {
        fprintf(stderr, "Key pair generation failed\n");
        free(pub);
        free(sec);
        OQS_KEM_free(kem);
        exit(EXIT_FAILURE);
    }
    
    // Save public key
    FILE *f = fopen(pubpath, "wb");
    if (!f) {
        perror("fopen pub");
        free(pub);
        free(sec);
        OQS_KEM_free(kem);
        exit(EXIT_FAILURE);
    }
    fwrite(pub, 1, kem->length_public_key, f);
    fclose(f);
    
    // Save secret key (with public key prepended as loader expects)
    f = fopen(secpath, "wb");
    if (!f) {
        perror("fopen sec");
        free(pub);
        free(sec);
        OQS_KEM_free(kem);
        exit(EXIT_FAILURE);
    }
    fwrite(pub, 1, kem->length_public_key, f);
    fwrite(sec, 1, kem->length_secret_key, f);
    fclose(f);
    
    printf("Keys generated successfully:\n");
    printf("  Public key:  %s (%zu bytes)\n", pubpath, kem->length_public_key);
    printf("  Secret key:  %s (%zu bytes)\n", secpath, kem->length_public_key + kem->length_secret_key);
    
    free(pub);
    free(sec);
    OQS_KEM_free(kem);
}

void do_encrypt(const char *input_file, const char *output_file,
                char **pubkeys, int num_pubkeys) {
    do_encrypt_chunked(input_file, output_file, pubkeys, num_pubkeys);
}

void do_decrypt(const char *input_file, const char *output_file, const char *keydir) {
    do_decrypt_chunked(input_file, output_file, keydir);
}

int main(int argc, char **argv) {
    int mode = 0;                     // 0=unset, 1=encrypt, 2=decrypt, 3=generate
    int stego_mode = 0;
    char *carrier = NULL;
    char *keydir = NULL;
    char *gen_username = NULL;
    char *gen_keydir = NULL;
    char *input_file = NULL, *output_file = NULL;
    char *pubkeys[128];
    int num_pubkeys = 0;
    int gen_mode_active = 0;

    for (int i = 1; i < argc; i++) {
        if (strcmp(argv[i], "-h") == 0) {
            show_help(argv[0]);
            return 0;
        }
        else if (strcmp(argv[i], "-e") == 0) {
            if (mode != 0) {
                fprintf(stderr, "Error: Cannot combine -e with other operation flags.\n");
                return 1;
            }
            mode = 1;
        }
        else if (strcmp(argv[i], "-d") == 0) {
            if (mode != 0) {
                fprintf(stderr, "Error: Cannot combine -d with other operation flags.\n");
                return 1;
            }
            mode = 2;
        }
        else if (strcmp(argv[i], "-g") == 0 && i+1 < argc) {
            if (mode != 0) {
                fprintf(stderr, "Error: Cannot combine -g with other operation flags.\n");
                return 1;
            }
            mode = 3;
            gen_mode_active = 1;
            gen_username = argv[++i];
        }
        else if (strcmp(argv[i], "-s") == 0 && i+1 < argc) {
            if (gen_mode_active) {
                fprintf(stderr, "Error: -s cannot be used with key generation (-g)\n");
                return 1;
            }
            stego_mode = 1;
            carrier = argv[++i];
        }
        else if (strcmp(argv[i], "-x") == 0) {
            if (gen_mode_active) {
                fprintf(stderr, "Error: -x cannot be used with key generation (-g)\n");
                return 1;
            }
            stego_mode = 2;
        }
        else if (strcmp(argv[i], "-r") == 0 && i+1 < argc) {
            if (gen_mode_active) {
                fprintf(stderr, "Error: -r cannot be used with key generation (-g)\n");
                return 1;
            }
            if (num_pubkeys < 128) {
                pubkeys[num_pubkeys++] = argv[++i];
            } else {
                die("Too many recipients");
            }
        }
        else if (strcmp(argv[i], "-k") == 0 && i+1 < argc) {
            // -k can be used with any mode, but we need to assign to the correct variable
            if (mode == 3) {
                gen_keydir = argv[++i];
            } else {
                keydir = argv[++i];
            }
        }
        else if (strcmp(argv[i], "-f") == 0 && i+1 < argc) {
            if (gen_mode_active) {
                fprintf(stderr, "Error: -f cannot be used with key generation (-g)\n");
                return 1;
            }
            input_file = argv[++i];
        }
        else if (strcmp(argv[i], "-i") == 0 && i+1 < argc) {
            if (gen_mode_active) {
                fprintf(stderr, "Error: -i cannot be used with key generation (-g)\n");
                return 1;
            }
            input_file = argv[++i];
        }
        else if (strcmp(argv[i], "-o") == 0 && i+1 < argc) {
            if (gen_mode_active) {
                fprintf(stderr, "Error: -o cannot be used with key generation (-g)\n");
                return 1;
            }
            output_file = argv[++i];
        }
        else {
            fprintf(stderr, "Unknown option: %s\n", argv[i]);
            return 1;
        }
    }

    if (mode == 0) {
        show_help(argv[0]);
        return 0;
    }

    // Handle key generation mode (no other flags allowed)
    if (mode == 3) {
        if (!gen_username) {
            fprintf(stderr, "Error: -g requires a username\n");
            return 1;
        }
        // Ensure no other input/output files or recipients were accidentally set
        if (input_file || output_file || num_pubkeys > 0 || stego_mode != 0) {
            fprintf(stderr, "Error: Key generation (-g) cannot be combined with encryption/decryption options.\n");
            return 1;
        }
        generate_keys(gen_username, gen_keydir);
        return 0;
    }

    // Validate files for encryption mode
    if (mode == 1) {
        if (!input_file) {
            fprintf(stderr, "Error: -e requires -f <infile>\n");
            return 1;
        }
        if (!file_exists(input_file)) {
            fprintf(stderr, "Error: Input file not found: %s\n", input_file);
            return 1;
        }
        
        if (num_pubkeys == 0) {
            fprintf(stderr, "Error: At least one recipient (-r pubkey) required\n");
            return 1;
        }
        if (!validate_pubkeys(pubkeys, num_pubkeys)) {
            return 1;
        }
        
        if (stego_mode == 1) {
            if (!carrier) {
                fprintf(stderr, "Error: -s requires carrier image file\n");
                return 1;
            }
            if (!file_exists(carrier)) {
                fprintf(stderr, "Error: Carrier image not found: %s\n", carrier);
                return 1;
            }
        }
        
        if (!output_file) output_file = (stego_mode == 1) ? "stego.png" : "encrypted.bin";
    }
    
    // Validate for decryption mode
    else if (mode == 2) {
        if (!input_file) {
            if (stego_mode == 2) {
                input_file = "stego.png";
            } else {
                input_file = "encrypted.bin";
            }
        }
        if (!file_exists(input_file)) {
            fprintf(stderr, "Error: Input file not found: %s\n", input_file);
            return 1;
        }
        
        if (!output_file) output_file = "recovered.bin";
        
        // Check if key directory exists and contains .sec files
        if (keydir && !file_exists(keydir)) {
            fprintf(stderr, "Error: Key directory '%s' does not exist\n", keydir);
            return 1;
        } else if (!keydir) {
            keydir = ".";
        }
        
        // Check if there are any .sec files in the key directory
        if (!has_sec_files(keydir)) {
            fprintf(stderr, "Error: No .sec files found in key directory '%s'\n", keydir);
            fprintf(stderr, "Please generate a key pair with -g or place your .sec files there.\n");
            return 1;
        }
    }

    if (mode == 1) {
        if (stego_mode == 1) {
            char scatter_password[256], confirm[256];
            int matched = 0, attempts = 0;
            while (!matched && attempts < 3) {
                prompt_password("Enter scatter password (for steganography): ", scatter_password, sizeof(scatter_password));
                prompt_password("Confirm scatter password: ", confirm, sizeof(confirm));
                if (strcmp(scatter_password, confirm) == 0) {
                    matched = 1;
                } else {
                    fprintf(stderr, "Passwords do not match. Try again.\n");
                    OPENSSL_cleanse(scatter_password, sizeof(scatter_password));
                    OPENSSL_cleanse(confirm, sizeof(confirm));
                    attempts++;
                }
            }
            if (!matched) die("Too many attempts");
            OPENSSL_cleanse(confirm, sizeof(confirm));

            char temp_raw[] = "temp_encrypted.bin";
            printf("Encrypting file '%s'...\n", input_file);
            do_encrypt(input_file, temp_raw, pubkeys, num_pubkeys);

            size_t data_len;
            uint8_t *data = read_file(temp_raw, &data_len);
            if (!data) die("Failed to read encrypted file");

            // Compress the encrypted data
            uLongf compressed_len = compressBound(data_len);
            uint8_t *compressed = malloc(compressed_len + 4);
            if (!compressed) die("malloc");
            compressed[0] = data_len & 0xff;
            compressed[1] = (data_len >> 8) & 0xff;
            compressed[2] = (data_len >> 16) & 0xff;
            compressed[3] = (data_len >> 24) & 0xff;
            int ret = compress2(compressed + 4, &compressed_len, data, data_len, 9);
            if (ret != Z_OK) die("Compression failed");
            free(data);
            size_t total_compressed = compressed_len + 4;
	    printf("Repacking compression.\n");

            printf("Embedding into PNG carrier '%s'...\n", carrier);
            embed_png(carrier, output_file, compressed, total_compressed, scatter_password);
            OPENSSL_cleanse(scatter_password, sizeof(scatter_password));
            free(compressed);
            unlink(temp_raw);
            printf("Encryption complete! Output saved to '%s'\n", output_file);
	    printf("Death to all those who stand in the way of freedom for the working people!\n");
        } else {
            printf("Encrypting file '%s' to '%s'...\n", input_file, output_file);
            do_encrypt(input_file, output_file, pubkeys, num_pubkeys);
        }
    } else if (mode == 2) {
        if (stego_mode == 2) {
            char scatter_password[256];
            prompt_password("Enter scatter password (for steganography): ", scatter_password, sizeof(scatter_password));

            printf("Extracting hidden data from PNG '%s'...\n", input_file);
            size_t extracted_len;
            uint8_t *extracted = read_png(input_file, &extracted_len, scatter_password);
            OPENSSL_cleanse(scatter_password, sizeof(scatter_password));
            if (!extracted) die("Failed to extract hidden data from PNG");

            if (extracted_len < 4) die("Extracted data too short");
            size_t orig_len = extracted[0] | (extracted[1]<<8) | (extracted[2]<<16) | (extracted[3]<<24);
            if (orig_len > 100*1024*1024) die("Decompressed size too large");
            uint8_t *decompressed = malloc(orig_len);
            if (!decompressed) die("malloc");
            uLongf decomp_len = orig_len;
            int zret = uncompress(decompressed, &decomp_len, extracted + 4, extracted_len - 4);
            free(extracted);
            if (zret != Z_OK) die("Decompression failed");
            if (decomp_len != orig_len) die("Decompressed size mismatch");

            char temp_raw[] = "temp_extracted.bin";
            FILE *tmp = fopen(temp_raw, "wb");
            if (!tmp) die("Cannot create temp file");
            fwrite(decompressed, 1, decomp_len, tmp);
            fclose(tmp);
            free(decompressed);

            printf("Decrypting extracted data to '%s'...\n", output_file);
            do_decrypt(temp_raw, output_file, keydir);
            unlink(temp_raw);
        } else {
            printf("Decrypting file '%s' to '%s'...\n", input_file, output_file);
            do_decrypt(input_file, output_file, keydir);
        }
    }

    // At the end, before return 0:
    OQS_destroy();

    return 0;
}
