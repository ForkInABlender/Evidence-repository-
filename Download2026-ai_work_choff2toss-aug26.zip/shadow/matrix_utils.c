#include "matrix_utils.h"
#include <openssl/rand.h>
#include <string.h>
#include <stdio.h>

/* ------------------------------------------------------------------------- */
/* GF(256) arithmetic using AES irreducible polynomial - CONSTANT TIME      */
/* ------------------------------------------------------------------------- */

// Constant-time GF(256) multiplication using table lookup (precomputed)
static uint8_t gf256_mul_table[256][256];
static int gf256_tables_initialized = 0;

static void init_gf256_tables(void) {
    if (gf256_tables_initialized) return;
    
    // Build multiplication table using the standard algorithm (once, at startup)
    for (int a = 0; a < 256; a++) {
        for (int b = 0; b < 256; b++) {
            uint8_t p = 0;
            uint8_t aa = (uint8_t)a;
            uint8_t bb = (uint8_t)b;
            for (int i = 0; i < 8; i++) {
                if (bb & 1) p ^= aa;
                uint8_t hi = aa & 0x80;
                aa <<= 1;
                if (hi) aa ^= 0x1B;
                bb >>= 1;
            }
            gf256_mul_table[a][b] = p;
        }
    }
    gf256_tables_initialized = 1;
}

uint8_t gf256_mul(uint8_t a, uint8_t b) {
    init_gf256_tables();
    return gf256_mul_table[a][b];
}

// Constant-time power using table (or loop with no early exits)
static uint8_t gf256_pow(uint8_t a, uint16_t exp) {
    uint8_t result = 1;
    while (exp) {
        if (exp & 1) result = gf256_mul(result, a);
        a = gf256_mul(a, a);
        exp >>= 1;
    }
    return result;
}

uint8_t gf256_inv(uint8_t a) {
    if (a == 0) return 0;
    return gf256_pow(a, 254);
}

/* ----- 8×8 matrix multiplication (already constant-time due to gf256_mul) ----- */
void matrix_mul(const uint8_t a[8][8], const uint8_t b[8][8], uint8_t out[8][8]) {
    for (int i = 0; i < 8; i++)
        for (int j = 0; j < 8; j++) {
            uint8_t sum = 0;
            for (int k = 0; k < 8; k++)
                sum ^= gf256_mul(a[i][k], b[k][j]);
            out[i][j] = sum;
        }
}

/* ----- 6×6 matrix generation (LU product, always invertible) ----- */
void generate_invertible_matrix_6x6(uint8_t out[6][6]) {
    uint8_t L[6][6] = {0}, U[6][6] = {0};
    for (int i = 0; i < 6; i++) {
        L[i][i] = 1;
        for (int j = 0; j < i; j++) {
            if (RAND_bytes(&L[i][j], 1) != 1) {
                fprintf(stderr, "RAND_bytes failed in matrix generation\n");
                exit(EXIT_FAILURE);
            }
        }
        U[i][i] = 1;
        for (int j = i + 1; j < 6; j++) {
            if (RAND_bytes(&U[i][j], 1) != 1) {
                fprintf(stderr, "RAND_bytes failed in matrix generation\n");
                exit(EXIT_FAILURE);
            }
        }
    }
    // Multiply L × U
    memset(out, 0, 36);
    for (int i = 0; i < 6; i++)
        for (int j = 0; j < 6; j++) {
            uint8_t sum = 0;
            for (int k = 0; k < 6; k++)
                sum ^= gf256_mul(L[i][k], U[k][j]);
            out[i][j] = sum;
        }
}

/* ----- 6×6 matrix inversion ----- */
int matrix_invert_6x6(const uint8_t in[6][6], uint8_t out[6][6]) {
    uint8_t a[6][12];
    memset(a, 0, sizeof(a));
    for (int i = 0; i < 6; i++) {
        memcpy(a[i], in[i], 6);
        a[i][6 + i] = 1;
    }
    for (int col = 0; col < 6; col++) {
        int pivot = -1;
        for (int row = col; row < 6; row++)
            if (a[row][col] != 0) { pivot = row; break; }
        if (pivot == -1) return -1;
        if (pivot != col)
            for (int j = 0; j < 12; j++) {
                uint8_t t = a[col][j];
                a[col][j] = a[pivot][j];
                a[pivot][j] = t;
            }
        uint8_t inv = gf256_inv(a[col][col]);
        for (int j = 0; j < 12; j++) a[col][j] = gf256_mul(a[col][j], inv);
        for (int row = 0; row < 6; row++) {
            if (row != col && a[row][col] != 0) {
                uint8_t factor = a[row][col];
                for (int j = 0; j < 12; j++)
                    a[row][j] ^= gf256_mul(factor, a[col][j]);
            }
        }
    }
    for (int i = 0; i < 6; i++)
        for (int j = 0; j < 6; j++)
            out[i][j] = a[i][6 + j];
    return 0;
}

/* ----- Mix all six faces using a 6×6 matrix (over GF(256)) ----- */
void mix_faces(uint8_t cube[6][8][8], const uint8_t M[6][6]) {
    uint8_t new_cube[6][8][8] = {0};
    for (int i = 0; i < 8; i++) {
        for (int j = 0; j < 8; j++) {
            for (int f = 0; f < 6; f++) {
                uint8_t sum = 0;
                for (int g = 0; g < 6; g++)
                    sum ^= gf256_mul(M[f][g], cube[g][i][j]);
                new_cube[f][i][j] = sum;
            }
        }
    }
    memcpy(cube, new_cube, sizeof(new_cube));
}
