#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <png.h>
#include <openssl/evp.h>
#include <openssl/kdf.h>
#include "stego_util.h"
#include "prng_utils.h"

#define MAX_PNG_DIM 10000
#define MAX_FILE_SIZE (1024ULL * 1024ULL * 1024ULL)

static void put_u64(uint8_t *b, uint64_t v) {
    for (int i = 0; i < 8; i++) b[i] = (v >> (8 * i)) & 0xff;
}

static uint64_t get_u64(const uint8_t *b) {
    uint64_t v = 0;
    for (int i = 0; i < 8; i++) v |= ((uint64_t)b[i]) << (8 * i);
    return v;
}

void embed_png(const char *carrier, const char *outfile,
               const uint8_t *data, size_t len, const char *password) {
    check_add(len, 8);
    uint8_t *payload = xmalloc(len + 8);
    put_u64(payload, len);
    memcpy(payload + 8, data, len);
    size_t bits = (len + 8) * 8;

    FILE *fp = xfopen(carrier, "rb");
    png_structp png = png_create_read_struct(PNG_LIBPNG_VER_STRING, NULL, NULL, NULL);
    png_infop info = png_create_info_struct(png);
    if (setjmp(png_jmpbuf(png))) die("png read");
    png_init_io(png, fp);
    png_read_info(png, info);

    png_uint_32 w, h;
    int bd, ct;
    png_get_IHDR(png, info, &w, &h, &bd, &ct, NULL, NULL, NULL);
    
    /* ----- ADDED DIMENSION CHECKS ----- */
    if (w == 0 || h == 0 || w > MAX_PNG_DIM || h > MAX_PNG_DIM)
        die("invalid PNG dimensions");
    /* --------------------------------- */

    if (bd != 8) die("unsupported bit depth");
    if (ct == PNG_COLOR_TYPE_PALETTE) png_set_palette_to_rgb(png);
    if (ct == PNG_COLOR_TYPE_GRAY && bd < 8) png_set_expand_gray_1_2_4_to_8(png);
    if (png_get_valid(png, info, PNG_INFO_tRNS)) png_set_tRNS_to_alpha(png);
    if (ct == PNG_COLOR_TYPE_RGB_ALPHA || ct == PNG_COLOR_TYPE_GRAY_ALPHA) png_set_strip_alpha(png);

    png_read_update_info(png, info);
    size_t rowbytes = png_get_rowbytes(png, info);
    
    /* ----- ADDED ROWBYTES OVERFLOW CHECK (redundant but safe) ----- */
    if (rowbytes > SIZE_MAX / h) die("image too large");
    /* -------------------------------------------------------------- */
    
    check_mul(rowbytes, h);
    size_t img_size = rowbytes * h;
    uint8_t *img = xmalloc(img_size);
    png_bytep *rows = xmalloc(sizeof(png_bytep) * h);
    for (size_t y = 0; y < h; y++) rows[y] = img + y * rowbytes;
    png_read_image(png, rows);
    fclose(fp);
    png_destroy_read_struct(&png, &info, NULL);
    free(rows);

    if (bits > img_size) die("carrier image too small");

    // Use password‑only seed (fixed salt)
    uint8_t seed[32];
    if (PKCS5_PBKDF2_HMAC(password, strlen(password),
                          (const uint8_t*)"fixed_stego_salt", 17, 100000,
                          EVP_sha256(), 32, seed) != 1)
        die("PBKDF2 failed");

    prng_state_t rng;
    if (prng_init(&rng, seed) != 0) die("PRNG init failed");

    size_t *indices = xmalloc(img_size * sizeof(size_t));
    for (size_t i = 0; i < img_size; i++) indices[i] = i;
    for (size_t i = img_size - 1; i > 0; i--) {
        uint32_t r;
        prng_generate(&rng, (uint8_t*)&r, 4);
        size_t j = r % (i + 1);
        size_t t = indices[i];
        indices[i] = indices[j];
        indices[j] = t;
    }
    prng_free(&rng);

    for (size_t i = 0; i < bits; i++) {
        size_t pos = indices[i];
        uint8_t bit = (payload[i/8] >> (i%8)) & 1;
        img[pos] = (img[pos] & 0xFE) | bit;
    }
    free(indices);
    free(payload);

    fp = xfopen(outfile, "wb");
    png = png_create_write_struct(PNG_LIBPNG_VER_STRING, NULL, NULL, NULL);
    info = png_create_info_struct(png);
    if (setjmp(png_jmpbuf(png))) die("png write");
    png_init_io(png, fp);
    png_set_IHDR(png, info, w, h, 8, PNG_COLOR_TYPE_RGB,
                 PNG_INTERLACE_NONE, PNG_COMPRESSION_TYPE_BASE, PNG_FILTER_TYPE_BASE);
    png_write_info(png, info);
    rows = xmalloc(sizeof(png_bytep) * h);
    for (size_t y = 0; y < h; y++) rows[y] = img + y * rowbytes;
    png_write_image(png, rows);
    png_write_end(png, NULL);
    fclose(fp);
    png_destroy_write_struct(&png, &info);
    free(rows);
    free(img);
}

uint8_t *read_png(const char *file, size_t *out_len, const char *password) {
    FILE *fp = xfopen(file, "rb");
    png_structp png = png_create_read_struct(PNG_LIBPNG_VER_STRING, NULL, NULL, NULL);
    png_infop info = png_create_info_struct(png);
    if (setjmp(png_jmpbuf(png))) die("png read error");
    png_init_io(png, fp);
    png_read_info(png, info);

    png_uint_32 w, h;
    int bd, ct;
    png_get_IHDR(png, info, &w, &h, &bd, &ct, NULL, NULL, NULL);
    
    /* ----- ADDED DIMENSION CHECKS ----- */
    if (w == 0 || h == 0 || w > MAX_PNG_DIM || h > MAX_PNG_DIM)
        die("invalid PNG dimensions");
    /* --------------------------------- */
    
    if (bd != 8 || ct != PNG_COLOR_TYPE_RGB) die("unsupported PNG format");

    size_t row = w * 3;
    check_mul(row, h);
    size_t size = row * h;
    uint8_t *img = xmalloc(size);
    for (size_t y = 0; y < h; y++) {
        png_read_row(png, img + y * row, NULL);
    }
    png_destroy_read_struct(&png, &info, NULL);
    fclose(fp);

    if (size < 64) die("image too small");

    // Same password‑only seed
    uint8_t seed[32];
    if (PKCS5_PBKDF2_HMAC(password, strlen(password),
                          (const uint8_t*)"fixed_stego_salt", 17, 100000,
                          EVP_sha256(), 32, seed) != 1)
        die("PBKDF2 failed");

    prng_state_t rng;
    if (prng_init(&rng, seed) != 0) die("PRNG init failed");

    size_t *indices = xmalloc(size * sizeof(size_t));
    for (size_t i = 0; i < size; i++) indices[i] = i;
    for (size_t i = size - 1; i > 0; i--) {
        uint32_t r;
        prng_generate(&rng, (uint8_t*)&r, 4);
        size_t j = r % (i + 1);
        size_t t = indices[i];
        indices[i] = indices[j];
        indices[j] = t;
    }
    prng_free(&rng);

    uint8_t lenbuf[8] = {0};
    for (int i = 0; i < 64; i++) {
        size_t pos = indices[i];
        lenbuf[i/8] |= (img[pos] & 1) << (i%8);
    }
    uint64_t len64 = get_u64(lenbuf);
    if (len64 > MAX_FILE_SIZE) die("embedded size too large");
    check_add(len64, 8);
    size_t total_bits = (len64 + 8) * 8;
    if (total_bits > size) die("truncated data");

    uint8_t *out = xmalloc(len64);
    memset(out, 0, len64);
    for (size_t i = 64; i < total_bits; i++) {
        size_t pos = indices[i];
        uint8_t bit = img[pos] & 1;
        out[(i-64)/8] |= bit << ((i-64)%8);
    }
    free(indices);
    free(img);
    *out_len = len64;
    return out;
}
