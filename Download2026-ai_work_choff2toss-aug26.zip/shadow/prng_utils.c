#include <openssl/evp.h>
#include <string.h>
#include <stdint.h>
#include <stdlib.h>
#include <stdio.h>
#include "prng_utils.h"

#define ZERO_BUF_SIZE 1024

int prng_init(prng_state_t *state, const uint8_t *key32) {
    memset(state, 0, sizeof(*state));

    // IV is 16 bytes, usually starting from 0
    uint8_t iv[16] = {0};

    state->ctx = EVP_CIPHER_CTX_new();
    if (!state->ctx)
        return -1;

    if (!EVP_EncryptInit_ex(state->ctx, EVP_aes_256_ctr(), NULL, key32, iv))
        return -1;

    return 0;
}

uint8_t prng_get_byte(prng_state_t *state) {
    uint8_t byte;
    if (prng_generate(state, &byte, 1) != 0) {
        fprintf(stderr, "Failed to generate secure byte\n");
        exit(EXIT_FAILURE);
    }
    return byte;
}

int prng_generate(prng_state_t *state, uint8_t *out, size_t len) {
    int out_len = 0;
    size_t total = 0;

    while (total < len) {
        size_t chunk = (len - total > ZERO_BUF_SIZE) ? ZERO_BUF_SIZE : (len - total);
        if (!EVP_EncryptUpdate(state->ctx, out + total, &out_len,
                               state->zero_buf, (int)chunk))
            return -1;
        total += out_len;
    }
    return 0;
}

void prng_free(prng_state_t *state) {
    if (state->ctx)
        EVP_CIPHER_CTX_free(state->ctx);
}
