#include "rubik.h"
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <stdint.h>

typedef uint8_t face_t[MATRIX_SIZE][MATRIX_SIZE];

void rotate_row(face_t matrix, int row, bool reverse) {
    if (reverse) {
        uint8_t temp = matrix[row][0];
        for (int i = 0; i < MATRIX_SIZE - 1; i++) matrix[row][i] = matrix[row][i + 1];
        matrix[row][MATRIX_SIZE - 1] = temp;
    } else {
        uint8_t temp = matrix[row][MATRIX_SIZE - 1];
        for (int i = MATRIX_SIZE - 1; i > 0; i--) matrix[row][i] = matrix[row][i - 1];
        matrix[row][0] = temp;
    }
}

void rotate_col(face_t matrix, int col, bool reverse) {
    if (reverse) {
        uint8_t temp = matrix[0][col];
        for (int i = 0; i < MATRIX_SIZE - 1; i++) matrix[i][col] = matrix[i + 1][col];
        matrix[MATRIX_SIZE - 1][col] = temp;
    } else {
        uint8_t temp = matrix[MATRIX_SIZE - 1][col];
        for (int i = MATRIX_SIZE - 1; i > 0; i--) matrix[i][col] = matrix[i - 1][col];
        matrix[0][col] = temp;
    }
}
