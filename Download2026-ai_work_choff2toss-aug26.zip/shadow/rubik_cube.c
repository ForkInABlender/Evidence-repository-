#define _GNU_SOURCE
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#include "rubik_cube.h"
#include "prng_utils.h"

void derive_prng_seed(const uint8_t *k1, const uint8_t *k2, const uint8_t *k3, uint8_t *seed32) {
    for (int i = 0; i < 16; i++) {
        seed32[i]      = k1[i] ^ k2[i];
        seed32[16 + i] = k3[i] ^ (k1[i] + k2[i]);
    }
}

int save_cube_metadata(const cube_metadata_layers_t *meta) {
    FILE *fp = fopen("cube.meta", "wb");
    if (!fp) {
        perror("Failed to open cube.meta for writing");
        return -1;
    }
    if (fwrite(meta, sizeof(cube_metadata_layers_t), 1, fp) != 1) {
        perror("Failed to write metadata");
        fclose(fp);
        return -1;
    }
    fclose(fp);
    return 0;
}

int load_cube_metadata(cube_metadata_layers_t *meta) {
    FILE *fp = fopen("cube.meta", "rb");
    if (!fp) {
        perror("Failed to open cube.meta for reading");
        return -1;
    }
    if (fread(meta, sizeof(cube_metadata_layers_t), 1, fp) != 1) {
        perror("Failed to read metadata");
        fclose(fp);
        return -1;
    }
    fclose(fp);
    return 0;
}

// Rotate a single face 90° clockwise (non-static, as declared in header)
void rotate_face_clockwise(uint8_t face[MATRIX_SIZE][MATRIX_SIZE]) {
    uint8_t temp[MATRIX_SIZE][MATRIX_SIZE];
    for (int i = 0; i < MATRIX_SIZE; i++) {
        for (int j = 0; j < MATRIX_SIZE; j++) {
            temp[j][MATRIX_SIZE - 1 - i] = face[i][j];
        }
    }
    memcpy(face, temp, sizeof(temp));
}

// Rotate a single face 90° counter-clockwise (non-static)
void rotate_face_counterclockwise(uint8_t face[MATRIX_SIZE][MATRIX_SIZE]) {
    uint8_t temp[MATRIX_SIZE][MATRIX_SIZE];
    for (int i = 0; i < MATRIX_SIZE; i++) {
        for (int j = 0; j < MATRIX_SIZE; j++) {
            temp[MATRIX_SIZE - 1 - j][i] = face[i][j];
        }
    }
    memcpy(face, temp, sizeof(temp));
}

// The following move functions are global (non-static) as declared in the header.
void move_U(uint8_t cube[6][MATRIX_SIZE][MATRIX_SIZE]) {
    rotate_face_clockwise(cube[UP]);
    uint8_t tmp[MATRIX_SIZE];
    memcpy(tmp, cube[FRONT][0], MATRIX_SIZE);
    memcpy(cube[FRONT][0], cube[RIGHT][0], MATRIX_SIZE);
    memcpy(cube[RIGHT][0], cube[BACK][0], MATRIX_SIZE);
    memcpy(cube[BACK][0], cube[LEFT][0], MATRIX_SIZE);
    memcpy(cube[LEFT][0], tmp, MATRIX_SIZE);
}

void move_U_inverse(uint8_t cube[6][MATRIX_SIZE][MATRIX_SIZE]) {
    rotate_face_counterclockwise(cube[UP]);
    uint8_t tmp[MATRIX_SIZE];
    memcpy(tmp, cube[FRONT][0], MATRIX_SIZE);
    memcpy(cube[FRONT][0], cube[LEFT][0], MATRIX_SIZE);
    memcpy(cube[LEFT][0], cube[BACK][0], MATRIX_SIZE);
    memcpy(cube[BACK][0], cube[RIGHT][0], MATRIX_SIZE);
    memcpy(cube[RIGHT][0], tmp, MATRIX_SIZE);
}

void move_D(uint8_t cube[6][MATRIX_SIZE][MATRIX_SIZE]) {
    rotate_face_clockwise(cube[DOWN]);
    uint8_t tmp[MATRIX_SIZE];
    memcpy(tmp, cube[FRONT][MATRIX_SIZE-1], MATRIX_SIZE);
    memcpy(cube[FRONT][MATRIX_SIZE-1], cube[LEFT][MATRIX_SIZE-1], MATRIX_SIZE);
    memcpy(cube[LEFT][MATRIX_SIZE-1], cube[BACK][MATRIX_SIZE-1], MATRIX_SIZE);
    memcpy(cube[BACK][MATRIX_SIZE-1], cube[RIGHT][MATRIX_SIZE-1], MATRIX_SIZE);
    memcpy(cube[RIGHT][MATRIX_SIZE-1], tmp, MATRIX_SIZE);
}

void move_D_inverse(uint8_t cube[6][MATRIX_SIZE][MATRIX_SIZE]) {
    rotate_face_counterclockwise(cube[DOWN]);
    uint8_t tmp[MATRIX_SIZE];
    memcpy(tmp, cube[FRONT][MATRIX_SIZE-1], MATRIX_SIZE);
    memcpy(cube[FRONT][MATRIX_SIZE-1], cube[RIGHT][MATRIX_SIZE-1], MATRIX_SIZE);
    memcpy(cube[RIGHT][MATRIX_SIZE-1], cube[BACK][MATRIX_SIZE-1], MATRIX_SIZE);
    memcpy(cube[BACK][MATRIX_SIZE-1], cube[LEFT][MATRIX_SIZE-1], MATRIX_SIZE);
    memcpy(cube[LEFT][MATRIX_SIZE-1], tmp, MATRIX_SIZE);
}

void move_L(uint8_t cube[6][MATRIX_SIZE][MATRIX_SIZE]) {
    rotate_face_clockwise(cube[LEFT]);
    for (int i = 0; i < MATRIX_SIZE; i++) {
        uint8_t tmp = cube[UP][i][0];
        cube[UP][i][0] = cube[BACK][MATRIX_SIZE-1-i][MATRIX_SIZE-1];
        cube[BACK][MATRIX_SIZE-1-i][MATRIX_SIZE-1] = cube[DOWN][i][0];
        cube[DOWN][i][0] = cube[FRONT][i][0];
        cube[FRONT][i][0] = tmp;
    }
}

void move_R(uint8_t cube[6][MATRIX_SIZE][MATRIX_SIZE]) {
    rotate_face_clockwise(cube[RIGHT]);
    for (int i = 0; i < MATRIX_SIZE; i++) {
        uint8_t tmp = cube[UP][i][MATRIX_SIZE-1];
        cube[UP][i][MATRIX_SIZE-1] = cube[FRONT][i][MATRIX_SIZE-1];
        cube[FRONT][i][MATRIX_SIZE-1] = cube[DOWN][i][MATRIX_SIZE-1];
        cube[DOWN][i][MATRIX_SIZE-1] = cube[BACK][MATRIX_SIZE-1-i][0];
        cube[BACK][MATRIX_SIZE-1-i][0] = tmp;
    }
}

void move_F(uint8_t cube[6][MATRIX_SIZE][MATRIX_SIZE]) {
    rotate_face_clockwise(cube[FRONT]);
    for (int i = 0; i < MATRIX_SIZE; i++) {
        uint8_t tmp = cube[UP][MATRIX_SIZE-1][i];
        cube[UP][MATRIX_SIZE-1][i] = cube[LEFT][MATRIX_SIZE-1-i][MATRIX_SIZE-1];
        cube[LEFT][MATRIX_SIZE-1-i][MATRIX_SIZE-1] = cube[DOWN][0][MATRIX_SIZE-1-i];
        cube[DOWN][0][MATRIX_SIZE-1-i] = cube[RIGHT][i][0];
        cube[RIGHT][i][0] = tmp;
    }
}

void move_B(uint8_t cube[6][MATRIX_SIZE][MATRIX_SIZE]) {
    rotate_face_clockwise(cube[BACK]);
    for (int i = 0; i < MATRIX_SIZE; i++) {
        uint8_t tmp = cube[UP][0][i];
        cube[UP][0][i] = cube[RIGHT][i][MATRIX_SIZE-1];
        cube[RIGHT][i][MATRIX_SIZE-1] = cube[DOWN][MATRIX_SIZE-1][MATRIX_SIZE-1-i];
        cube[DOWN][MATRIX_SIZE-1][MATRIX_SIZE-1-i] = cube[LEFT][MATRIX_SIZE-1-i][0];
        cube[LEFT][MATRIX_SIZE-1-i][0] = tmp;
    }
}

void move_L_inverse(uint8_t cube[6][MATRIX_SIZE][MATRIX_SIZE]) {
    rotate_face_counterclockwise(cube[LEFT]);
    for (int i = 0; i < MATRIX_SIZE; i++) {
        uint8_t tmp = cube[UP][i][0];
        cube[UP][i][0] = cube[FRONT][i][0];
        cube[FRONT][i][0] = cube[DOWN][i][0];
        cube[DOWN][i][0] = cube[BACK][MATRIX_SIZE-1-i][MATRIX_SIZE-1];
        cube[BACK][MATRIX_SIZE-1-i][MATRIX_SIZE-1] = tmp;
    }
}

void move_R_inverse(uint8_t cube[6][MATRIX_SIZE][MATRIX_SIZE]) {
    rotate_face_counterclockwise(cube[RIGHT]);
    for (int i = 0; i < MATRIX_SIZE; i++) {
        uint8_t tmp = cube[UP][i][MATRIX_SIZE-1];
        cube[UP][i][MATRIX_SIZE-1] = cube[BACK][MATRIX_SIZE-1-i][0];
        cube[BACK][MATRIX_SIZE-1-i][0] = cube[DOWN][i][MATRIX_SIZE-1];
        cube[DOWN][i][MATRIX_SIZE-1] = cube[FRONT][i][MATRIX_SIZE-1];
        cube[FRONT][i][MATRIX_SIZE-1] = tmp;
    }
}

void move_F_inverse(uint8_t cube[6][MATRIX_SIZE][MATRIX_SIZE]) {
    rotate_face_counterclockwise(cube[FRONT]);
    for (int i = 0; i < MATRIX_SIZE; i++) {
        uint8_t tmp = cube[UP][MATRIX_SIZE-1][i];
        cube[UP][MATRIX_SIZE-1][i] = cube[RIGHT][i][0];
        cube[RIGHT][i][0] = cube[DOWN][0][MATRIX_SIZE-1-i];
        cube[DOWN][0][MATRIX_SIZE-1-i] = cube[LEFT][MATRIX_SIZE-1-i][MATRIX_SIZE-1];
        cube[LEFT][MATRIX_SIZE-1-i][MATRIX_SIZE-1] = tmp;
    }
}

void move_B_inverse(uint8_t cube[6][MATRIX_SIZE][MATRIX_SIZE]) {
    rotate_face_counterclockwise(cube[BACK]);
    for (int i = 0; i < MATRIX_SIZE; i++) {
        uint8_t tmp = cube[UP][0][i];
        cube[UP][0][i] = cube[LEFT][MATRIX_SIZE-1-i][0];
        cube[LEFT][MATRIX_SIZE-1-i][0] = cube[DOWN][MATRIX_SIZE-1][MATRIX_SIZE-1-i];
        cube[DOWN][MATRIX_SIZE-1][MATRIX_SIZE-1-i] = cube[RIGHT][i][MATRIX_SIZE-1];
        cube[RIGHT][i][MATRIX_SIZE-1] = tmp;
    }
}

// Add these near the top (if not already present)
static void perform_move(uint8_t cube[6][MATRIX_SIZE][MATRIX_SIZE], char move) {
    switch (move) {
        case 'U': move_U(cube); break;
        case 'D': move_D(cube); break;
        case 'L': move_L(cube); break;
        case 'R': move_R(cube); break;
        case 'F': move_F(cube); break;
        case 'B': move_B(cube); break;
        default: break;
    }
}

static void perform_move_inverse(uint8_t cube[6][MATRIX_SIZE][MATRIX_SIZE], char move) {
    switch (move) {
        case 'U': move_U_inverse(cube); break;
        case 'D': move_D_inverse(cube); break;
        case 'L': move_L_inverse(cube); break;
        case 'R': move_R_inverse(cube); break;
        case 'F': move_F_inverse(cube); break;
        case 'B': move_B_inverse(cube); break;
        default: break;
    }
}

// Then the new shuffle_cube (4 arguments)
void shuffle_cube(uint8_t cube[6][MATRIX_SIZE][MATRIX_SIZE], char *transform_key, size_t key_size,
                  const uint8_t *shuffle_seed) {
    const char moves[] = {'U', 'D', 'L', 'R', 'F', 'B'};
    const int num_moves = sizeof(moves) / sizeof(moves[0]);
    transform_key[0] = '\0';

    prng_state_t prng;
    if (prng_init(&prng, shuffle_seed) != 0) {
        fprintf(stderr, "Failed to initialize PRNG for shuffle\n");
        exit(1);
    }

    for (int i = 0; i < NUM_MOVES && strlen(transform_key) < key_size - 3; i++) {
        uint8_t byte;
        if (prng_generate(&prng, &byte, 1) != 0) {
            fprintf(stderr, "PRNG generation failed\n");
            prng_free(&prng);
            exit(1);
        }
        char move = moves[byte % num_moves];
        perform_move(cube, move);
        size_t len = strlen(transform_key);
        transform_key[len] = move;
        transform_key[len + 1] = ' ';
        transform_key[len + 2] = '\0';
    }
    prng_free(&prng);
}

void unshuffle_cube(uint8_t cube[6][MATRIX_SIZE][MATRIX_SIZE], const char *transform_key) {
    char key_copy[1024];
    strncpy(key_copy, transform_key, sizeof(key_copy));
    key_copy[sizeof(key_copy) - 1] = '\0';
    char *tokens[NUM_MOVES];
    int count = 0;
    char *saveptr = NULL;
    char *token = strtok_r(key_copy, " ", &saveptr);
    while (token && count < NUM_MOVES) {
        tokens[count++] = token;
        token = strtok_r(NULL, " ", &saveptr);
    }
    for (int i = count - 1; i >= 0; i--) {
        char move = tokens[i][0];
        perform_move_inverse(cube, move);
    }
}
