#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <limits.h>
#include "png_stego.h"

#define MAX_FILE_SIZE (1024ULL * 1024ULL * 1024ULL)

void die(const char *msg) {
    fprintf(stderr, "Error: %s\n", msg);
    exit(1);
}

void *xmalloc(size_t n) {
    if (n == 0 || n > MAX_FILE_SIZE) die("bad alloc");
    void *p = malloc(n);
    if (!p) die("malloc");
    return p;
}

FILE *xfopen(const char *p, const char *m) {
    FILE *f = fopen(p, m);
    if (!f) { perror(p); exit(1); }
    return f;
}

void xfread(void *b, size_t n, FILE *f) {
    if (fread(b, 1, n, f) != n) die("fread");
}

void xfwrite(const void *b, size_t n, FILE *f) {
    if (fwrite(b, 1, n, f) != n) die("fwrite");
}

void put_u32(uint8_t *b, uint32_t v) {
    for (int i = 0; i < 4; i++) b[i] = (v >> (8 * i)) & 0xff;
}

uint32_t get_u32(const uint8_t *b) {
    return b[0] | b[1] << 8 | b[2] << 16 | b[3] << 24;
}

void check_add(size_t a, size_t b) {
    if (a > SIZE_MAX - b) die("overflow add");
}

void check_mul(size_t a, size_t b) {
    if (a && b > SIZE_MAX / a) die("overflow mul");
}