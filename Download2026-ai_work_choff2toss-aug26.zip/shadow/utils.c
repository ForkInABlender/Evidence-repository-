#include "utils.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <openssl/evp.h>
#include <openssl/pem.h>
#include <openssl/err.h>

uint8_t* read_file(const char *filename, size_t *out_len) {
    FILE *fp = fopen(filename, "rb");
    if (!fp) return NULL;
    fseek(fp, 0, SEEK_END);
    long fsize = ftell(fp);
    fseek(fp, 0, SEEK_SET);
    if (fsize < 0) { fclose(fp); return NULL; }
    uint8_t *buf = malloc(fsize);
    if (!buf) { fclose(fp); return NULL; }
    size_t nread = fread(buf, 1, fsize, fp);
    fclose(fp);
    if (nread != (size_t)fsize) { free(buf); return NULL; }
    *out_len = fsize;
    return buf;
}

void print_face0_preview(const uint8_t cube[6][MATRIX_SIZE][MATRIX_SIZE], 
                         const char *label, size_t len) {
    printf("%s (first %zu bytes of face 0): ", label, len);
    for (size_t i = 0; i < len && i < MATRIX_SIZE * MATRIX_SIZE; i++)
        putchar(cube[0][i / MATRIX_SIZE][i % MATRIX_SIZE]);
    printf("\n");
}

/*void generate_rsa_keypair(const char *priv_path, const char *pub_path) {
    EVP_PKEY_CTX *ctx = EVP_PKEY_CTX_new_id(EVP_PKEY_RSA, NULL);
    EVP_PKEY *pkey = NULL;
    if (!ctx || EVP_PKEY_keygen_init(ctx) <= 0 ||
        EVP_PKEY_CTX_set_rsa_keygen_bits(ctx, 16384) <= 0 ||
        EVP_PKEY_keygen(ctx, &pkey) <= 0) {
        ERR_print_errors_fp(stderr);
        exit(EXIT_FAILURE);
    }
    FILE *priv_fp = fopen(priv_path, "w");
    if (!priv_fp || !PEM_write_PrivateKey(priv_fp, pkey, NULL, NULL, 0, NULL, NULL))
        exit(EXIT_FAILURE);
    fclose(priv_fp);
    FILE *pub_fp = fopen(pub_path, "w");
    if (!pub_fp || !PEM_write_PUBKEY(pub_fp, pkey)) exit(EXIT_FAILURE);
    fclose(pub_fp);
    EVP_PKEY_free(pkey);
    EVP_PKEY_CTX_free(ctx);
}*/
