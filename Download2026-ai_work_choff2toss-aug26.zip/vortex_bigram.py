import numpy as np
from collections import defaultdict, Counter

# --- Vortex math primitives ---

DOUBLING_SEQ = [1, 2, 4, 8, 7, 5]  # mod-9 doubling cycle (Rodin vortex skin)
DOUBLING_POS = {v: i for i, v in enumerate(DOUBLING_SEQ)}

FAMILY_GROUPS = {
    1: 0, 4: 0, 7: 0,   # family A
    2: 1, 5: 1, 8: 1,   # family B
    3: 2, 6: 2, 9: 2,   # axis (3,6,9)
    0: 2,               # treat 0 as axis
}

def digital_root(x):
    return (x % 9) or 9

def vortex_position(x):
    """Position in the doubling sequence, or -1 if axis number."""
    dr = digital_root(x)
    return DOUBLING_POS.get(dr, -1)

def family_group(x):
    dr = digital_root(x)
    return FAMILY_GROUPS.get(dr, 2)

def tokenize(text):
    return [ord(c) for c in text]


# --- Models ---

class BaselineBigram:
    def __init__(self):
        self.p = defaultdict(Counter)

    def train(self, seqs):
        for s in seqs:
            for a, b in zip(s[:-1], s[1:]):
                self.p[a][b] += 1

    def predict(self, a):
        c = self.p[a]
        total = sum(c.values())
        return {k: v / total for k, v in c.items()} if total else {}


class VortexAugmentedBigram:
    """
    Three-level signal:
      1. char-level bigram (exact identity)
      2. vortex-position bigram (position in 1-2-4-8-7-5 cycle)
      3. family-group bigram ({1,4,7}, {2,5,8}, {3,6,9})

    Weights reflect specificity: char > vortex position > family group.
    Residue signal is lifted back to char space by boosting all chars
    that share the predicted residue property, proportional to their
    char-level prior — avoiding the broken flat-key collision in the original.
    """
    W_CHAR = 0.6
    W_VPOS = 0.25
    W_FAM  = 0.15

    def __init__(self):
        self.p_char  = defaultdict(Counter)
        self.p_vpos  = defaultdict(Counter)
        self.p_fam   = defaultdict(Counter)
        self.char_prior = Counter()

    def train(self, seqs):
        for s in seqs:
            for a, b in zip(s[:-1], s[1:]):
                self.p_char[a][b] += 1
                self.p_vpos[vortex_position(a)][vortex_position(b)] += 1
                self.p_fam[family_group(a)][family_group(b)] += 1
                self.char_prior[b] += 1

    def _normalize(self, counter):
        total = sum(counter.values())
        return {k: v / total for k, v in counter.items()} if total else {}

    def _prior(self, chars):
        sub = {c: self.char_prior[c] for c in chars}
        total = sum(sub.values()) or 1
        return {c: v / total for c, v in sub.items()}

    def predict(self, a):
        char_dist = self._normalize(self.p_char[a])
        vpos_dist = self._normalize(self.p_vpos[vortex_position(a)])
        fam_dist  = self._normalize(self.p_fam[family_group(a)])

        all_chars = set(self.char_prior.keys())
        out = Counter()

        # 1. Direct char signal
        for k, v in char_dist.items():
            out[k] += self.W_CHAR * v

        # 2. Vortex-position signal: distribute over chars matching predicted vpos
        for target_vpos, vp in vpos_dist.items():
            matching = [c for c in all_chars if vortex_position(c) == target_vpos]
            if matching:
                for c, pw in self._prior(matching).items():
                    out[c] += self.W_VPOS * vp * pw

        # 3. Family-group signal: distribute over chars matching predicted family
        for target_fam, fp in fam_dist.items():
            matching = [c for c in all_chars if family_group(c) == target_fam]
            if matching:
                for c, pw in self._prior(matching).items():
                    out[c] += self.W_FAM * fp * pw

        return self._normalize(out)


# --- Evaluation ---

def eval_model(model, seqs):
    loglik, n = 0, 0
    for s in seqs:
        for a, b in zip(s[:-1], s[1:]):
            pred = model.predict(a)
            loglik += np.log(pred.get(b, 1e-9))
            n += 1
    return loglik / n if n else float('-inf')


# --- Run ---

train_data = [tokenize(s) for s in [
    "hello world", "hello there", "world model test",
    "the quick brown fox", "language models learn patterns"
]]
test_data = [tokenize(s) for s in [
    "hello model", "world there", "the brown model"
]]

base   = BaselineBigram()
vortex = VortexAugmentedBigram()

base.train(train_data)
vortex.train(train_data)

b_score = eval_model(base,   test_data)
v_score = eval_model(vortex, test_data)

print(f"baseline:         {b_score:.4f}")
print(f"vortex-augmented: {v_score:.4f}")
print(f"delta:            {v_score - b_score:+.4f}  ({'better' if v_score > b_score else 'worse'})")
