# PyBrain3 20-Epoch Replication Package — Epoch Saves

This package is configured for **20 epochs** and now saves XML checkpoints after every epoch.

Run:

```bash
cd replicate_pybrain3
python replicate_assistant.py
```

Checkpoint outputs:

```text
checkpoints/teacher_soft_epoch_001.xml ... checkpoints/teacher_soft_epoch_020.xml
checkpoints/teacher_blend_epoch_001.xml ... checkpoints/teacher_blend_epoch_020.xml
checkpoints/gpt_epoch_001.xml ... checkpoints/gpt_epoch_020.xml
```

Final outputs:

```text
vortex_model_20.xml
vortex_model.xml
gpt_replicated_20.xml
training_state_20.json
conversation_memory.jsonl
```

Resume behavior:

- If execution stops, rerun `python replicate_assistant.py`.
- The script detects the latest XML checkpoint in `checkpoints/`.
- It resumes from the next epoch instead of restarting.
- Each checkpoint is immediately verified with `NetworkReader.readFrom(...)`.

The script also patches SciPy's `__init__.py` with NumPy compatibility imports, including a safe `mat = np.asmatrix` fallback for NumPy 2.x.
