# Dylan Kenneth Eliot + Pybrain3_gpt remodeling bot
"""
replicate_assistant.py

20-epoch continual "replication" trainer for the uploaded PyBrain3 stack.

Run:
    python replicate_assistant.py

Epoch-save / resume outputs:
    checkpoints/
        teacher_soft_epoch_001.xml ... teacher_soft_epoch_020.xml
        teacher_blend_epoch_001.xml ... teacher_blend_epoch_020.xml
        gpt_epoch_001.xml ... gpt_epoch_020.xml
    vortex_model_20.xml
    gpt_replicated_20.xml
    vortex_model.xml
    conversation_memory.jsonl
    training_state_20.json

Resume behavior:
- On startup, the script reads training_state_20.json and the checkpoint folder.
- If teacher soft/blend checkpoints exist, it loads the latest epoch and continues.
- If GPT checkpoints exist, it loads the latest GPT XML and continues.
- Every epoch writes XML immediately with NetworkWriter.writeToFile.
"""

import os
import re
import sys
import json
import time
from pathlib import Path

import numpy as np

EPOCHS = 20
GPT_IO = 50257
NGRAM_N = 4
MEMORY_PATH = Path("conversation_memory.jsonl")
STATE_PATH = Path("training_state_20.json")
CHECKPOINT_DIR = Path("checkpoints")

SCIPY_NUMPY_COMPAT_BLOCK = """import numpy as _np
from numpy import __version__ as __numpy_version__
from numpy import reshape, outer, dot, where, array, exp, zeros, size
from numpy import ndarray, eye, tanh, clip, log, sqrt, power, pi, tan, diag, random as rand
from numpy import random, asarray, mgrid, tile, floor, sum
try:
    from numpy import mat
except ImportError:
    mat = _np.asmatrix
from numpy import *
"""


def write_state(**kwargs):
    state = {}
    if STATE_PATH.exists():
        try:
            state = json.loads(STATE_PATH.read_text(encoding="utf-8"))
        except Exception:
            state = {}
    state.update(kwargs)
    state["updated_unix"] = time.time()
    STATE_PATH.write_text(json.dumps(state, indent=2), encoding="utf-8")


def read_state():
    if not STATE_PATH.exists():
        return {}
    try:
        return json.loads(STATE_PATH.read_text(encoding="utf-8"))
    except Exception:
        return {}


def latest_checkpoint(prefix):
    CHECKPOINT_DIR.mkdir(exist_ok=True)
    pattern = re.compile(rf"^{re.escape(prefix)}_epoch_(\d{{3}})\.xml$")
    best_epoch = 0
    best_path = None
    for p in CHECKPOINT_DIR.glob(f"{prefix}_epoch_*.xml"):
        m = pattern.match(p.name)
        if not m:
            continue
        ep = int(m.group(1))
        if ep > best_epoch:
            best_epoch = ep
            best_path = p
    return best_epoch, best_path


def save_epoch(net, prefix, epoch):
    from pybrain3.tools.xml import NetworkWriter, NetworkReader
    CHECKPOINT_DIR.mkdir(exist_ok=True)
    path = CHECKPOINT_DIR / f"{prefix}_epoch_{epoch:03d}.xml"
    NetworkWriter.writeToFile(net, str(path))
    # Verify the XML is readable immediately.
    NetworkReader.readFrom(str(path))
    return str(path)


def patch_scipy_numpy_imports():
    """Patch scipy/__init__.py once, preserving a backup."""
    import scipy
    init_path = Path(scipy.__file__)
    text = init_path.read_text(encoding="utf-8")
    marker = "from numpy import reshape, outer, dot"
    if marker in text and "mat = _np.asmatrix" in text:
        print(f"SciPy NumPy compatibility imports already present: {init_path}")
        return str(init_path)

    backup = init_path.with_suffix(init_path.suffix + ".bak_pybrain3_replicate")
    if not backup.exists():
        backup.write_text(text, encoding="utf-8")

    init_path.write_text(SCIPY_NUMPY_COMPAT_BLOCK + "\n" + text, encoding="utf-8")
    print(f"Patched SciPy NumPy compatibility imports: {init_path}")
    return str(init_path)


def append_conversation(input_text, output_text):
    MEMORY_PATH.parent.mkdir(parents=True, exist_ok=True)
    with MEMORY_PATH.open("a", encoding="utf-8") as f:
        f.write(json.dumps({
            "input": input_text,
            "output": output_text,
            "created_unix": time.time(),
        }, ensure_ascii=False) + "\n")


def seed_memory():
    if MEMORY_PATH.exists() and MEMORY_PATH.stat().st_size > 0:
        return
    append_conversation("Replicate you", "I can replicate behavior patterns into a PyBrain3 XML-trained student model.")
    append_conversation("Do it", "Building a teacher/student replication pipeline with XMLWriter/XMLReader persistence.")
    append_conversation("Then use 20 epochs", "Reconfiguring the replication pipeline to train with 20 epochs.")
    append_conversation("Then run without a timer", "External execution limits cannot be disabled; training should save checkpoints.")
    append_conversation("Yes, do epoch saves", "Adding per-epoch XML checkpoints and resume detection.")


def load_conversation_text():
    if not MEMORY_PATH.exists():
        return ""
    rows = []
    for line in MEMORY_PATH.read_text(encoding="utf-8").splitlines():
        try:
            obj = json.loads(line)
            rows.append(f"user: {obj.get('input','')}\nassistant: {obj.get('output','')}")
        except Exception:
            continue
    return "\n".join(rows)


def build_teacher_context():
    import vortex_distill as vd

    extra = load_conversation_text()
    corpus = vd.CORPUS + ("\n" + extra if extra else "")

    print("Building vortex vocabulary...")
    char2id, id2char, id2idx, idx2id, char2cluster = vd.build_vocab(corpus)
    vocab_size = len(char2id)
    feat_size = vocab_size + 3
    print(f"Teacher context: vocab={vocab_size}, input_features={feat_size}")

    ngram = vd.NGramTeacher(n=NGRAM_N)
    ngram.train(corpus)
    return vd, corpus, ngram, char2id, id2char, id2idx, idx2id, char2cluster, vocab_size, feat_size


def train_vortex_teacher():
    from pybrain3.tools.xml import NetworkWriter, NetworkReader
    from pybrain3.supervised.trainers import BackpropTrainer

    vd, corpus, ngram, char2id, id2char, id2idx, idx2id, char2cluster, vocab_size, feat_size = build_teacher_context()

    soft_epoch, soft_path = latest_checkpoint("teacher_soft")
    blend_epoch, blend_path = latest_checkpoint("teacher_blend")

    if blend_epoch >= EPOCHS and blend_path is not None:
        print(f"Teacher blend already complete at epoch {blend_epoch}; loading {blend_path}")
        net = NetworkReader.readFrom(str(blend_path))
        NetworkWriter.writeToFile(net, "vortex_model_20.xml")
        NetworkWriter.writeToFile(net, "vortex_model.xml")
        write_state(teacher_complete=True, teacher_blend_epoch=blend_epoch, vortex_model="vortex_model_20.xml")
        return net, corpus, char2id, id2char, id2idx, idx2id, char2cluster, vocab_size

    if soft_epoch > 0 and soft_path is not None:
        print(f"Resuming teacher after soft epoch {soft_epoch}: {soft_path}")
        net = NetworkReader.readFrom(str(soft_path))
    else:
        print("Building new LSTM teacher...")
        net = vd.build_rnn(feat_size, hidden_size=64, output_size=vocab_size)

    if soft_epoch < EPOCHS:
        print(f"Phase 1: n-gram soft-target distillation, epochs {soft_epoch + 1}..{EPOCHS}")
        ds_soft = vd.distill_dataset(corpus, ngram, char2id, id2idx, vocab_size, char2cluster, id2char)
        trainer = BackpropTrainer(net, ds_soft, learningrate=0.01, momentum=0.9)
        for epoch in range(soft_epoch + 1, EPOCHS + 1):
            err = trainer.train()
            ckpt = save_epoch(net, "teacher_soft", epoch)
            print(f"  teacher soft epoch {epoch:03d}/{EPOCHS} error={err:.8f} saved={ckpt}")
            write_state(teacher_soft_epoch=epoch, teacher_soft_error=float(err), teacher_soft_checkpoint=ckpt, requested_epochs=EPOCHS)

    # Continue from latest soft checkpoint unless a blend checkpoint is newer.
    if blend_epoch > 0 and blend_path is not None:
        print(f"Resuming teacher blend at epoch {blend_epoch}: {blend_path}")
        net = NetworkReader.readFrom(str(blend_path))
        start_blend = blend_epoch + 1
    else:
        _, soft_path = latest_checkpoint("teacher_soft")
        if soft_path is not None:
            net = NetworkReader.readFrom(str(soft_path))
        start_blend = 1

    if start_blend <= EPOCHS:
        print(f"Phase 2: blended hard/soft fine-tune, epochs {start_blend}..{EPOCHS}")
        ds_blend = vd.blended_dataset(corpus, ngram, char2id, id2idx, vocab_size, char2cluster, id2char)
        trainer = BackpropTrainer(net, ds_blend, learningrate=0.0005, momentum=0.9)
        for epoch in range(start_blend, EPOCHS + 1):
            err = trainer.train()
            ckpt = save_epoch(net, "teacher_blend", epoch)
            print(f"  teacher blend epoch {epoch:03d}/{EPOCHS} error={err:.8f} saved={ckpt}")
            write_state(teacher_blend_epoch=epoch, teacher_blend_error=float(err), teacher_blend_checkpoint=ckpt, requested_epochs=EPOCHS)

    NetworkWriter.writeToFile(net, "vortex_model_20.xml")
    NetworkWriter.writeToFile(net, "vortex_model.xml")
    NetworkReader.readFrom("vortex_model_20.xml")
    print("Saved and verified vortex_model_20.xml")
    write_state(teacher_complete=True, vortex_model="vortex_model_20.xml")
    return net, corpus, char2id, id2char, id2idx, idx2id, char2cluster, vocab_size


def train_gpt_student(teacher_pack):
    from pybrain3.tools.xml import NetworkWriter, NetworkReader
    import vortex_distill as vd

    teacher, corpus, char2id, id2char, id2idx, idx2id, char2cluster, vocab_size = teacher_pack

    gpt_epoch, gpt_path = latest_checkpoint("gpt")
    if gpt_epoch >= EPOCHS and gpt_path is not None:
        print(f"GPT student already complete at epoch {gpt_epoch}; loading {gpt_path}")
        student = NetworkReader.readFrom(str(gpt_path))
        NetworkWriter.writeToFile(student, "gpt_replicated_20.xml")
        write_state(gpt_complete=True, gpt_epoch=gpt_epoch, gpt_model="gpt_replicated_20.xml")
        return student

    if gpt_epoch > 0 and gpt_path is not None:
        print(f"Resuming GPT student at epoch {gpt_epoch}: {gpt_path}")
        student = NetworkReader.readFrom(str(gpt_path))
        start_epoch = gpt_epoch + 1
    else:
        from main_gpt3_3d import net as student
        start_epoch = 1

    print("Generating teacher sample for GPT student...")
    sample = vd.neural_generate(
        teacher, "the ",
        char2id, id2char, id2idx, idx2id,
        vocab_size, char2cluster,
        length=GPT_IO, temp=0.6
    )[:GPT_IO]

    words = sample.split()
    if len(words) < 2:
        words = corpus.split()

    unique = sorted(set(words))
    w2i = {w: i for i, w in enumerate(unique)}
    i2w = {i: w for w, i in w2i.items()}
    V = len(unique)
    print(f"GPT student reduced training vocab={V}, tokens={len(words)}")

    ngram = vd.NGramTeacher(n=NGRAM_N)
    ngram.train(sample)
    sorted_chars = sorted(char2id.keys())
    c2i = {c: i for i, c in enumerate(sorted_chars)}

    def vortex_weight(pos):
        dr = vd.digital_root(pos)
        vp = vd.vortex_pos(dr)
        fg = vd.family_group(pos)
        w = (vp + 1) / 6.0 if vp >= 0 else 0.5
        return max(w * (1.0 - fg * 0.1), 0.1)

    def encode_token(token_id, pos):
        vec = np.zeros(V)
        if token_id < V:
            vec[token_id] = vortex_weight(pos)
        return vec

    def soft_target(ctx_words, next_word_id):
        char_dist = ngram.soft_target(" ".join(ctx_words), sorted_chars, c2i, len(char2id))
        y = np.zeros(V)
        if char_dist is not None:
            for wid, word in i2w.items():
                if word and word[0] in c2i:
                    y[wid] += char_dist[c2i[word[0]]]
            s = y.sum()
            if s > 0:
                return y / s
        y[next_word_id] = 1.0
        return y

    tokens = [w2i[w] for w in words if w in w2i]
    print(f"Training GPT student, epochs {start_epoch}..{EPOCHS}")
    for epoch in range(start_epoch, EPOCHS + 1):
        total_err = 0.0
        denom = max(len(tokens) - 1, 1)
        for i in range(len(tokens) - 1):
            x_small = encode_token(tokens[i], i + 1)
            ctx = [i2w[t] for t in tokens[max(0, i - NGRAM_N + 1):i + 1] if t in i2w]
            y_small = soft_target(ctx, tokens[i + 1])

            x = np.zeros(GPT_IO); x[:V] = x_small
            y = np.zeros(GPT_IO); y[:V] = y_small

            out = np.array(student.activate(x), dtype=np.float64)
            err = out - y
            total_err += float(np.dot(err, err))
            student.backActivate(err)
        mse = total_err / denom
        ckpt = save_epoch(student, "gpt", epoch)
        print(f"  GPT epoch {epoch:03d}/{EPOCHS} mse={mse:.8f} saved={ckpt}")
        write_state(gpt_epoch=epoch, gpt_mse=float(mse), gpt_checkpoint=ckpt, requested_epochs=EPOCHS)

    NetworkWriter.writeToFile(student, "gpt_replicated_20.xml")
    NetworkReader.readFrom("gpt_replicated_20.xml")
    print("Saved and verified gpt_replicated_20.xml")
    write_state(gpt_complete=True, gpt_model="gpt_replicated_20.xml")
    return student


def main():
    patch_scipy_numpy_imports()
    seed_memory()
    write_state(requested_epochs=EPOCHS, started_unix=time.time(), checkpoint_dir=str(CHECKPOINT_DIR))
    teacher_pack = train_vortex_teacher()
    train_gpt_student(teacher_pack)
    write_state(completed=True)
    print("20-epoch replication training complete.")


if __name__ == "__main__":
    main()
