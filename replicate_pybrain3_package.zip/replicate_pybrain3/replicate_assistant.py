# Dylan Kenneth Eliot + Pybrain3_gpt remodeling bot
"""
replicate_assistant.py

Continual "replication" trainer for the uploaded PyBrain3 stack.

What it does:
1. Patches SciPy's __init__.py with the NumPy compatibility imports requested.
2. Trains the vortex/LSTM teacher for 40 epochs.
3. Trains the GPT-style 50,257 I/O student for 40 epochs on teacher/generated text.
4. Saves XML models with PyBrain3 NetworkWriter and verifies with NetworkReader.
5. Stores conversation input/output pairs in JSONL so future runs can continue training.

Run from this folder:
    python replicate_assistant.py

Outputs:
    vortex_model_40.xml
    gpt_replicated_40.xml
    conversation_memory.jsonl
"""

import os
import sys
import json
import time
import shutil
import importlib
from pathlib import Path

import numpy as np

EPOCHS = 40
GPT_IO = 50257
NGRAM_N = 4
MEMORY_PATH = Path("conversation_memory.jsonl")

SCIPY_NUMPY_COMPAT_BLOCK = """import numpy as _np
from numpy import __version__ as __numpy_version__
from numpy import reshape, outer, dot, where, array, exp, zeros, size
from numpy import ndarray, eye, tanh, clip, log, sqrt, power, pi, tan, diag, random as rand
from numpy import random, asarray, mgrid, tile, floor, sum
try:
    from numpy import mat
except ImportError:
    mat = _np.asmatrix
from numpy import *
"""


def patch_scipy_numpy_imports():
    """Patch scipy/__init__.py once, preserving a backup."""
    import scipy
    init_path = Path(scipy.__file__)
    text = init_path.read_text(encoding="utf-8")
    marker = "from numpy import reshape, outer, dot"
    if marker in text and "mat = _np.asmatrix" in text:
        print(f"SciPy NumPy compatibility imports already present: {init_path}")
        return str(init_path)

    backup = init_path.with_suffix(init_path.suffix + ".bak_pybrain3_replicate")
    if not backup.exists():
        backup.write_text(text, encoding="utf-8")

    # Remove any earlier incompatible leading block before inserting the safe one.
    while text.startswith("from numpy import __version__ as __numpy_version__") or text.startswith("import numpy as _np"):
        idx = text.find("from numpy import *")
        if idx == -1:
            break
        end = text.find("\n", idx)
        text = text[end + 1:].lstrip("\n")

    init_path.write_text(SCIPY_NUMPY_COMPAT_BLOCK + "\n" + text, encoding="utf-8")
    print(f"Patched SciPy NumPy compatibility imports: {init_path}")
    return str(init_path)


def append_conversation(input_text, output_text):
    MEMORY_PATH.parent.mkdir(parents=True, exist_ok=True)
    with MEMORY_PATH.open("a", encoding="utf-8") as f:
        f.write(json.dumps({
            "input": input_text,
            "output": output_text,
            "created_unix": time.time(),
        }, ensure_ascii=False) + "\n")


def load_conversation_text():
    if not MEMORY_PATH.exists():
        return ""
    rows = []
    for line in MEMORY_PATH.read_text(encoding="utf-8").splitlines():
        try:
            obj = json.loads(line)
            rows.append(f"user: {obj.get('input','')}\nassistant: {obj.get('output','')}")
        except Exception:
            continue
    return "\n".join(rows)


def train_vortex_teacher():
    from pybrain3.tools.xml import NetworkWriter, NetworkReader
    from pybrain3.supervised.trainers import BackpropTrainer

    import vortex_distill as vd

    extra = load_conversation_text()
    corpus = vd.CORPUS + ("\n" + extra if extra else "")

    print("Building vortex vocabulary...")
    char2id, id2char, id2idx, idx2id, char2cluster = vd.build_vocab(corpus)
    vocab_size = len(char2id)
    feat_size = vocab_size + 3

    print(f"Building LSTM teacher: vocab={vocab_size}, input_features={feat_size}")
    ngram = vd.NGramTeacher(n=NGRAM_N)
    ngram.train(corpus)
    net = vd.build_rnn(feat_size, hidden_size=64, output_size=vocab_size)

    print(f"Phase 1: n-gram soft-target distillation for {EPOCHS} epochs")
    ds_soft = vd.distill_dataset(corpus, ngram, char2id, id2idx, vocab_size, char2cluster, id2char)
    trainer = BackpropTrainer(net, ds_soft, learningrate=0.01, momentum=0.9)
    for epoch in range(1, EPOCHS + 1):
        err = trainer.train()
        print(f"  teacher soft epoch {epoch:03d}/{EPOCHS} error={err:.8f}")

    print(f"Phase 2: blended hard/soft fine-tune for {EPOCHS} epochs")
    ds_blend = vd.blended_dataset(corpus, ngram, char2id, id2idx, vocab_size, char2cluster, id2char)
    trainer = BackpropTrainer(net, ds_blend, learningrate=0.0005, momentum=0.9)
    for epoch in range(1, EPOCHS + 1):
        err = trainer.train()
        print(f"  teacher blend epoch {epoch:03d}/{EPOCHS} error={err:.8f}")

    NetworkWriter.writeToFile(net, "vortex_model_40.xml")
    NetworkWriter.writeToFile(net, "vortex_model.xml")
    NetworkReader.readFrom("vortex_model_40.xml")
    print("Saved and verified vortex_model_40.xml")
    return net, corpus, char2id, id2char, id2idx, idx2id, char2cluster, vocab_size


def train_gpt_student(teacher_pack):
    from pybrain3.tools.xml import NetworkWriter, NetworkReader

    import vortex_distill as vd
    from main_gpt3_3d import net as student

    teacher, corpus, char2id, id2char, id2idx, idx2id, char2cluster, vocab_size = teacher_pack

    print("Generating teacher sample for GPT student...")
    sample = vd.neural_generate(
        teacher, "the ",
        char2id, id2char, id2idx, idx2id,
        vocab_size, char2cluster,
        length=GPT_IO, temp=0.6
    )[:GPT_IO]

    words = sample.split()
    if len(words) < 2:
        words = corpus.split()

    unique = sorted(set(words))
    w2i = {w: i for i, w in enumerate(unique)}
    i2w = {i: w for w, i in w2i.items()}
    V = len(unique)
    print(f"GPT student reduced training vocab={V}, tokens={len(words)}")

    ngram = vd.NGramTeacher(n=NGRAM_N)
    ngram.train(sample)
    sorted_chars = sorted(char2id.keys())
    c2i = {c: i for i, c in enumerate(sorted_chars)}

    def vortex_weight(pos):
        dr = vd.digital_root(pos)
        vp = vd.vortex_pos(dr)
        fg = vd.family_group(pos)
        w = (vp + 1) / 6.0 if vp >= 0 else 0.5
        return max(w * (1.0 - fg * 0.1), 0.1)

    def encode_token(token_id, pos):
        vec = np.zeros(V)
        if token_id < V:
            vec[token_id] = vortex_weight(pos)
        return vec

    def soft_target(ctx_words, next_word_id):
        char_dist = ngram.soft_target(" ".join(ctx_words), sorted_chars, c2i, len(char2id))
        y = np.zeros(V)
        if char_dist is not None:
            for wid, word in i2w.items():
                if word and word[0] in c2i:
                    y[wid] += char_dist[c2i[word[0]]]
            s = y.sum()
            if s > 0:
                return y / s
        y[next_word_id] = 1.0
        return y

    tokens = [w2i[w] for w in words if w in w2i]
    print(f"Training GPT student for {EPOCHS} epochs...")
    for epoch in range(1, EPOCHS + 1):
        total_err = 0.0
        denom = max(len(tokens) - 1, 1)
        for i in range(len(tokens) - 1):
            x_small = encode_token(tokens[i], i + 1)
            ctx = [i2w[t] for t in tokens[max(0, i - NGRAM_N + 1):i + 1] if t in i2w]
            y_small = soft_target(ctx, tokens[i + 1])

            x = np.zeros(GPT_IO); x[:V] = x_small
            y = np.zeros(GPT_IO); y[:V] = y_small

            out = np.array(student.activate(x), dtype=np.float64)
            err = out - y
            total_err += float(np.dot(err, err))
            student.backActivate(err)
        print(f"  GPT epoch {epoch:03d}/{EPOCHS} mse={total_err / denom:.8f}")

    NetworkWriter.writeToFile(student, "gpt_replicated_40.xml")
    NetworkReader.readFrom("gpt_replicated_40.xml")
    print("Saved and verified gpt_replicated_40.xml")
    return student


def main():
    patch_scipy_numpy_imports()

    # Seed this run with the current user/assistant replication request.
    if not MEMORY_PATH.exists():
        append_conversation("Replicate you", "I can replicate the behavior pattern into a PyBrain3 XML-trained student model.")
        append_conversation("Do it", "Building a 40-epoch teacher/student replication pipeline with XMLWriter/XMLReader persistence.")

    teacher_pack = train_vortex_teacher()
    train_gpt_student(teacher_pack)
    print("Replication training complete.")


if __name__ == "__main__":
    main()
